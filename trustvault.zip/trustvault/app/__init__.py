from pathlib import Path

from flask import Flask, jsonify, send_from_directory
from werkzeug.exceptions import HTTPException

from . import audit
from .config import Config
from .db import commit, get_db, init_schema, rollback
from .security import ApiError

CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'")


def create_app(**overrides):
    cfg = Config(**overrides)
    app = Flask(__name__, static_folder=None)
    app.config["TV"] = cfg
    app.config["MAX_CONTENT_LENGTH"] = cfg.MAX_UPLOAD_BYTES + 1024 * 1024
    app.config["JSON_SORT_KEYS"] = False
    if cfg.TRUST_PROXY:
        from werkzeug.middleware.proxy_fix import ProxyFix
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)   # real client IP in the audit trail
    init_schema(cfg.DB_PATH)

    from .routes import auth, docs, admin, events
    for m in (auth, docs, admin, events):
        app.register_blueprint(m.bp)

    static = Path(__file__).parent / "static"

    @app.get("/")
    def index():
        return send_from_directory(static, "index.html", max_age=0)

    @app.get("/healthz")
    def healthz():
        return jsonify({"ok": True})          # liveness only; reveals nothing

    @app.get("/static/<path:name>")
    def static_files(name):
        return send_from_directory(static, name, max_age=0)   # send_from_directory blocks traversal

    # ---- transaction + response hygiene
    @app.after_request
    def finish(resp):
        db = None
        try:
            from flask import g
            db = g.get("db")
        except RuntimeError:
            pass
        if db is not None:
            (commit if resp.status_code < 400 else rollback)(db)
        resp.headers.setdefault("Content-Security-Policy", CSP)
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        resp.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        if cfg.COOKIE_SECURE:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        from flask import request
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.teardown_appcontext
    def close(_exc):
        from flask import g
        db = g.pop("db", None)
        if db is not None:
            rollback(db)
            db.close()

    @app.errorhandler(ApiError)
    def api_error(e):
        db = get_db()
        rollback(db)      # refusals call commit() first when they need their audit row kept
        return jsonify({"error": e.message, **e.extra}), e.status

    @app.errorhandler(HTTPException)
    def http_error(e):
        return jsonify({"error": e.description if e.code != 413 else "Upload too large"}), e.code

    @app.errorhandler(Exception)
    def unexpected(e):
        app.logger.exception("unhandled error")
        try:
            db = get_db()
            rollback(db)
            audit.log(db, "system.error", outcome="error", error=type(e).__name__)
            commit(db)
        except Exception:
            pass
        return jsonify({"error": "Internal error"}), 500       # never leak internals

    return app
