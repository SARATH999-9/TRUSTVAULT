import json
import re

from flask import Blueprint, current_app, jsonify, request

from .. import audit
from ..config import ROLES
from ..db import begin_write, commit, get_db, now
from ..security import (ApiError, api, current_user, hash_password, json_body, revoke_user_sessions,
                        validate_new_password)
from ..util import iso, like_escape, user_public
from .docs import apply_grant  # noqa: F401  (admins cannot grant; imported only to make that explicit in tests)

bp = Blueprint("admin", __name__, url_prefix="/api/admin")
ADMIN = ("admin",)


def _audit_json(r, admin=True):
    d = {"seq": r["seq"], "ts": iso(r["ts"]), "actor": r["actor_name"], "actor_id": r["actor_id"],
         "action": r["action"], "outcome": r["outcome"], "doc_id": r["doc_id"],
         "target_user_id": r["target_user_id"], "detail": json.loads(r["detail"] or "{}")}
    if admin:
        d["ip"], d["user_agent"] = r["ip"], r["user_agent"]
    return d


@bp.get("/audit")
@api(roles=ADMIN)
def audit_list():
    db, a = get_db(), request.args
    where, p = [], []
    for col, key in (("action", "action"), ("outcome", "outcome"), ("doc_id", "doc_id")):
        if a.get(key):
            where.append(f"{col} = ?")
            p.append(a[key][:64])
    if a.get("prefix"):
        where.append("action LIKE ? ESCAPE '\\'")
        p.append(like_escape(a["prefix"][:32]) + "%")
    if a.get("actor"):
        where.append("actor_name LIKE ? ESCAPE '\\'")
        p.append("%" + like_escape(a["actor"][:64]) + "%")
    if a.get("before"):
        try:
            where.append("seq < ?")
            p.append(int(a["before"]))
        except ValueError:
            raise ApiError(400, "before must be an integer")
    try:
        limit = max(1, min(int(a.get("limit", 100)), 500))
    except ValueError:
        raise ApiError(400, "limit must be an integer")
    sql = "SELECT * FROM audit_log" + (" WHERE " + " AND ".join(where) if where else "") + f" ORDER BY seq DESC LIMIT {limit}"
    return jsonify({"events": [_audit_json(r) for r in db.execute(sql, p)]})


@bp.get("/audit/verify")
@api(roles=ADMIN)
def audit_verify():
    db, user = get_db(), current_user()
    res = audit.verify(db, current_app.config["TV"].AUDIT_KEY, current_app.config["TV"].AUDIT_FILE)
    audit.log(db, "audit.verify", actor=user, ok=res["ok"], rows=res["count"])
    return jsonify(res)


@bp.get("/audit/anchor")
@api(roles=ADMIN)
def audit_anchor():
    """Head hash + row count. Copy this somewhere the app cannot write (ticket,
    email, WORM bucket). A later verify that disagrees proves tail truncation."""
    db = get_db()
    r = db.execute("SELECT seq, hash, ts FROM audit_log ORDER BY seq DESC LIMIT 1").fetchone()
    return jsonify({"seq": r["seq"], "hash": r["hash"], "at": iso(r["ts"])})


@bp.get("/documents")
@api(roles=ADMIN)
def documents_meta():
    """Metadata only. There is no admin route that returns document content."""
    db = get_db()
    rows = db.execute("""
        SELECT d.id, d.name, d.category, d.created_at, d.updated_at, d.deleted_at, d.current_version,
               u.display_name AS owner, v.size,
               (SELECT COUNT(*) FROM grants g WHERE g.document_id=d.id AND g.revoked_at IS NULL
                  AND (g.expires_at IS NULL OR g.expires_at > ?)) AS active_grants,
               (SELECT MAX(ts) FROM audit_log a WHERE a.doc_id=d.id AND a.action='doc.download' AND a.outcome='ok') AS last_download,
               (SELECT COUNT(*) FROM audit_log a WHERE a.doc_id=d.id AND a.outcome='denied') AS denials
        FROM documents d JOIN users u ON u.id=d.owner_id
        JOIN document_versions v ON v.document_id=d.id AND v.version=d.current_version
        ORDER BY d.updated_at DESC LIMIT 500""", (now(),)).fetchall()
    return jsonify({"documents": [{**{k: r[k] for k in ("id", "name", "category", "owner", "size", "active_grants",
                                                          "denials", "current_version")},
                                   "created_at": iso(r["created_at"]), "updated_at": iso(r["updated_at"]),
                                   "deleted": r["deleted_at"] is not None, "last_download": iso(r["last_download"])}
                                  for r in rows]})


@bp.get("/grants")
@api(roles=ADMIN)
def grants_overview():
    db = get_db()
    rows = db.execute("""SELECT g.id, g.permission, g.granted_at, g.expires_at, d.id AS doc_id, d.name AS doc_name,
                                u.display_name AS grantee, b.display_name AS granted_by
                         FROM grants g JOIN documents d ON d.id=g.document_id JOIN users u ON u.id=g.user_id
                         JOIN users b ON b.id=g.granted_by
                         WHERE g.revoked_at IS NULL AND (g.expires_at IS NULL OR g.expires_at > ?)
                         ORDER BY g.granted_at DESC LIMIT 500""", (now(),)).fetchall()
    return jsonify({"grants": [{**{k: r[k] for k in ("id", "permission", "doc_id", "doc_name", "grantee", "granted_by")},
                                "granted_at": iso(r["granted_at"]), "expires_at": iso(r["expires_at"])} for r in rows]})


@bp.delete("/grants/<int:grant_id>")
@api(roles=ADMIN)
def admin_revoke(grant_id):
    """Emergency brake. Admins can only *remove* access, never add it."""
    db, user = get_db(), current_user()
    begin_write(db)
    g = db.execute("SELECT * FROM grants WHERE id=? AND revoked_at IS NULL", (grant_id,)).fetchone()
    if not g:
        raise ApiError(404, "No such active grant")
    db.execute("UPDATE grants SET revoked_at=?, revoked_by=? WHERE id=?", (now(), user["id"], grant_id))
    d = db.execute("SELECT name FROM documents WHERE id=?", (g["document_id"],)).fetchone()
    audit.log(db, "grant.revoke", actor=user, doc_id=g["document_id"], target_user_id=g["user_id"],
              doc_name=d["name"] if d else None, by_admin=True, was=g["permission"])
    return jsonify({"ok": True})


# ---------------------------------------------------------------- users
def _user_row(u):
    return {**user_public(u), "active": bool(u["active"]), "created_at": iso(u["created_at"]),
            "locked": bool(u["locked_until"] and u["locked_until"] > now())}


@bp.get("/users")
@api(roles=ADMIN)
def users_list():
    return jsonify({"users": [_user_row(u) for u in get_db().execute("SELECT * FROM users ORDER BY username")]})


@bp.post("/users")
@api(roles=ADMIN)
def users_create():
    db, admin, b = get_db(), current_user(), json_body()
    username, display, role, pw = b.get("username"), b.get("display_name"), b.get("role"), b.get("password")
    if not isinstance(username, str) or not re.fullmatch(r"[A-Za-z0-9._-]{3,40}", username):
        raise ApiError(400, "username must be 3-40 characters: letters, digits, . _ -")
    if not isinstance(display, str) or not (1 <= len(display.strip()) <= 80):
        raise ApiError(400, "display_name is required (max 80 characters)")
    if role not in ROLES:
        raise ApiError(400, "role must be admin, owner or viewer")
    validate_new_password(pw, username)
    begin_write(db)
    if db.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
        raise ApiError(409, "That username is taken")
    cur = db.execute("INSERT INTO users(username,display_name,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                     (username, display.strip(), hash_password(pw), role, now()))
    audit.log(db, "user.create", actor=admin, target_user_id=cur.lastrowid, username=username, role=role)
    return jsonify({"id": cur.lastrowid}), 201


def _other_active_admins(db, exclude_id):
    return db.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1 AND id<>?", (exclude_id,)).fetchone()[0]


@bp.patch("/users/<int:uid>")
@api(roles=ADMIN)
def users_update(uid):
    db, admin, b = get_db(), current_user(), json_body()
    begin_write(db)
    u = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        raise ApiError(404, "No such user")
    sets, vals, detail = [], [], {}
    if "role" in b:
        if b["role"] not in ROLES:
            raise ApiError(400, "Invalid role")
        if u["role"] == "admin" and b["role"] != "admin" and _other_active_admins(db, uid) == 0:
            raise ApiError(409, "Cannot demote the last active administrator")
        sets.append("role=?"); vals.append(b["role"]); detail["role"] = [u["role"], b["role"]]
    if "active" in b:
        if not isinstance(b["active"], bool):
            raise ApiError(400, "active must be true or false")
        if not b["active"] and u["role"] == "admin" and _other_active_admins(db, uid) == 0:
            raise ApiError(409, "Cannot disable the last active administrator")
        sets.append("active=?"); vals.append(int(b["active"])); detail["active"] = [bool(u["active"]), b["active"]]
    if "display_name" in b:
        if not isinstance(b["display_name"], str) or not (1 <= len(b["display_name"].strip()) <= 80):
            raise ApiError(400, "display_name is required (max 80 characters)")
        sets.append("display_name=?"); vals.append(b["display_name"].strip())
    if not sets:
        raise ApiError(400, "Nothing to change")
    db.execute(f"UPDATE users SET {', '.join(sets)} WHERE id=?", (*vals, uid))
    if "active" in b and not b["active"]:
        revoke_user_sessions(db, uid)                 # logged out everywhere, this instant
        audit.log(db, "user.disable", actor=admin, target_user_id=uid, username=u["username"])
    elif "active" in b:
        audit.log(db, "user.enable", actor=admin, target_user_id=uid, username=u["username"])
    if "role" in b:
        audit.log(db, "user.role_change", actor=admin, target_user_id=uid, username=u["username"], change=detail["role"])
    return jsonify({"ok": True})


@bp.post("/users/<int:uid>/password")
@api(roles=ADMIN)
def users_reset_password(uid):
    db, admin, b = get_db(), current_user(), json_body()
    u = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        raise ApiError(404, "No such user")
    validate_new_password(b.get("password"), u["username"])
    begin_write(db)
    db.execute("UPDATE users SET password_hash=?, failed_logins=0, locked_until=NULL WHERE id=?",
               (hash_password(b["password"]), uid))
    revoke_user_sessions(db, uid)
    audit.log(db, "user.password_reset", actor=admin, target_user_id=uid, username=u["username"])
    return jsonify({"ok": True})


@bp.post("/users/<int:uid>/revoke-sessions")
@api(roles=ADMIN)
def users_revoke_sessions(uid):
    db, admin = get_db(), current_user()
    u = db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        raise ApiError(404, "No such user")
    revoke_user_sessions(db, uid)
    audit.log(db, "session.revoked", actor=admin, target_user_id=uid, username=u["username"])
    return jsonify({"ok": True})


# ---------------------------------------------------------------- what is worth noticing
def compute_alerts(db, window=600):
    t = now() - window
    alerts = []

    def q(sql, *p):
        return db.execute(sql, p).fetchall()

    for r in q("SELECT actor_name, COUNT(*) n FROM audit_log WHERE action='access.denied' AND ts>? "
               "GROUP BY actor_id, actor_name HAVING n>=5", t):
        alerts.append({"severity": "high", "kind": "repeated_denials",
                       "message": f"{r['actor_name']} was refused access {r['n']} times in 10 minutes (probing?)"})
    for r in q("SELECT actor_name, COUNT(*) n FROM audit_log WHERE action='doc.download' AND outcome='ok' AND ts>? "
               "GROUP BY actor_id, actor_name HAVING n>=10", t):
        alerts.append({"severity": "high", "kind": "bulk_download",
                       "message": f"{r['actor_name']} downloaded {r['n']} documents in 10 minutes"})
    for r in q("SELECT actor_name, COUNT(*) n FROM audit_log WHERE action='auth.login_failed' AND ts>? "
               "GROUP BY actor_name HAVING n>=5", t):
        alerts.append({"severity": "medium", "kind": "login_failures",
                       "message": f"{r['n']} failed logins for '{r['actor_name']}' in 10 minutes"})
    for r in q("""SELECT a.actor_name, a.doc_id, COUNT(*) n, MAX(a.ts) last
                  FROM audit_log a JOIN grants g ON g.document_id=a.doc_id AND g.user_id=a.actor_id AND g.revoked_at IS NOT NULL
                  WHERE a.action='access.denied' AND a.ts>? AND a.ts>g.revoked_at
                  GROUP BY a.actor_id, a.doc_id""", now() - 86400):
        alerts.append({"severity": "high", "kind": "revoked_user_retry", "doc_id": r["doc_id"],
                       "message": f"{r['actor_name']} tried {r['n']} time(s) to open a document after their access was revoked"})
    for r in q("SELECT actor_name, COUNT(*) n FROM audit_log WHERE action='grant.add' AND ts>? GROUP BY actor_id, actor_name HAVING n>=5", t):
        alerts.append({"severity": "medium", "kind": "grant_burst",
                       "message": f"{r['actor_name']} created {r['n']} grants in 10 minutes"})
    for r in q("SELECT action, actor_name, detail, ts FROM audit_log WHERE action IN "
               "('user.role_change','user.disable','user.password_reset','session.revoked','auth.lockout') AND ts>? ORDER BY seq DESC LIMIT 20", now() - 86400):
        alerts.append({"severity": "info", "kind": r["action"], "at": iso(r["ts"]),
                       "message": f"{r['action']} by {r['actor_name'] or 'system'} - {r['detail']}"})
    return alerts


@bp.get("/alerts")
@api(roles=ADMIN)
def alerts():
    db = get_db()
    verify = audit.verify(db, current_app.config["TV"].AUDIT_KEY, current_app.config["TV"].AUDIT_FILE)
    out = compute_alerts(db)
    if not verify["ok"]:
        out.insert(0, {"severity": "critical", "kind": "audit_chain_broken",
                       "message": "AUDIT TRAIL INTEGRITY FAILURE: " + "; ".join(verify["problems"][:3])})
    return jsonify({"alerts": out})


@bp.get("/stats")
@api(roles=ADMIN)
def stats():
    db, d = get_db(), now() - 86400
    c = lambda sql, *p: db.execute(sql, p).fetchone()[0]
    return jsonify({
        "documents": c("SELECT COUNT(*) FROM documents WHERE deleted_at IS NULL"),
        "users": c("SELECT COUNT(*) FROM users WHERE active=1"),
        "downloads_24h": c("SELECT COUNT(*) FROM audit_log WHERE action='doc.download' AND outcome='ok' AND ts>?", d),
        "denials_24h": c("SELECT COUNT(*) FROM audit_log WHERE outcome='denied' AND ts>?", d),
        "permission_changes_24h": c("SELECT COUNT(*) FROM audit_log WHERE action LIKE 'grant.%' AND ts>?", d),
        "audit_rows": c("SELECT COUNT(*) FROM audit_log"),
    })
