"""Live updates over Server-Sent Events.

Every tick the stream re-validates the session against the database and reads
new audit rows. If the session was revoked or the account disabled, the stream
ends immediately. Polling the DB (instead of in-process pub/sub) keeps this
correct with several worker processes.
"""
import json
import time

from flask import Blueprint, Response, current_app, request

from ..db import connect
from ..security import api, current_user, lookup_session, COOKIE
from ..util import iso

bp = Blueprint("events", __name__, url_prefix="/api")


LIMIT = 500


def head_seq(conn):
    r = conn.execute("SELECT MAX(seq) FROM audit_log").fetchone()
    return r[0] or 0


def visible_events(conn, user, after_seq, upto):
    """Events with after_seq < seq <= upto that this user may see, plus the new cursor."""
    if user["role"] == "admin":
        rows = conn.execute("SELECT * FROM audit_log WHERE seq>? AND seq<=? ORDER BY seq LIMIT ?",
                            (after_seq, upto, LIMIT)).fetchall()
        admin = True
    else:
        # Non-admins only learn about (a) grant changes aimed at them, (b) activity on documents
        # they own and (c) their own document actions.
        rows = conn.execute(
            """SELECT * FROM audit_log WHERE seq>? AND seq<=? AND (
                 (target_user_id=? AND action LIKE 'grant.%')
                 OR doc_id IN (SELECT id FROM documents WHERE owner_id=?)
                 OR (actor_id=? AND action LIKE 'doc.%')) ORDER BY seq LIMIT ?""",
            (after_seq, upto, user["id"], user["id"], user["id"], LIMIT)).fetchall()
        admin = False
    out = []
    for r in rows:
        d = json.loads(r["detail"] or "{}")
        ev = {"seq": r["seq"], "ts": iso(r["ts"]), "action": r["action"], "outcome": r["outcome"],
              "doc_id": r["doc_id"], "actor": r["actor_name"], "target_user_id": r["target_user_id"],
              "doc_name": d.get("doc_name")}
        if admin:
            ev["ip"] = r["ip"]
        out.append(ev)
    cursor = rows[-1]["seq"] if len(rows) == LIMIT else upto
    return out, cursor


def stream(cfg, token, start_seq, max_ticks=None, sleep=1.0):
    conn = connect(cfg.DB_PATH)
    last, ticks, last_beat = start_seq, 0, time.time()
    try:
        yield "retry: 3000\n\n"
        while max_ticks is None or ticks < max_ticks:
            ticks += 1
            user = lookup_session(conn, token, cfg, touch=False)
            if not user:
                yield "event: session_ended\ndata: {}\n\n"
                return
            head = head_seq(conn)            # read head first, then rows up to it: nothing is skipped
            events, last = visible_events(conn, user, last, head)
            for e in events:
                yield f"id: {e['seq']}\nevent: audit\ndata: {json.dumps(e)}\n\n"
            if time.time() - last_beat > 15:
                last_beat = time.time()
                yield ": heartbeat\n\n"
            if sleep:
                time.sleep(sleep)
    finally:
        conn.close()


@bp.get("/events")
@api()
def events():
    cfg = current_app.config["TV"]
    user = current_user()
    conn = connect(cfg.DB_PATH)
    try:
        start = head_seq(conn)
    finally:
        conn.close()
    max_ticks = 2 if cfg.TESTING else None
    resp = Response(stream(cfg, request.cookies.get(COOKIE), start, max_ticks, 0 if cfg.TESTING else 1.0),
                    mimetype="text/event-stream")
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["X-Accel-Buffering"] = "no"
    return resp
