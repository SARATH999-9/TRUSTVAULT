from flask import Blueprint, current_app, jsonify, request

from .. import audit
from ..db import begin_write, commit, get_db, now
from ..security import (ApiError, api, check_password, create_session, current_user, hash_password,
                        ip_throttled, json_body, lookup_session, revoke_user_sessions, set_cookie,
                        validate_new_password, COOKIE, _h)
from ..util import user_public

bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@bp.post("/login")
@api(public=True)
def login():
    cfg, db = current_app.config["TV"], get_db()
    body = json_body()
    username, password = body.get("username"), body.get("password")
    if not isinstance(username, str) or not isinstance(password, str) or not username or len(password) > 200:
        raise ApiError(400, "username and password are required")
    username = username[:64]
    if ip_throttled(cfg):
        raise ApiError(429, "Too many login attempts from this address. Try again in a minute.")
    user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    locked = bool(user and user["locked_until"] and user["locked_until"] > now())
    ok = check_password(user, password) and user["active"] and not locked
    if not ok:
        begin_write(db)
        reason = "locked" if locked else ("disabled" if user and not user["active"] else "bad_credentials")
        if user and not locked and user["active"]:
            fails = user["failed_logins"] + 1
            lock = now() + cfg.LOGIN_LOCK_SECONDS if fails >= cfg.LOGIN_MAX_FAILS else None
            db.execute("UPDATE users SET failed_logins=?, locked_until=? WHERE id=?",
                       (0 if lock else fails, lock, user["id"]))
            if lock:
                audit.log(db, "auth.lockout", actor=user, outcome="denied", target_user_id=user["id"])
        audit.log(db, "auth.login_failed", outcome="denied", attempted_username=username[:64], reason=reason)
        commit(db)
        # One message for every failure mode: no user enumeration.
        raise ApiError(401, "Invalid credentials, or the account is temporarily locked")
    begin_write(db)
    db.execute("UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=?", (user["id"],))
    token, csrf = create_session(db, user)      # fresh token on every login: no session fixation
    audit.log(db, "auth.login", actor=user)
    commit(db)
    resp = jsonify({"user": user_public(user), "csrf": csrf})
    set_cookie(resp, token)
    return resp


@bp.post("/logout")
@api()
def logout():
    db, user = get_db(), current_user()
    begin_write(db)
    db.execute("DELETE FROM sessions WHERE id_hash=?", (user["id_hash"],))
    audit.log(db, "auth.logout", actor=user)
    resp = jsonify({"ok": True})
    resp.delete_cookie(COOKIE, path="/")
    return resp


@bp.get("/me")
@api()
def me():
    u = current_user()
    return jsonify({"user": user_public(u), "csrf": u["csrf"]})


@bp.post("/password")
@api()
def change_password():
    db, user, body = get_db(), current_user(), json_body()
    cur, new = body.get("current"), body.get("new")
    if not isinstance(cur, str) or not check_password(user, cur):
        audit.log(db, "auth.password_change", actor=user, outcome="denied", reason="wrong_current")
        commit(db)
        raise ApiError(403, "Current password is incorrect")
    validate_new_password(new, user["username"])
    begin_write(db)
    db.execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(new), user["id"]))
    revoke_user_sessions(db, user["id"], except_hash=user["id_hash"])   # everything else dies now
    audit.log(db, "auth.password_change", actor=user)
    return jsonify({"ok": True})
