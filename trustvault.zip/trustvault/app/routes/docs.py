import hashlib
import io
import json
import uuid

from flask import Blueprint, current_app, jsonify, request, send_file

from .. import audit, authz, suggest
from ..config import CATEGORIES
from ..db import begin_write, commit, get_db, now
from ..security import ApiError, api, current_user, json_body
from ..storage import BlobStore, StorageError
from ..util import iso, like_escape, parse_when, end_of_day, user_public
from ..validation import ValidationError, clean_filename, clean_text, sniff_and_validate

bp = Blueprint("docs", __name__, url_prefix="/api")


def store():
    cfg = current_app.config["TV"]
    return BlobStore(cfg.BLOB_DIR, cfg.STORAGE_KEY)


def _aad(doc_id, version):
    return f"{doc_id}:{version}"


def _doc_json(r, my_perm):
    return {"id": r["id"], "name": r["name"], "description": r["description"], "category": r["category"],
            "owner": {"id": r["owner_id"], "name": r["owner_name"], "username": r["owner_username"]},
            "version": r["current_version"], "created_at": iso(r["created_at"]),
            "updated_at": iso(r["updated_at"]), "my_permission": my_perm,
            "deleted_at": iso(r["deleted_at"])}


def _read_upload():
    cfg = current_app.config["TV"]
    f = request.files.get("file")
    if f is None:
        raise ApiError(400, "No file was uploaded (multipart field 'file')")
    data = f.read(cfg.MAX_UPLOAD_BYTES + 1)
    if len(data) > cfg.MAX_UPLOAD_BYTES:
        raise ApiError(413, f"File exceeds the {cfg.MAX_UPLOAD_BYTES // (1024 * 1024)} MB limit")
    try:
        filename = clean_filename(f.filename)
        ext, mime = sniff_and_validate(filename, data)
    except ValidationError as e:
        raise ApiError(400, str(e))
    return filename, data, mime


# ---------------------------------------------------------------- people picker (owners choose who to share with)
@bp.get("/directory")
@api(roles=("owner",))
def directory():
    """Name + role of active non-admin users. Needed so an owner can pick a grantee. Internal-directory
    enumeration by owners is an accepted trade-off (THREATS.md T-45)."""
    db, user = get_db(), current_user()
    q = "%" + like_escape(request.args.get("q", "")[:64]) + "%"
    rows = db.execute("SELECT id, username, display_name, role FROM users WHERE active=1 AND role<>'admin' AND id<>? "
                      "AND (username LIKE ? ESCAPE '\\' OR display_name LIKE ? ESCAPE '\\') ORDER BY display_name LIMIT 50",
                      (user["id"], q, q)).fetchall()
    return jsonify({"users": [user_public(r) for r in rows]})


# ---------------------------------------------------------------- list / search
@bp.get("/documents")
@api(roles=("owner", "viewer"))
def list_documents():
    """Only rows the caller owns or holds a live grant on. The SQL mirrors
    authz.permissions(); tests assert the two never disagree."""
    db, user = get_db(), current_user()
    a = request.args
    trash = a.get("trash") == "1"
    where, params = [], {"uid": user["id"], "now": now()}
    if trash:
        if user["role"] != "owner":
            raise ApiError(403, "Only owners have a trash")
        where.append("d.owner_id=:uid AND d.deleted_at IS NOT NULL")
    else:
        where.append("d.deleted_at IS NULL")
        scope = a.get("scope", "all")
        if user["role"] == "owner":
            if scope == "mine":
                where.append("d.owner_id=:uid")
            elif scope == "shared":
                where.append("d.owner_id<>:uid AND g.id IS NOT NULL")
            else:
                where.append("(d.owner_id=:uid OR g.id IS NOT NULL)")
        else:
            where.append("g.id IS NOT NULL")
    if a.get("q"):
        params["q"] = "%" + like_escape(a["q"][:100]) + "%"
        where.append("(d.name LIKE :q ESCAPE '\\' OR d.description LIKE :q ESCAPE '\\')")
    if a.get("category"):
        if a["category"] not in CATEGORIES:
            raise ApiError(400, "Unknown category")
        params["cat"] = a["category"]
        where.append("d.category=:cat")
    if a.get("owner"):
        params["own"] = "%" + like_escape(a["owner"][:64]) + "%"
        where.append("(u.username LIKE :own ESCAPE '\\' OR u.display_name LIKE :own ESCAPE '\\')")
    df, dt = parse_when(a.get("date_from"), "date_from"), parse_when(a.get("date_to"), "date_to")
    if df is not None:
        params["df"] = df
        where.append("d.created_at >= :df")
    if dt is not None:
        params["dt"] = end_of_day(dt)
        where.append("d.created_at <= :dt")
    try:
        limit = max(1, min(int(a.get("limit", 100)), 200))
        offset = max(0, int(a.get("offset", 0)))
    except ValueError:
        raise ApiError(400, "limit/offset must be integers")
    sql = f"""SELECT d.*, u.display_name AS owner_name, u.username AS owner_username, g.permission AS gperm
              FROM documents d JOIN users u ON u.id = d.owner_id
              LEFT JOIN grants g ON g.document_id = d.id AND g.user_id = :uid AND g.revoked_at IS NULL
                                    AND (g.expires_at IS NULL OR g.expires_at > :now)
              WHERE {' AND '.join(where)} ORDER BY d.updated_at DESC LIMIT {limit} OFFSET {offset}"""
    rows = db.execute(sql, params).fetchall()
    out = []
    for r in rows:
        if r["owner_id"] == user["id"]:
            perm = "owner"
        else:
            perm = "edit" if (r["gperm"] == "edit" and user["role"] == "owner") else "read"
        out.append(_doc_json(r, perm))
    return jsonify({"documents": out, "categories": CATEGORIES})


# ---------------------------------------------------------------- create
@bp.post("/documents")
@api(roles=("owner",))
def upload():
    db, user = get_db(), current_user()
    filename, data, mime = _read_upload()
    try:
        name = clean_text(request.form.get("name") or filename, "Name", 150)
        desc = clean_text(request.form.get("description"), "Description", 1000, required=False)
    except ValidationError as e:
        raise ApiError(400, str(e))
    category = request.form.get("category", "Other")
    if category not in CATEGORIES:
        raise ApiError(400, "Unknown category")
    doc_id, ver_id, t = uuid.uuid4().hex, uuid.uuid4().hex, now()
    sha = hashlib.sha256(data).hexdigest()
    blob = store().put(data, _aad(doc_id, 1))
    try:
        begin_write(db)
        db.execute("INSERT INTO documents(id,name,description,category,owner_id,created_at,updated_at) "
                   "VALUES(?,?,?,?,?,?,?)", (doc_id, name, desc, category, user["id"], t, t))
        db.execute("INSERT INTO document_versions(id,document_id,version,blob_name,size,sha256,mime,"
                   "original_filename,uploaded_by,uploaded_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                   (ver_id, doc_id, 1, blob, len(data), sha, mime, filename, user["id"], t))
        audit.log(db, "doc.upload", actor=user, doc_id=doc_id, doc_name=name, filename=filename,
                  size=len(data), sha256=sha, category=category)
    except Exception:
        store().delete(blob)
        raise
    return jsonify({"id": doc_id}), 201


# ---------------------------------------------------------------- read
def _version_rows(db, doc_id):
    return db.execute("""SELECT v.version, v.size, v.sha256, v.mime, v.original_filename, v.uploaded_at,
                                u.display_name AS uploader
                         FROM document_versions v JOIN users u ON u.id=v.uploaded_by
                         WHERE v.document_id=? ORDER BY v.version DESC""", (doc_id,)).fetchall()


@bp.get("/documents/<doc_id>")
@api(roles=("owner", "viewer"))
def get_document(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "read")
    perms = authz.permissions(db, user, doc)
    owner = db.execute("SELECT display_name, username FROM users WHERE id=?", (doc["owner_id"],)).fetchone()
    row = dict(doc, owner_name=owner["display_name"], owner_username=owner["username"])
    audit.log(db, "doc.view", actor=user, doc_id=doc["id"], doc_name=doc["name"])
    out = _doc_json(row, "owner" if "manage" in perms else ("edit" if "edit" in perms else "read"))
    out["can"] = {"edit": "edit" in perms, "manage": "manage" in perms}
    out["versions"] = [{"version": v["version"], "size": v["size"], "sha256": v["sha256"], "mime": v["mime"],
                        "filename": v["original_filename"], "uploaded_at": iso(v["uploaded_at"]),
                        "uploaded_by": v["uploader"]} for v in _version_rows(db, doc["id"])]
    return jsonify(out)


@bp.get("/documents/<doc_id>/download")
@api(roles=("owner", "viewer"))
def download(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "read")
    try:
        ver = int(request.args.get("version", doc["current_version"]))
    except ValueError:
        raise ApiError(400, "version must be an integer")
    v = db.execute("SELECT * FROM document_versions WHERE document_id=? AND version=?", (doc["id"], ver)).fetchone()
    if not v:
        raise ApiError(404, "Version not found")
    try:
        data = store().get(v["blob_name"], _aad(doc["id"], v["version"]))
    except StorageError:
        audit.log(db, "doc.download", actor=user, outcome="error", doc_id=doc["id"], version=ver, reason="integrity")
        commit(db)
        raise ApiError(500, "Stored file failed its integrity check")
    if hashlib.sha256(data).hexdigest() != v["sha256"]:
        audit.log(db, "doc.download", actor=user, outcome="error", doc_id=doc["id"], version=ver, reason="hash_mismatch")
        commit(db)
        raise ApiError(500, "Stored file failed its integrity check")
    # Audit first, commit, THEN release bytes: no unrecorded read can happen.
    audit.log(db, "doc.download", actor=user, doc_id=doc["id"], doc_name=doc["name"], version=ver,
              size=v["size"], sha256=v["sha256"])
    commit(db)
    resp = send_file(io.BytesIO(data), mimetype="application/octet-stream", as_attachment=True,
                     download_name=v["original_filename"], max_age=0, conditional=False)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["Content-Security-Policy"] = "sandbox; default-src 'none'"
    return resp


# ---------------------------------------------------------------- change
@bp.patch("/documents/<doc_id>")
@api(roles=("owner", "viewer"))
def update_meta(doc_id):
    db, user, body = get_db(), current_user(), json_body()
    doc = authz.load_doc(db, doc_id, user, "edit")
    changes = {}
    try:
        if "name" in body:
            changes["name"] = clean_text(body["name"], "Name", 150)
        if "description" in body:
            changes["description"] = clean_text(body["description"], "Description", 1000, required=False)
    except ValidationError as e:
        raise ApiError(400, str(e))
    if "category" in body:
        if body["category"] not in CATEGORIES:
            raise ApiError(400, "Unknown category")
        changes["category"] = body["category"]
    if not changes:
        raise ApiError(400, "Nothing to change")
    # Allow-listed columns only (no mass assignment of owner_id, deleted_at, ...).
    begin_write(db)
    sets = ", ".join(f"{k}=?" for k in changes)
    db.execute(f"UPDATE documents SET {sets}, updated_at=? WHERE id=?", (*changes.values(), now(), doc["id"]))
    audit.log(db, "doc.update", actor=user, doc_id=doc["id"], doc_name=doc["name"],
              before={k: doc[k] for k in changes}, after=changes)
    return jsonify({"ok": True})


@bp.post("/documents/<doc_id>/versions")
@api(roles=("owner", "viewer"))
def new_version(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "edit")
    filename, data, mime = _read_upload()
    ver = doc["current_version"] + 1
    sha, t = hashlib.sha256(data).hexdigest(), now()
    blob = store().put(data, _aad(doc["id"], ver))
    try:
        begin_write(db)
        db.execute("INSERT INTO document_versions(id,document_id,version,blob_name,size,sha256,mime,"
                   "original_filename,uploaded_by,uploaded_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                   (uuid.uuid4().hex, doc["id"], ver, blob, len(data), sha, mime, filename, user["id"], t))
        db.execute("UPDATE documents SET current_version=?, updated_at=? WHERE id=?", (ver, t, doc["id"]))
        audit.log(db, "doc.new_version", actor=user, doc_id=doc["id"], doc_name=doc["name"], version=ver,
                  filename=filename, size=len(data), sha256=sha)
    except Exception:
        store().delete(blob)
        raise
    return jsonify({"version": ver}), 201


@bp.delete("/documents/<doc_id>")
@api(roles=("owner",))
def delete_document(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    if doc["deleted_at"]:
        raise ApiError(409, "Already in the trash")
    begin_write(db)
    db.execute("UPDATE documents SET deleted_at=?, deleted_by=? WHERE id=?", (now(), user["id"], doc["id"]))
    audit.log(db, "doc.delete", actor=user, doc_id=doc["id"], doc_name=doc["name"])
    return jsonify({"ok": True})


@bp.post("/documents/<doc_id>/restore")
@api(roles=("owner",))
def restore_document(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    if not doc["deleted_at"]:
        raise ApiError(409, "Document is not in the trash")
    begin_write(db)
    db.execute("UPDATE documents SET deleted_at=NULL, deleted_by=NULL WHERE id=?", (doc["id"],))
    audit.log(db, "doc.restore", actor=user, doc_id=doc["id"], doc_name=doc["name"])
    return jsonify({"ok": True})


def purge(db, doc, actor, **why):
    blobs = [r["blob_name"] for r in db.execute("SELECT blob_name FROM document_versions WHERE document_id=?", (doc["id"],))]
    begin_write(db)
    audit.log(db, "doc.purge", actor=actor, doc_id=doc["id"], doc_name=doc["name"], versions=len(blobs), **why)
    db.execute("DELETE FROM documents WHERE id=?", (doc["id"],))   # cascades versions, grants, suggestions
    commit(db)
    s = store()
    for b in blobs:
        s.delete(b)


@bp.delete("/documents/<doc_id>/purge")
@api(roles=("owner",))
def purge_document(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    if not doc["deleted_at"]:
        raise ApiError(409, "Move the document to the trash before purging it")
    purge(db, doc, user)
    return jsonify({"ok": True})


# ---------------------------------------------------------------- sharing
def _grant_json(g):
    return {"id": g["id"], "user": {"id": g["user_id"], "username": g["username"], "display_name": g["display_name"],
                                    "role": g["role"]},
            "permission": g["permission"], "granted_at": iso(g["granted_at"]), "expires_at": iso(g["expires_at"]),
            "revoked_at": iso(g["revoked_at"]), "granted_by": g["granted_by_name"],
            "via_suggestion": g["suggestion_id"] is not None}


@bp.get("/documents/<doc_id>/grants")
@api(roles=("owner",))
def list_grants(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    rows = db.execute("""SELECT g.*, u.username, u.display_name, u.role, b.display_name AS granted_by_name
                         FROM grants g JOIN users u ON u.id=g.user_id JOIN users b ON b.id=g.granted_by
                         WHERE g.document_id=? ORDER BY g.revoked_at IS NOT NULL, g.granted_at DESC""",
                      (doc["id"],)).fetchall()
    t, active, history = now(), [], []
    for g in rows:
        live = g["revoked_at"] is None and (g["expires_at"] is None or g["expires_at"] > t)
        (active if live else history).append(_grant_json(g))
    history = history[:20]
    return jsonify({"active": active, "history": history})


def apply_grant(db, doc, owner, target_id, permission, expires_at, suggestion_id=None):
    if permission not in ("read", "edit"):
        raise ApiError(400, "permission must be 'read' or 'edit'")
    if not isinstance(target_id, int) or isinstance(target_id, bool):
        raise ApiError(400, "user_id must be an integer")
    target = db.execute("SELECT * FROM users WHERE id=? AND active=1", (target_id,)).fetchone()
    if not target or target["role"] == "admin":
        raise ApiError(400, "That person cannot be granted access")     # same answer for unknown/disabled/admin
    if target["id"] == owner["id"]:
        raise ApiError(400, "You already own this document")
    if permission == "edit" and target["role"] != "owner":
        raise ApiError(400, "Viewers are read-only; give them 'read' or change their role first")
    begin_write(db)
    existing = db.execute("SELECT * FROM grants WHERE document_id=? AND user_id=? AND revoked_at IS NULL",
                          (doc["id"], target_id)).fetchone()
    if existing:
        db.execute("UPDATE grants SET permission=?, expires_at=? WHERE id=?", (permission, expires_at, existing["id"]))
        audit.log(db, "grant.update", actor=owner, doc_id=doc["id"], target_user_id=target_id, doc_name=doc["name"],
                  target=target["username"], before=existing["permission"], after=permission,
                  expires_at=iso(expires_at), suggestion_id=suggestion_id)
    else:
        db.execute("INSERT INTO grants(document_id,user_id,permission,granted_by,granted_at,expires_at,suggestion_id)"
                   " VALUES(?,?,?,?,?,?,?)", (doc["id"], target_id, permission, owner["id"], now(), expires_at, suggestion_id))
        audit.log(db, "grant.add", actor=owner, doc_id=doc["id"], target_user_id=target_id, doc_name=doc["name"],
                  target=target["username"], permission=permission, expires_at=iso(expires_at),
                  via_suggestion=suggestion_id is not None, suggestion_id=suggestion_id)


@bp.put("/documents/<doc_id>/grants")
@api(roles=("owner",))
def put_grant(doc_id):
    db, user, body = get_db(), current_user(), json_body()
    doc = authz.load_doc(db, doc_id, user, "manage")
    exp = parse_when(body.get("expires_at"), "expires_at", future=True)
    apply_grant(db, doc, user, body.get("user_id"), body.get("permission"), exp)
    return jsonify({"ok": True})


@bp.delete("/documents/<doc_id>/grants/<int:target_id>")
@api(roles=("owner",))
def revoke_grant(doc_id, target_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    begin_write(db)
    g = db.execute("SELECT * FROM grants WHERE document_id=? AND user_id=? AND revoked_at IS NULL",
                   (doc["id"], target_id)).fetchone()
    if not g:
        raise ApiError(404, "No active grant for that person")
    db.execute("UPDATE grants SET revoked_at=?, revoked_by=? WHERE id=?", (now(), user["id"], g["id"]))
    t = db.execute("SELECT username FROM users WHERE id=?", (target_id,)).fetchone()
    audit.log(db, "grant.revoke", actor=user, doc_id=doc["id"], target_user_id=target_id, doc_name=doc["name"],
              target=t["username"] if t else None, was=g["permission"])
    return jsonify({"ok": True})


# ---------------------------------------------------------------- AI-assisted suggestions (advice only)
@bp.get("/documents/<doc_id>/suggestions")
@api(roles=("owner",))
def get_suggestions(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    items = suggest.generate(db, doc)
    begin_write(db)
    ids = suggest.persist(db, doc, items)
    audit.log(db, "suggestion.created", actor=user, doc_id=doc["id"], doc_name=doc["name"],
              suggested=[{"suggestion_id": i, "user_id": it["user_id"], "permission": it["permission"],
                          "score": it["score"]} for i, it in zip(ids, items)])
    names = {r["id"]: r for r in db.execute("SELECT id, username, display_name, role FROM users")}
    return jsonify({"suggestions": [
        {"id": i, "user": user_public(names[it["user_id"]]), "permission": it["permission"], "reason": it["reason"]}
        for i, it in zip(ids, items)],
        "note": "These are suggestions only. Nothing is shared until you accept one."})


def _open_suggestion(db, doc, sid):
    s = db.execute("SELECT * FROM suggestions WHERE id=? AND document_id=?", (sid, doc["id"])).fetchone()
    if not s:
        raise ApiError(404, "Suggestion not found")
    if s["state"] != "open":
        raise ApiError(409, f"Suggestion was already {s['state']}")
    return s


@bp.post("/documents/<doc_id>/suggestions/<int:sid>/accept")
@api(roles=("owner",))
def accept_suggestion(doc_id, sid):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    body = request.get_json(silent=True) or {}
    s = _open_suggestion(db, doc, sid)
    perm = body.get("permission", s["permission"])      # the human may choose; default is what was suggested
    exp = parse_when(body.get("expires_at"), "expires_at", future=True)
    apply_grant(db, doc, user, s["user_id"], perm, exp, suggestion_id=sid)
    db.execute("UPDATE suggestions SET state='accepted', decided_by=?, decided_at=? WHERE id=?", (user["id"], now(), sid))
    audit.log(db, "suggestion.accepted", actor=user, doc_id=doc["id"], target_user_id=s["user_id"], doc_name=doc["name"],
              suggestion_id=sid, suggested_permission=s["permission"], granted_permission=perm)
    return jsonify({"ok": True})


@bp.post("/documents/<doc_id>/suggestions/<int:sid>/dismiss")
@api(roles=("owner",))
def dismiss_suggestion(doc_id, sid):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    s = _open_suggestion(db, doc, sid)
    begin_write(db)
    db.execute("UPDATE suggestions SET state='dismissed', decided_by=?, decided_at=? WHERE id=?", (user["id"], now(), sid))
    audit.log(db, "suggestion.dismissed", actor=user, doc_id=doc["id"], target_user_id=s["user_id"],
              doc_name=doc["name"], suggestion_id=sid)
    return jsonify({"ok": True})


# ---------------------------------------------------------------- per-document audit (owner)
@bp.get("/documents/<doc_id>/audit")
@api(roles=("owner",))
def doc_audit(doc_id):
    db, user = get_db(), current_user()
    doc = authz.load_doc(db, doc_id, user, "manage")
    rows = db.execute("SELECT * FROM audit_log WHERE doc_id=? ORDER BY seq DESC LIMIT 200", (doc["id"],)).fetchall()
    return jsonify({"events": [{"seq": r["seq"], "ts": iso(r["ts"]), "actor": r["actor_name"], "action": r["action"],
                                "outcome": r["outcome"]} for r in rows]})
