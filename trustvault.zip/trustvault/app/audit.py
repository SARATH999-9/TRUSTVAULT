"""Tamper-evident audit trail.

Each row carries   hash = SHA256(prev_hash || canonical(row))   and
                   mac  = HMAC(AUDIT_KEY, hash).
* UPDATE/DELETE are blocked by SQLite triggers (schema.sql).
* Someone with raw file access who drops the triggers and edits a row breaks
  the hash chain; if they also recompute the chain they still cannot forge the
  MAC without AUDIT_KEY, which is not stored in the database.
* Rows are mirrored to an append-only JSONL file as a second sink.
* Known limit (THREATS.md T-19): truncating the *tail* of the log is only
  caught if the head hash was anchored elsewhere (/api/admin/audit/anchor).
"""
import hashlib
import hmac
import json

from flask import current_app, request, has_request_context

from .db import begin_write, now, queue_mirror

GENESIS = "0" * 64


def _canonical(d):
    return json.dumps(d, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _row_payload(seq, ts, actor_id, actor_name, action, outcome, doc_id, target_user_id, detail, ip, ua):
    return {"seq": seq, "ts": ts, "actor_id": actor_id, "actor_name": actor_name, "action": action,
            "outcome": outcome, "doc_id": doc_id, "target_user_id": target_user_id,
            "detail": detail, "ip": ip, "ua": ua}


def _hash(prev, payload):
    return hashlib.sha256((prev + _canonical(payload)).encode()).hexdigest()


def _mac(key, h):
    return hmac.new(key, h.encode(), hashlib.sha256).hexdigest()


def client_ip():
    # We deliberately trust only the socket address. If deployed behind a proxy,
    # configure the proxy to overwrite REMOTE_ADDR (documented in README).
    return request.remote_addr if has_request_context() else None


def log(db, action, *, actor=None, outcome="ok", doc_id=None, target_user_id=None, **detail):
    """Append one audit row inside the caller's transaction (so an action and
    its audit record commit or roll back together)."""
    cfg = current_app.config["TV"]
    begin_write(db)
    last = db.execute("SELECT seq, hash FROM audit_log ORDER BY seq DESC LIMIT 1").fetchone()
    seq = (last["seq"] + 1) if last else 1
    prev = last["hash"] if last else GENESIS
    ts = now()
    actor_id = actor["id"] if actor else None
    actor_name = actor["username"] if actor else detail.pop("attempted_username", None)
    ip = client_ip()
    ua = (request.headers.get("User-Agent", "")[:200] if has_request_context() else None)
    detail_s = _canonical(detail)
    payload = _row_payload(seq, ts, actor_id, actor_name, action, outcome, doc_id, target_user_id, detail_s, ip, ua)
    h = _hash(prev, payload)
    m = _mac(cfg.AUDIT_KEY, h)
    db.execute(
        """INSERT INTO audit_log(seq,ts,actor_id,actor_name,action,outcome,doc_id,target_user_id,
                                 detail,ip,user_agent,prev_hash,hash,mac)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (seq, ts, actor_id, actor_name, action, outcome, doc_id, target_user_id, detail_s, ip, ua, prev, h, m))
    queue_mirror(_canonical({**payload, "hash": h, "mac": m}))   # written to disk only after COMMIT
    return seq


def _mirror(path):
    out = {}
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    r = json.loads(line)
                    out[r["seq"]] = r["hash"]
                except (ValueError, KeyError):
                    out[-1] = "corrupt"
    except OSError:
        return None
    return out


def verify(db, key, mirror_path=None):
    """Walk the whole chain. Returns dict(ok, count, head, problems[]).
    If the JSONL mirror is supplied it is cross-checked, which also catches
    truncation of the database tail."""
    problems, prev, expected_seq, count = [], GENESIS, 1, 0
    for r in db.execute("SELECT * FROM audit_log ORDER BY seq"):
        count += 1
        if r["seq"] != expected_seq:
            problems.append(f"sequence gap before seq {r['seq']} (expected {expected_seq}) - rows deleted?")
            expected_seq = r["seq"]
        if r["prev_hash"] != prev:
            problems.append(f"seq {r['seq']}: prev_hash does not match previous row")
        payload = _row_payload(r["seq"], r["ts"], r["actor_id"], r["actor_name"], r["action"], r["outcome"],
                               r["doc_id"], r["target_user_id"], r["detail"], r["ip"], r["user_agent"])
        h = _hash(r["prev_hash"], payload)
        if h != r["hash"]:
            problems.append(f"seq {r['seq']}: row content does not match its hash - row altered")
        if not hmac.compare_digest(_mac(key, r["hash"]), r["mac"]):
            problems.append(f"seq {r['seq']}: MAC invalid - row forged or key mismatch")
        prev = r["hash"]
        expected_seq += 1
    if mirror_path is not None:
        m = _mirror(mirror_path)
        if m is not None:
            if m and max(m) > count and max(m) > expected_seq - 1:
                problems.append(f"mirror file has rows up to seq {max(m)} but the database ends at {expected_seq - 1} - tail truncated?")
            if -1 in m:
                problems.append("mirror file contains a corrupt line")
            db_hashes = {r["seq"]: r["hash"] for r in db.execute("SELECT seq, hash FROM audit_log")}
            for seq, h in m.items():
                if seq in db_hashes and db_hashes[seq] != h:
                    problems.append(f"seq {seq}: database row differs from the mirror file")
                    break
    return {"ok": not problems, "count": count, "head": prev, "problems": problems[:50]}
