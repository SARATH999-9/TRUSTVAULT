import os
import sqlite3
import time
from pathlib import Path

from flask import g, current_app, has_app_context

SCHEMA = Path(__file__).resolve().parent.parent / "schema.sql"


def connect(path):
    # isolation_level=None: we control transactions explicitly (see begin_write).
    conn = sqlite3.connect(path, timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = FULL")   # an audit record acknowledged is on disk
    return conn


def init_schema(path):
    conn = connect(path)
    conn.executescript(SCHEMA.read_text())
    conn.close()


def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["TV"].DB_PATH)
    return g.db


def begin_write(db):
    """Take the write lock up front so read-then-write sequences (audit chain
    head, grant upserts) cannot interleave with another writer."""
    if not db.in_transaction:
        db.execute("BEGIN IMMEDIATE")


def queue_mirror(line):
    """Audit mirror lines are held until the DB transaction commits. Writing them
    earlier would leave a phantom row in the mirror if the request then rolled
    back, and a later verify would cry 'tampering' about our own bug."""
    if has_app_context():
        g.setdefault("_mirror_queue", []).append(line)


def _flush_mirror():
    if not has_app_context():
        return
    lines = g.pop("_mirror_queue", None)
    if not lines:
        return
    try:
        with open(current_app.config["TV"].AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write("".join(l + "\n" for l in lines))
            f.flush()
            os.fsync(f.fileno())
    except OSError:
        pass  # the DB row is authoritative; the mirror is a best-effort second sink


def commit(db):
    if db.in_transaction:
        db.execute("COMMIT")
    _flush_mirror()


def rollback(db):
    if db.in_transaction:
        db.execute("ROLLBACK")
    if has_app_context():
        g.pop("_mirror_queue", None)


def now():
    return time.time()
