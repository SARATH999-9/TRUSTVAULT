"""'Who should see this?' assistant.

Deliberately a transparent heuristic, not a black box: it looks at who *this
owner* has previously shared similar documents with. It returns advice only.
Nothing in this module writes to the grants table; the owner must confirm each
suggestion through a separate, audited request (routes/docs.py: accept).
It also respects earlier human decisions: anyone the owner revoked or
dismissed on this document is never suggested again.
"""
import re

from .db import now

STOP = {"the", "and", "for", "with", "from", "draft", "final", "copy", "report", "document"}


def _tokens(name):
    return {t for t in re.findall(r"[a-z0-9]{4,}", name.lower()) if t not in STOP}


def generate(db, doc):
    owner_id = doc["owner_id"]
    # Anyone who has ever had a grant on this document (active or revoked) is excluded:
    # a revoke is a human decision we must not nag the owner to reverse.
    excluded = {r["user_id"] for r in db.execute(
        "SELECT user_id FROM grants WHERE document_id=?", (doc["id"],))}
    excluded |= {r["user_id"] for r in db.execute(
        "SELECT user_id FROM suggestions WHERE document_id=? AND state='dismissed'", (doc["id"],))}
    excluded.add(owner_id)

    users = {u["id"]: u for u in db.execute(
        "SELECT id, username, display_name, role FROM users WHERE active=1 AND role IN ('owner','viewer')")}
    this_tokens = _tokens(doc["name"])

    stats = {}
    q = """SELECT g.user_id, g.permission, d.category, d.name
           FROM grants g JOIN documents d ON d.id = g.document_id
           WHERE g.granted_by=? AND d.id<>? AND d.owner_id=?"""
    for r in db.execute(q, (owner_id, doc["id"], owner_id)):
        s = stats.setdefault(r["user_id"], {"cat": 0, "edit_cat": 0, "name": 0, "tot": 0})
        s["tot"] += 1
        if r["category"] == doc["category"]:
            s["cat"] += 1
            if r["permission"] == "edit":
                s["edit_cat"] += 1
        if this_tokens & _tokens(r["name"]):
            s["name"] += 1

    out = []
    for uid, s in stats.items():
        if uid in excluded or uid not in users:
            continue
        score = 3 * s["cat"] + 1 * s["name"] + 0.5 * min(s["tot"], 5)
        if score <= 0:
            continue
        perm = "edit" if (s["edit_cat"] >= 2 and users[uid]["role"] == "owner") else "read"
        bits = []
        if s["cat"]:
            bits.append(f"you shared {s['cat']} other {doc['category']} document(s) with them")
        if s["name"]:
            bits.append(f"{s['name']} earlier document(s) with a similar title")
        if not bits:
            bits.append(f"you have shared {s['tot']} document(s) with them before")
        out.append({"user_id": uid, "permission": perm, "score": round(score, 2),
                    "reason": "Suggested because " + "; ".join(bits) + ". Read-only unless you choose otherwise."
                    if perm == "read" else "Suggested because " + "; ".join(bits) + "; you gave them edit on similar documents."})
    out.sort(key=lambda x: -x["score"])
    return out[:5]


def persist(db, doc, items):
    db.execute("DELETE FROM suggestions WHERE document_id=? AND state='open'", (doc["id"],))
    ids = []
    for it in items:
        cur = db.execute("INSERT INTO suggestions(document_id,user_id,permission,reason,score,created_at) "
                         "VALUES(?,?,?,?,?,?)", (doc["id"], it["user_id"], it["permission"], it["reason"], it["score"], now()))
        ids.append(cur.lastrowid)
    return ids
