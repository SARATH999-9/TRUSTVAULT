"""Upload and input validation. We never trust the filename, the browser's
Content-Type, or the extension alone: the bytes must match the claimed type."""
import re
import unicodedata
import zipfile
import io

ALLOWED = {
    # ext: (mime served on download, sniff function name)
    "pdf":  "application/pdf",
    "png":  "image/png",
    "jpg":  "image/jpeg",
    "jpeg": "image/jpeg",
    "txt":  "text/plain; charset=utf-8",
    "csv":  "text/csv; charset=utf-8",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
}
OFFICE_PREFIX = {"docx": "word/", "xlsx": "xl/", "pptx": "ppt/"}
MAX_ZIP_ENTRIES = 2000
MAX_ZIP_UNCOMPRESSED = 200 * 1024 * 1024


class ValidationError(ValueError):
    pass


def clean_filename(name: str) -> str:
    name = unicodedata.normalize("NFKC", name or "")
    name = name.replace("\\", "/").split("/")[-1]                     # drop any path
    name = re.sub(r"[\x00-\x1f\x7f<>:\"|?*]", "", name).strip(" .")
    name = re.sub(r"\s+", " ", name)
    if not name or len(name) > 150:
        raise ValidationError("Filename is empty or longer than 150 characters")
    return name


def clean_text(value, field, max_len, required=True):
    value = unicodedata.normalize("NFKC", (value or "")).strip()
    value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", value)
    if required and not value:
        raise ValidationError(f"{field} is required")
    if len(value) > max_len:
        raise ValidationError(f"{field} must be at most {max_len} characters")
    return value


def sniff_and_validate(filename: str, data: bytes):
    """Returns (ext, mime). Raises ValidationError."""
    if not data:
        raise ValidationError("File is empty")
    if "." not in filename:
        raise ValidationError("File must have an extension")
    ext = filename.rsplit(".", 1)[1].lower()
    if ext not in ALLOWED:
        raise ValidationError(f"File type .{ext} is not allowed. Allowed: {', '.join(sorted(ALLOWED))}")
    if ext == "pdf":
        if not data.startswith(b"%PDF-"):
            raise ValidationError("Content is not a PDF")
        for marker in (b"/JavaScript", b"/JS", b"/Launch"):
            if marker in data:
                raise ValidationError("PDF contains active content (JavaScript/Launch) and was rejected")
    elif ext == "png":
        if not data.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValidationError("Content is not a PNG")
    elif ext in ("jpg", "jpeg"):
        if not data.startswith(b"\xff\xd8\xff"):
            raise ValidationError("Content is not a JPEG")
    elif ext in ("txt", "csv"):
        if b"\x00" in data:
            raise ValidationError("Text file contains binary data")
        try:
            data.decode("utf-8")
        except UnicodeDecodeError:
            raise ValidationError("Text file is not valid UTF-8")
    else:  # office formats are zip containers
        if not data.startswith(b"PK\x03\x04"):
            raise ValidationError(f"Content is not a valid .{ext} file")
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                infos = z.infolist()
                names = [i.filename for i in infos]
                if len(infos) > MAX_ZIP_ENTRIES or sum(i.file_size for i in infos) > MAX_ZIP_UNCOMPRESSED:
                    raise ValidationError("Archive is too large when unpacked (possible zip bomb)")
                if any(n.startswith("/") or ".." in n.split("/") for n in names):
                    raise ValidationError("Archive contains unsafe paths")
                if "[Content_Types].xml" not in names or not any(n.startswith(OFFICE_PREFIX[ext]) for n in names):
                    raise ValidationError(f"Archive is not a real .{ext} document")
                if any(n.lower().endswith("vbaproject.bin") for n in names):
                    raise ValidationError("Documents containing macros are not allowed")
        except zipfile.BadZipFile:
            raise ValidationError(f"Content is not a valid .{ext} file")
    return ext, ALLOWED[ext]
