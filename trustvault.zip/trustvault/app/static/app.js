'use strict';
/* TrustVault UI. All dynamic text goes through textContent (the h() helper); there is no innerHTML
   anywhere, so a malicious document name cannot become markup. The server is the only authority:
   hiding a button here is a convenience, never the control. */

const $app = document.getElementById('app');
const S = { user: null, csrf: null, es: null, route: null, refresh: null, live: false };

function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'value') e.value = v;
    else if (v === true) e.setAttribute(k, '');
    else e.setAttribute(k, v);
  }
  for (const c of kids.flat(Infinity)) if (c != null && c !== false) e.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return e;
}
const fmt = (iso) => iso ? new Date(iso).toLocaleString() : '—';
const bytes = (n) => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
function toast(msg, bad) {
  const t = h('div', { class: 'toast' + (bad ? ' bad' : '') }, msg);
  document.getElementById('toasts').append(t);
  setTimeout(() => t.remove(), 6000);
}

async function api(method, url, body) {
  const opt = { method, credentials: 'same-origin', headers: {} };
  if (S.csrf && method !== 'GET') opt.headers['X-CSRF-Token'] = S.csrf;
  if (body instanceof FormData) opt.body = body;
  else if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(url, opt);
  let data = null;
  try { data = await r.json(); } catch (_) { /* non-JSON */ }
  if (r.status === 401 && S.user) { endSession('Your session ended. Please sign in again.'); throw new Error('Signed out'); }
  if (!r.ok) throw new Error((data && data.error) || ('Request failed (' + r.status + ')'));
  return data;
}
const run = (p) => p.catch((e) => { toast(e.message, true); throw e; });

/* ---------------- session + live events ---------------- */
function endSession(msg) {
  if (S.es) { S.es.close(); S.es = null; }
  S.user = S.csrf = null;
  renderLogin(msg);
}
function connectEvents() {
  if (S.es) S.es.close();
  const es = new EventSource('/api/events');
  S.es = es;
  es.onopen = () => { S.live = true; paintLive(); };
  es.onerror = () => { S.live = false; paintLive(); };
  es.addEventListener('session_ended', () => endSession('Your access was ended by an administrator.'));
  es.addEventListener('audit', (m) => onEvent(JSON.parse(m.data)));
}
function paintLive() {
  const el = document.getElementById('live');
  if (el) { el.className = 'live' + (S.live ? '' : ' off'); el.lastChild.textContent = S.live ? 'Live' : 'Reconnecting…'; }
}
let refreshTimer = null;
function onEvent(ev) {
  if (ev.target_user_id === S.user.id && ev.action === 'grant.revoke') {
    toast('Your access to “' + (ev.doc_name || 'a document') + '” was removed.', true);
    if (S.route && S.route[0] === 'doc' && S.route[1] === ev.doc_id) { location.hash = '#/docs'; return; }
  }
  if (ev.target_user_id === S.user.id && ev.action === 'grant.add') toast('You were given access to “' + (ev.doc_name || 'a document') + '”.');
  if (ev.outcome === 'denied' && S.user.role === 'owner' && ev.doc_id) toast('Refused access attempt by ' + (ev.actor || '?') + ' on your document.', true);
  if (S.liveHook) S.liveHook(ev);
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => S.refresh && S.refresh(true), 300);
}

/* ---------------- shell ---------------- */
const NAV = {
  owner: [['#/docs', 'Documents'], ['#/upload', 'Upload'], ['#/trash', 'Trash']],
  viewer: [['#/docs', 'Shared with me']],
  admin: [['#/admin/activity', 'Activity'], ['#/admin/alerts', 'Alerts'], ['#/admin/grants', 'Permissions'], ['#/admin/docs', 'Documents (metadata)'], ['#/admin/users', 'Users']],
};
function shell(content) {
  const cur = location.hash || '';
  $app.replaceChildren(h('div', { class: 'shell' },
    h('nav', {},
      h('div', { class: 'logo' }, h('i'), 'TrustVault'),
      NAV[S.user.role].map(([href, label]) => h('a', { href, class: cur.startsWith(href) ? 'active' : '' }, label)),
      h('div', { class: 'sep' }, 'Account'),
      h('a', { href: '#/account', class: cur === '#/account' ? 'active' : '' }, 'Change password'),
      h('a', { href: '#', onclick: async (e) => { e.preventDefault(); try { await api('POST', '/api/auth/logout'); } catch (_) {} endSession('Signed out.'); } }, 'Sign out'),
      h('div', { class: 'me' }, S.user.display_name, h('br'), h('span', { class: 'chip' }, S.user.role), ' ',
        h('span', { id: 'live', class: 'live' + (S.live ? '' : ' off') }, h('i'), S.live ? 'Live' : 'Connecting…'))),
    h('main', {}, content)));
}

function renderLogin(msg) {
  S.route = null; S.refresh = null; S.liveHook = null;
  const err = h('div', { class: 'small', style: 'color:var(--bad);min-height:18px', role: 'alert' }, msg || '');
  const u = h('input', { id: 'u', autocomplete: 'username', required: true });
  const p = h('input', { id: 'p', type: 'password', autocomplete: 'current-password', required: true });
  $app.replaceChildren(h('div', { class: 'login' }, h('div', { class: 'card' },
    h('h1', {}, 'TrustVault'), h('p', { class: 'mute' }, 'Secure document sharing with a provable audit trail.'),
    h('form', { onsubmit: async (e) => {
      e.preventDefault();
      try {
        const d = await api('POST', '/api/auth/login', { username: u.value, password: p.value });
        S.user = d.user; S.csrf = d.csrf; connectEvents();
        location.hash = S.user.role === 'admin' ? '#/admin/activity' : '#/docs'; route();
      } catch (ex) { err.textContent = ex.message; }
    } }, h('label', { for: 'u' }, 'Username'), u, h('label', { for: 'p' }, 'Password'), p, err,
      h('button', { type: 'submit', style: 'width:100%;margin-top:6px' }, 'Sign in')))));
}

/* ---------------- documents ---------------- */
function docRow(d) {
  return h('tr', { class: 'click', tabindex: 0, onclick: () => location.hash = '#/doc/' + d.id, onkeydown: (e) => e.key === 'Enter' && (location.hash = '#/doc/' + d.id) },
    h('td', {}, d.name), h('td', {}, h('span', { class: 'chip' }, d.category)), h('td', {}, d.owner.name),
    h('td', {}, h('span', { class: 'chip' }, d.my_permission)), h('td', {}, 'v' + d.version), h('td', { class: 'mute' }, fmt(d.updated_at)));
}
async function viewDocs() {
  const f = { q: '', category: '', owner: '', date_from: '', date_to: '', scope: 'all' };
  const results = h('tbody');
  const cats = h('select', { onchange: (e) => { f.category = e.target.value; load(); } }, h('option', { value: '' }, 'All categories'));
  const bind = (k) => (e) => { f[k] = e.target.value; clearTimeout(bind.t); bind.t = setTimeout(load, 250); };
  async function load() {
    const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
    const d = await run(api('GET', '/api/documents?' + qs));
    if (cats.options.length === 1) d.categories.forEach((c) => cats.append(h('option', { value: c }, c)));
    results.replaceChildren(...(d.documents.length ? d.documents.map(docRow)
      : [h('tr', {}, h('td', { colspan: 6, class: 'mute' }, 'No documents match.'))]));
  }
  S.refresh = load;
  const scope = S.user.role === 'owner' ? h('select', { onchange: (e) => { f.scope = e.target.value; load(); } },
    h('option', { value: 'all' }, 'All I can see'), h('option', { value: 'mine' }, 'Owned by me'), h('option', { value: 'shared' }, 'Shared with me')) : null;
  shell([h('h1', {}, S.user.role === 'owner' ? 'Documents' : 'Shared with me'),
    h('div', { class: 'card' }, h('div', { class: 'row' },
      h('input', { class: 'grow', placeholder: 'Search by name…', 'aria-label': 'Search by name', oninput: bind('q') }), cats,
      h('input', { placeholder: 'Owner', 'aria-label': 'Owner', oninput: bind('owner'), size: 10 }),
      h('input', { type: 'date', 'aria-label': 'Created from', onchange: bind('date_from') }),
      h('input', { type: 'date', 'aria-label': 'Created to', onchange: bind('date_to') }), scope)),
    h('div', { class: 'card' }, h('table', {}, h('thead', {}, h('tr', {}, ['Name', 'Category', 'Owner', 'Your access', 'Version', 'Updated'].map((x) => h('th', {}, x)))), results))]);
  await load();
}

async function viewUpload() {
  if (S.user.role !== 'owner') return shell(h('div', { class: 'card' }, 'Only owners can upload.'));
  const d = await run(api('GET', '/api/documents?limit=1'));
  const file = h('input', { type: 'file', required: true });
  const name = h('input', { placeholder: 'Defaults to file name' });
  const cat = h('select', {}, d.categories.map((c) => h('option', { value: c }, c)));
  const desc = h('textarea', { rows: 3, maxlength: 1000 });
  shell([h('h1', {}, 'Upload'), h('div', { class: 'card' }, h('form', { onsubmit: async (e) => {
    e.preventDefault();
    const fd = new FormData(); fd.append('file', file.files[0]); fd.append('name', name.value); fd.append('category', cat.value); fd.append('description', desc.value);
    const r = await run(api('POST', '/api/documents', fd));
    toast('Uploaded. It is private to you until you share it.'); location.hash = '#/doc/' + r.id;
  } }, h('label', {}, 'File (pdf, docx, xlsx, pptx, png, jpg, txt, csv — max 10 MB)'), file, h('label', {}, 'Name'), name,
    h('label', {}, 'Category'), cat, h('label', {}, 'Description'), desc, h('p', {}, h('button', { type: 'submit' }, 'Upload'))))]);
}

async function viewDoc(id) {
  let d;
  try { d = await api('GET', '/api/documents/' + encodeURIComponent(id)); } catch (e) {
    return shell(h('div', { class: 'card' }, h('h1', {}, 'Not available'), h('p', { class: 'mute' }, 'This document does not exist or you do not have access to it.'), h('a', { href: '#/docs' }, 'Back to documents')));
  }
  S.refresh = () => route(true);
  const body = [h('a', { href: '#/docs' }, '← All documents'), h('h1', {}, d.name),
    h('p', { class: 'mute' }, h('span', { class: 'chip' }, d.category), ' ', h('span', { class: 'chip' }, 'Your access: ' + d.my_permission), ' · owner ' + d.owner.name + ' · updated ' + fmt(d.updated_at))];
  if (d.description) body.push(h('p', {}, d.description));
  // versions
  body.push(h('div', { class: 'card' }, h('h3', {}, 'Versions'), h('table', {}, h('tbody', {}, d.versions.map((v) => h('tr', {},
    h('td', {}, 'v' + v.version), h('td', {}, v.filename), h('td', { class: 'mute' }, bytes(v.size)), h('td', { class: 'mute' }, v.uploaded_by + ' · ' + fmt(v.uploaded_at)),
    h('td', { class: 'mono' }, v.sha256.slice(0, 12) + '…'),
    h('td', {}, h('a', { href: '/api/documents/' + id + '/download?version=' + v.version }, 'Download'))))))));
  if (d.can.edit) {
    const nm = h('input', { value: d.name, 'aria-label': 'Name' }), ct = h('select', {}, ['Contract', 'HR', 'Finance', 'Legal', 'Engineering', 'Audit', 'Other'].map((c) => h('option', { value: c, selected: c === d.category }, c)));
    const ds = h('input', { value: d.description, class: 'grow', 'aria-label': 'Description' }); const nf = h('input', { type: 'file' });
    body.push(h('div', { class: 'card' }, h('h3', {}, 'Edit'), h('div', { class: 'row' }, nm, ct, ds,
      h('button', { onclick: async () => { await run(api('PATCH', '/api/documents/' + id, { name: nm.value, category: ct.value, description: ds.value })); toast('Saved'); route(true); } }, 'Save')),
      h('div', { class: 'row', style: 'margin-top:10px' }, nf, h('button', { class: 'ghost', onclick: async () => {
        if (!nf.files[0]) return toast('Choose a file first', true);
        const fd = new FormData(); fd.append('file', nf.files[0]);
        await run(api('POST', '/api/documents/' + id + '/versions', fd)); toast('New version uploaded'); route(true);
      } }, 'Upload new version'))));
  }
  if (d.can.manage) body.push(...(await sharingPanel(id)));
  shell(body);
}

async function sharingPanel(id) {
  const [g, sug0, au] = await Promise.all([
    run(api('GET', '/api/documents/' + id + '/grants')), Promise.resolve(null), run(api('GET', '/api/documents/' + id + '/audit'))]);
  const out = [];
  const who = h('input', { list: 'people', placeholder: 'Type a name…', 'aria-label': 'Person' });
  const dl = h('datalist', { id: 'people' }); let people = [];
  who.addEventListener('input', async () => {
    const d = await api('GET', '/api/directory?q=' + encodeURIComponent(who.value)); people = d.users;
    dl.replaceChildren(...people.map((u) => h('option', { value: u.display_name + ' (' + u.username + ')' })));
  });
  const perm = h('select', { 'aria-label': 'Permission' }, h('option', { value: 'read' }, 'Can read'), h('option', { value: 'edit' }, 'Can edit'));
  const exp = h('input', { type: 'date', 'aria-label': 'Expires' });
  const share = async () => {
    const u = people.find((x) => who.value === x.display_name + ' (' + x.username + ')');
    if (!u) return toast('Pick a person from the list', true);
    const body = { user_id: u.id, permission: perm.value }; if (exp.value) body.expires_at = exp.value + 'T23:59:59Z';
    await run(api('PUT', '/api/documents/' + id + '/grants', body)); toast('Access granted to ' + u.display_name); route(true);
  };
  out.push(h('div', { class: 'card' }, h('h3', {}, 'Who can access this document'),
    h('table', {}, h('tbody', {}, g.active.length ? g.active.map((x) => h('tr', {},
      h('td', {}, x.user.display_name, ' ', h('span', { class: 'mute small' }, '@' + x.user.username)),
      h('td', {}, h('span', { class: 'chip' }, x.permission)),
      h('td', { class: 'mute small' }, (x.via_suggestion ? 'via suggestion · ' : '') + (x.expires_at ? 'expires ' + fmt(x.expires_at) : 'no expiry')),
      h('td', {}, h('button', { class: 'danger', onclick: async () => { await run(api('DELETE', '/api/documents/' + id + '/grants/' + x.user.id)); toast('Access removed — effective immediately'); route(true); } }, 'Revoke'))))
      : [h('tr', {}, h('td', { class: 'mute' }, 'Private: only you can open it.'))])),
    h('div', { class: 'row', style: 'margin-top:12px' }, who, dl, perm, exp, h('button', { onclick: share }, 'Share'))));
  // suggestions: advice only, a human confirms
  const sugBox = h('div', {});
  out.push(h('div', { class: 'card' }, h('h3', {}, 'Suggested people'), h('p', { class: 'mute small' }, 'Suggestions are advice. Nothing is shared until you accept, and your decision is recorded.'),
    sugBox, h('button', { class: 'ghost', onclick: async () => {
      const d = await run(api('GET', '/api/documents/' + id + '/suggestions'));
      sugBox.replaceChildren(...(d.suggestions.length ? d.suggestions.map((s) => h('div', { class: 'alert' },
        h('b', {}, s.user.display_name), ' as ', h('span', { class: 'chip' }, s.permission), h('div', { class: 'small mute' }, s.reason),
        h('div', { class: 'row', style: 'margin-top:6px' },
          h('button', { onclick: async () => { await run(api('POST', '/api/documents/' + id + '/suggestions/' + s.id + '/accept', {})); toast('Accepted and recorded'); route(true); } }, 'Accept'),
          h('button', { class: 'ghost', onclick: async () => { await run(api('POST', '/api/documents/' + id + '/suggestions/' + s.id + '/dismiss')); s && toast('Dismissed'); route(true); } }, 'Dismiss'))))
        : [h('p', { class: 'mute' }, 'No suggestions for this document yet.')]));
    } }, 'Suggest who should see this')));
  out.push(h('div', { class: 'card' }, h('h3', {}, 'Who touched this document'), h('table', {}, h('tbody', {}, au.events.slice(0, 15).map((e) => h('tr', {},
    h('td', { class: 'mute small' }, fmt(e.ts)), h('td', {}, e.actor || '—'), h('td', {}, e.action), h('td', {}, h('span', { class: 'chip ' + e.outcome }, e.outcome))))))));
  out.push(h('div', { class: 'card' }, h('button', { class: 'danger', onclick: async () => {
    if (!confirm('Move this document to the trash? Everyone you shared it with loses access.')) return;
    await run(api('DELETE', '/api/documents/' + id)); toast('Moved to trash'); location.hash = '#/docs'; } }, 'Move to trash')));
  return out;
}

async function viewTrash() {
  const d = await run(api('GET', '/api/documents?trash=1'));
  S.refresh = () => route(true);
  shell([h('h1', {}, 'Trash'), h('p', { class: 'mute' }, 'Nobody but you can see these. Purging is permanent and removes the encrypted file.'),
    h('div', { class: 'card' }, h('table', {}, h('tbody', {}, d.documents.length ? d.documents.map((x) => h('tr', {},
      h('td', {}, x.name), h('td', { class: 'mute' }, 'deleted ' + fmt(x.deleted_at)),
      h('td', {}, h('button', { class: 'ghost', onclick: async () => { await run(api('POST', '/api/documents/' + x.id + '/restore')); toast('Restored'); route(true); } }, 'Restore'), ' ',
        h('button', { class: 'danger', onclick: async () => { if (confirm('Permanently delete “' + x.name + '”?')) { await run(api('DELETE', '/api/documents/' + x.id + '/purge')); route(true); } } }, 'Purge'))))
      : [h('tr', {}, h('td', { class: 'mute' }, 'Trash is empty.'))])))]);
}

/* ---------------- admin ---------------- */
function evRow(e, fresh) {
  const d = Object.entries(e.detail || {}).filter(([k]) => !['doc_name'].includes(k)).map(([k, v]) => k + '=' + (typeof v === 'object' ? JSON.stringify(v) : v)).join(' ');
  return h('tr', { class: fresh ? 'flash' : '' }, h('td', { class: 'mute small' }, '#' + e.seq), h('td', { class: 'small' }, fmt(e.ts)),
    h('td', {}, e.actor || '—'), h('td', {}, e.action), h('td', {}, h('span', { class: 'chip ' + e.outcome }, e.outcome)),
    h('td', { class: 'small' }, (e.detail && e.detail.doc_name) || (e.doc_id ? e.doc_id.slice(0, 8) + '…' : '')), h('td', { class: 'mono' }, d.slice(0, 140)), h('td', { class: 'mute small' }, e.ip || ''));
}
async function adminActivity() {
  const f = { prefix: '', outcome: '', actor: '' };
  const body = h('tbody'); const stats = h('div', { class: 'stats' }); const integrity = h('div', { class: 'small mute' });
  async function load() {
    const [a, s] = await Promise.all([run(api('GET', '/api/admin/audit?limit=100&' + new URLSearchParams(Object.entries(f).filter(([, v]) => v)))), run(api('GET', '/api/admin/stats'))]);
    body.replaceChildren(...a.events.map((e) => evRow(e)));
    stats.replaceChildren(...[['Documents', s.documents], ['Active users', s.users], ['Downloads (24h)', s.downloads_24h], ['Refusals (24h)', s.denials_24h], ['Permission changes (24h)', s.permission_changes_24h], ['Audit rows', s.audit_rows]]
      .map(([k, v]) => h('div', { class: 'stat' }, h('b', {}, v), h('span', { class: 'mute small' }, k))));
  }
  S.refresh = load;
  S.liveHook = (e) => { if (!f.prefix && !f.outcome && !f.actor) body.prepend(evRow({ ...e, detail: { doc_name: e.doc_name } }, true)); };
  const sel = (k, opts) => h('select', { 'aria-label': k, onchange: (e) => { f[k] = e.target.value; load(); } }, opts.map(([v, l]) => h('option', { value: v }, l)));
  shell([h('h1', {}, 'Activity'), h('p', { class: 'mute' }, 'Every upload, view, download, change, deletion, permission change and refused attempt. Newest first, updating live.'), stats,
    h('div', { class: 'card' }, h('div', { class: 'row' },
      sel('prefix', [['', 'All actions'], ['doc.', 'Document actions'], ['grant.', 'Permission changes'], ['auth.', 'Sign-ins'], ['user.', 'User admin'], ['access.', 'Access refusals'], ['suggestion.', 'Suggestions']]),
      sel('outcome', [['', 'Any outcome'], ['ok', 'Succeeded'], ['denied', 'Refused'], ['error', 'Errors']]),
      h('input', { placeholder: 'Actor', 'aria-label': 'Actor', oninput: (e) => { f.actor = e.target.value; clearTimeout(adminActivity.t); adminActivity.t = setTimeout(load, 250); } }),
      h('span', { class: 'grow' }),
      h('button', { class: 'ghost', onclick: async () => {
        const v = await run(api('GET', '/api/admin/audit/verify')); const a = await run(api('GET', '/api/admin/audit/anchor'));
        integrity.textContent = (v.ok ? '✔ Chain intact: ' + v.count + ' rows verified. ' : '✖ TAMPERING DETECTED: ' + v.problems.join('; ') + ' ') + 'Anchor #' + a.seq + ' ' + a.hash;
        integrity.style.color = v.ok ? 'var(--ok)' : 'var(--bad)';
      } }, 'Verify audit integrity')), h('div', { style: 'margin-top:8px', class: 'mono' }, integrity)),
    h('div', { class: 'card', style: 'overflow-x:auto' }, h('table', {}, h('thead', {}, h('tr', {}, ['Seq', 'Time', 'Actor', 'Action', 'Outcome', 'Document', 'Detail', 'IP'].map((x) => h('th', {}, x)))), body))]);
  await load();
}
async function adminAlerts() {
  const box = h('div');
  async function load() {
    const d = await run(api('GET', '/api/admin/alerts'));
    box.replaceChildren(...(d.alerts.length ? d.alerts.map((a) => h('div', { class: 'alert ' + a.severity }, h('span', { class: 'chip ' + a.severity }, a.severity), ' ', a.message))
      : [h('p', { class: 'mute' }, 'Nothing needs attention.')]));
  }
  S.refresh = load;
  shell([h('h1', {}, 'Worth noticing'), h('p', { class: 'mute' }, 'Probing (repeated refusals), bulk downloads, retries after revocation, login failures, grant bursts, account changes and any audit-chain integrity failure.'), h('div', { class: 'card' }, box)]);
  await load();
}
async function adminGrants() {
  const d = await run(api('GET', '/api/admin/grants')); S.refresh = () => route(true);
  const changes = await run(api('GET', '/api/admin/audit?prefix=grant.&limit=30'));
  shell([h('h1', {}, 'Permissions'), h('p', { class: 'mute' }, 'Administrators can remove access in an emergency but can never add it, and never open document content.'),
    h('div', { class: 'card' }, h('h3', {}, 'Active grants'), h('table', {}, h('thead', {}, h('tr', {}, ['Document', 'Person', 'Access', 'Granted by', 'Expires', ''].map((x) => h('th', {}, x)))), h('tbody', {}, d.grants.map((g) => h('tr', {},
      h('td', {}, g.doc_name), h('td', {}, g.grantee), h('td', {}, h('span', { class: 'chip' }, g.permission)), h('td', {}, g.granted_by), h('td', { class: 'mute small' }, g.expires_at ? fmt(g.expires_at) : 'never'),
      h('td', {}, h('button', { class: 'danger', onclick: async () => { if (confirm('Revoke this access now?')) { await run(api('DELETE', '/api/admin/grants/' + g.id)); toast('Revoked'); route(true); } } }, 'Revoke'))))))),
    h('div', { class: 'card', style: 'overflow-x:auto' }, h('h3', {}, 'Recent permission changes'), h('table', {}, h('tbody', {}, changes.events.map((e) => evRow(e)))))]);
}
async function adminDocs() {
  const d = await run(api('GET', '/api/admin/documents')); S.refresh = () => route(true);
  shell([h('h1', {}, 'Documents (metadata only)'), h('p', { class: 'mute' }, 'Admins see that a document exists, who owns it and how it is shared — never its content.'),
    h('div', { class: 'card', style: 'overflow-x:auto' }, h('table', {}, h('thead', {}, h('tr', {}, ['Name', 'Owner', 'Category', 'Size', 'Shared with', 'Last download', 'Refusals', 'State'].map((x) => h('th', {}, x)))),
      h('tbody', {}, d.documents.map((x) => h('tr', {}, h('td', {}, x.name), h('td', {}, x.owner), h('td', {}, x.category), h('td', { class: 'mute' }, bytes(x.size)), h('td', {}, x.active_grants),
        h('td', { class: 'mute small' }, fmt(x.last_download)), h('td', {}, x.denials ? h('span', { class: 'chip denied' }, x.denials) : '0'), h('td', {}, x.deleted ? h('span', { class: 'chip' }, 'in trash') : 'active'))))))]);
}
async function adminUsers() {
  const d = await run(api('GET', '/api/admin/users')); S.refresh = () => route(true);
  const f = { username: h('input', { placeholder: 'username' }), display_name: h('input', { placeholder: 'Full name' }), role: h('select', {}, ['viewer', 'owner', 'admin'].map((r) => h('option', { value: r }, r))), password: h('input', { type: 'password', placeholder: 'Initial password (10+ chars)' }) };
  shell([h('h1', {}, 'Users'), h('div', { class: 'card' }, h('h3', {}, 'Create user'), h('div', { class: 'row' }, f.username, f.display_name, f.role, f.password,
    h('button', { onclick: async () => { await run(api('POST', '/api/admin/users', { username: f.username.value, display_name: f.display_name.value, role: f.role.value, password: f.password.value })); toast('User created'); route(true); } }, 'Create'))),
    h('div', { class: 'card' }, h('table', {}, h('thead', {}, h('tr', {}, ['User', 'Role', 'Status', ''].map((x) => h('th', {}, x)))), h('tbody', {}, d.users.map((u) => h('tr', {},
      h('td', {}, u.display_name, ' ', h('span', { class: 'mute small' }, '@' + u.username)),
      h('td', {}, h('select', { 'aria-label': 'Role of ' + u.username, onchange: async (e) => { try { await api('PATCH', '/api/admin/users/' + u.id, { role: e.target.value }); toast('Role changed — applies immediately'); } catch (x) { toast(x.message, true); } route(true); } }, ['viewer', 'owner', 'admin'].map((r) => h('option', { value: r, selected: r === u.role }, r)))),
      h('td', {}, u.active ? (u.locked ? h('span', { class: 'chip medium' }, 'locked') : 'active') : h('span', { class: 'chip denied' }, 'disabled')),
      h('td', {}, h('button', { class: u.active ? 'danger' : 'ghost', onclick: async () => { try { await api('PATCH', '/api/admin/users/' + u.id, { active: !u.active }); toast(u.active ? 'Disabled — all sessions ended' : 'Enabled'); } catch (x) { toast(x.message, true); } route(true); } }, u.active ? 'Disable' : 'Enable'), ' ',
        h('button', { class: 'ghost', onclick: async () => { const p = prompt('New password for ' + u.username + ' (10+ chars, letters and digits/symbols):'); if (p) { await run(api('POST', '/api/admin/users/' + u.id + '/password', { password: p })); toast('Password reset; sessions ended'); } } }, 'Reset password')))))))]);
}
function viewAccount() {
  const cur = h('input', { type: 'password', autocomplete: 'current-password' }), nw = h('input', { type: 'password', autocomplete: 'new-password' });
  shell([h('h1', {}, 'Change password'), h('div', { class: 'card' }, h('label', {}, 'Current password'), cur, h('label', {}, 'New password (10+ chars, letters and digits/symbols)'), nw,
    h('p', {}, h('button', { onclick: async () => { await run(api('POST', '/api/auth/password', { current: cur.value, new: nw.value })); toast('Password changed. Other sessions were signed out.'); cur.value = nw.value = ''; } }, 'Change password')))]);
}

/* ---------------- router ---------------- */
async function route(soft) {
  if (!S.user) return;
  const parts = (location.hash.replace(/^#\/?/, '') || (S.user.role === 'admin' ? 'admin/activity' : 'docs')).split('/');
  S.route = parts; if (!soft) { S.liveHook = null; }
  try {
    const [a, b] = parts;
    if (a === 'docs') return await viewDocs();
    if (a === 'doc') return await viewDoc(b);
    if (a === 'upload') return await viewUpload();
    if (a === 'trash') return await viewTrash();
    if (a === 'account') return viewAccount();
    if (a === 'admin' && S.user.role === 'admin') {
      return await ({ activity: adminActivity, alerts: adminAlerts, grants: adminGrants, docs: adminDocs, users: adminUsers }[b] || adminActivity)();
    }
    location.hash = S.user.role === 'admin' ? '#/admin/activity' : '#/docs';
  } catch (e) { /* api() already surfaced the message */ }
}
window.addEventListener('hashchange', () => route(false));
(async function boot() {
  try { const d = await api('GET', '/api/auth/me'); S.user = d.user; S.csrf = d.csrf; connectEvents(); route(false); }
  catch (_) { renderLogin(); }
})();
