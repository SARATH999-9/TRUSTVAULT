"""THE authorisation decision point.

Every route that touches a document gets it through `load_doc()`. There is no
other path from a document id to a document row or its bytes. Decisions are
computed from the database on every call (no caching), so revocation, expiry,
role changes and account disabling take effect on the very next request.

Policy
------
admin   : no document access at all (not even read). Manages users, sees
          metadata + audit, may revoke grants. Separation of duties.
owner   : may upload; has read/edit/manage on documents they own.
viewer  : read-only, only on documents granted to them. A viewer can never
          edit, even if an 'edit' grant row exists.
grant   : 'read' -> {read}; 'edit' -> {read, edit}. Optional expiry.
manage  : (grant/revoke, delete, restore, purge, see per-doc audit) is the owner
          of the document only. Editors cannot re-share.
deleted : a document in the trash is reachable by nobody except its owner,
          who may only restore or purge it.
"""
from . import audit
from .db import commit, now
from .security import ApiError


def active_grant(db, doc_id, user_id):
    return db.execute(
        "SELECT * FROM grants WHERE document_id=? AND user_id=? AND revoked_at IS NULL "
        "AND (expires_at IS NULL OR expires_at > ?)", (doc_id, user_id, now())).fetchone()


def permissions(db, user, doc):
    """Return the set of actions `user` may perform on `doc` (a row)."""
    if not user or not user["active"] or doc is None:
        return set()
    role = user["role"]
    if role == "admin":
        return set()
    if doc["owner_id"] == user["id"] and role == "owner":
        return {"manage"} if doc["deleted_at"] else {"read", "edit", "manage"}
    if doc["deleted_at"]:
        return set()
    g = active_grant(db, doc["id"], user["id"])
    if not g:
        return set()
    perms = {"read"}
    if g["permission"] == "edit" and role == "owner":
        perms.add("edit")
    return perms


def load_doc(db, doc_id, user, action):
    """Fetch a document iff `user` may perform `action`; else audit + raise."""
    doc_id = (doc_id or "")[:64]
    doc = db.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
    perms = permissions(db, user, doc)
    if action in perms:
        return doc
    audit.log(db, "access.denied", actor=user, outcome="denied", doc_id=doc_id, attempted=action)
    commit(db)   # the refusal is evidence: persist it even though we abort
    if perms:
        raise ApiError(403, "You do not have permission to do that on this document")
    # No rights at all: indistinguishable from a document that does not exist.
    raise ApiError(404, "Document not found")
