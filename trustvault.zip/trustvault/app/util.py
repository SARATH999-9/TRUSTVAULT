from datetime import datetime, timezone, timedelta

from .security import ApiError


def iso(ts):
    return None if ts is None else datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def like_escape(s):
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def parse_when(value, field, future=False):
    """ISO date/datetime (naive = UTC) or epoch seconds -> epoch float."""
    if value in (None, ""):
        return None
    try:
        if isinstance(value, (int, float)):
            ts = float(value)
        else:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            ts = dt.timestamp()
    except (ValueError, OverflowError):
        raise ApiError(400, f"{field} is not a valid date")
    if future:
        now = datetime.now(timezone.utc).timestamp()
        if ts <= now:
            raise ApiError(400, f"{field} must be in the future")
        if ts > now + 5 * 365 * 86400:
            raise ApiError(400, f"{field} is too far in the future")
    return ts


def end_of_day(ts):
    return ts + 86400 - 1 if ts is not None else None


def user_public(u):
    return {"id": u["id"], "username": u["username"], "display_name": u["display_name"], "role": u["role"]}
