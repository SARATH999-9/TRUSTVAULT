"""Encrypted blob store.

Files live under data/blobs/<random>.bin, outside any served directory, and are
AES-256-GCM encrypted. The key for each blob is derived (HKDF) from the master
key + the blob name, and the associated data binds the ciphertext to
(document id, version). Swapping blob files between records, or pointing a DB
row at someone else's blob, makes decryption fail instead of leaking content.
"""
import os
import secrets

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


class StorageError(Exception):
    pass


class BlobStore:
    def __init__(self, root, master_key):
        self.root = root
        self.master = master_key

    def _key(self, blob_name):
        return HKDF(algorithm=hashes.SHA256(), length=32, salt=None,
                    info=b"trustvault-blob:" + blob_name.encode()).derive(self.master)

    def _path(self, blob_name):
        if not blob_name.isalnum() or len(blob_name) != 32:   # defence against traversal
            raise StorageError("bad blob name")
        return self.root / f"{blob_name}.bin"

    def put(self, data: bytes, aad: str) -> str:
        blob_name = secrets.token_hex(16)
        nonce = os.urandom(12)
        ct = AESGCM(self._key(blob_name)).encrypt(nonce, data, aad.encode())
        tmp = self._path(blob_name).with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(nonce + ct)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self._path(blob_name))
        return blob_name

    def get(self, blob_name: str, aad: str) -> bytes:
        try:
            raw = self._path(blob_name).read_bytes()
            return AESGCM(self._key(blob_name)).decrypt(raw[:12], raw[12:], aad.encode())
        except (OSError, InvalidTag, ValueError) as e:
            raise StorageError("blob unreadable or failed integrity check") from e

    def delete(self, blob_name: str):
        try:
            self._path(blob_name).unlink()
        except (FileNotFoundError, StorageError):
            pass
