import os
import secrets
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent

CATEGORIES = ["Contract", "HR", "Finance", "Legal", "Engineering", "Audit", "Other"]
ROLES = ("admin", "owner", "viewer")
PERMISSIONS = ("read", "edit")


def _secret(env, fname, data_dir):
    """Secrets come from the environment, else a 0600 file created on first run."""
    val = os.environ.get(env)
    if val:
        return val.encode()
    p = Path(data_dir) / fname
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(secrets.token_hex(32))
    return p.read_text().strip().encode()


class Config:
    def __init__(self, **overrides):
        self.DATA_DIR = Path(os.environ.get("TV_DATA_DIR", BASE / "data"))
        self.MAX_UPLOAD_BYTES = int(os.environ.get("TV_MAX_UPLOAD_MB", "10")) * 1024 * 1024
        self.SESSION_IDLE_SECONDS = 30 * 60
        self.SESSION_ABSOLUTE_SECONDS = 12 * 3600
        self.COOKIE_SECURE = os.environ.get("TV_COOKIE_SECURE", "0") == "1"
        self.LOGIN_MAX_FAILS = 5
        self.LOGIN_LOCK_SECONDS = 15 * 60
        self.IP_LOGIN_PER_MINUTE = 20
        self.TRASH_RETENTION_DAYS = 30
        self.TESTING = False
        # Set TV_TRUST_PROXY=1 only behind exactly one reverse proxy that overwrites X-Forwarded-*.
        self.TRUST_PROXY = os.environ.get("TV_TRUST_PROXY", "0") == "1"
        for k, v in overrides.items():
            setattr(self, k, v)
        # Derived paths are computed AFTER overrides, from the final DATA_DIR.
        self.DATA_DIR = Path(self.DATA_DIR)
        self.DB_PATH = str(self.DATA_DIR / "trustvault.db")
        self.BLOB_DIR = self.DATA_DIR / "blobs"          # outside static/, never served directly
        self.AUDIT_FILE = self.DATA_DIR / "audit.jsonl"  # second, append-only sink
        self.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.BLOB_DIR.mkdir(parents=True, exist_ok=True)
        # Independent keys: file encryption and audit MAC never share a key.
        self.STORAGE_KEY = _secret("TV_STORAGE_KEY", ".storage.key", self.DATA_DIR)
        self.AUDIT_KEY = _secret("TV_AUDIT_KEY", ".audit.key", self.DATA_DIR)
