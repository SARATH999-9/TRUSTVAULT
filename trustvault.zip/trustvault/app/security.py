"""Authentication, sessions, CSRF, login throttling and the route decorator."""
import functools
import hashlib
import hmac
import re
import secrets
import time
from collections import defaultdict, deque
from urllib.parse import urlsplit

from flask import current_app, g, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

from . import audit
from .db import begin_write, commit, get_db, now

COOKIE = "tv_session"


class ApiError(Exception):
    def __init__(self, status, message, **extra):
        self.status, self.message, self.extra = status, message, extra


# ---------- passwords ----------
def hash_password(pw):
    return generate_password_hash(pw, method="scrypt")


_DUMMY = generate_password_hash("dummy-password-for-timing", method="scrypt")


def check_password(user_row, pw):
    # Always do one hash verification, so unknown users are not distinguishable by timing.
    return check_password_hash(user_row["password_hash"] if user_row else _DUMMY, pw) and user_row is not None


def validate_new_password(pw, username=""):
    if not isinstance(pw, str) or len(pw) < 10:
        raise ApiError(400, "Password must be at least 10 characters")
    if len(pw) > 200:
        raise ApiError(400, "Password too long")
    if username and pw.lower() == username.lower():
        raise ApiError(400, "Password must not equal the username")
    if not (re.search(r"[A-Za-z]", pw) and re.search(r"[^A-Za-z]", pw)):
        raise ApiError(400, "Password must mix letters with digits or symbols")


# ---------- sessions ----------
def _h(token):
    return hashlib.sha256(token.encode()).hexdigest()


def create_session(db, user):
    cfg = current_app.config["TV"]
    token, csrf, t = secrets.token_urlsafe(32), secrets.token_urlsafe(24), now()
    begin_write(db)
    db.execute("INSERT INTO sessions(id_hash,user_id,csrf,created_at,last_seen,expires_at,ip,user_agent) "
               "VALUES(?,?,?,?,?,?,?,?)",
               (_h(token), user["id"], csrf, t, t, t + cfg.SESSION_ABSOLUTE_SECONDS,
                audit.client_ip(), request.headers.get("User-Agent", "")[:200]))
    return token, csrf


def revoke_user_sessions(db, user_id, except_hash=None):
    begin_write(db)
    if except_hash:
        db.execute("DELETE FROM sessions WHERE user_id=? AND id_hash<>?", (user_id, except_hash))
    else:
        db.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))


def lookup_session(db, token, cfg, touch=True):
    """Validate a session token against the DB *now*. Disabled users, expired
    sessions and revoked sessions all fail here, on every request."""
    if not token:
        return None
    t = now()
    row = db.execute(
        """SELECT s.id_hash, s.csrf, s.last_seen, s.expires_at, u.*
           FROM sessions s JOIN users u ON u.id = s.user_id
           WHERE s.id_hash = ? AND u.active = 1""", (_h(token),)).fetchone()
    if not row or row["expires_at"] < t or row["last_seen"] + cfg.SESSION_IDLE_SECONDS < t:
        return None
    if touch and t - row["last_seen"] > 60:
        begin_write(db)
        db.execute("UPDATE sessions SET last_seen=? WHERE id_hash=?", (t, row["id_hash"]))
    return row


def current_user():
    if "user" not in g:
        g.user = lookup_session(get_db(), request.cookies.get(COOKIE), current_app.config["TV"])
    return g.user


def set_cookie(resp, token):
    cfg = current_app.config["TV"]
    resp.set_cookie(COOKIE, token, httponly=True, samesite="Strict", secure=cfg.COOKIE_SECURE,
                    max_age=cfg.SESSION_ABSOLUTE_SECONDS, path="/")


# ---------- CSRF / origin ----------
def _same_origin():
    origin = request.headers.get("Origin")
    if origin and origin != "null":
        if urlsplit(origin).netloc != request.host:
            return False
    elif origin == "null":
        return False
    if request.headers.get("Sec-Fetch-Site") not in (None, "same-origin", "none"):
        return False
    return True


def _check_csrf(user):
    if not _same_origin():
        raise ApiError(403, "Cross-origin request refused")
    sent = request.headers.get("X-CSRF-Token", "")
    if not user or not hmac.compare_digest(sent, user["csrf"]):
        raise ApiError(403, "Missing or invalid CSRF token")


# ---------- login throttling ----------
_ip_hits = defaultdict(deque)


def ip_throttled(cfg):
    ip, t = audit.client_ip() or "?", time.time()
    q = _ip_hits[ip]
    while q and q[0] < t - 60:
        q.popleft()
    if len(q) >= cfg.IP_LOGIN_PER_MINUTE:
        return True
    q.append(t)
    return False


# ---------- decorator ----------
def api(roles=None, public=False):
    """Every route is wrapped. Default is authenticated + CSRF-checked.
    `roles` is the coarse gate; per-document decisions are made in authz.py."""
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(*a, **kw):
            if public:
                if request.method != "GET":
                    if not _same_origin():
                        raise ApiError(403, "Cross-origin request refused")
                    if not request.is_json:
                        raise ApiError(415, "JSON body required")
                return fn(*a, **kw)
            user = current_user()
            if not user:
                raise ApiError(401, "Authentication required")
            if request.method not in ("GET", "HEAD", "OPTIONS"):
                _check_csrf(user)
            if roles and user["role"] not in roles:
                db = get_db()
                audit.log(db, "access.denied", actor=user, outcome="denied",
                          attempted="route", route=request.endpoint, method=request.method)
                commit(db)
                raise ApiError(403, "Your role is not permitted to do this")
            return fn(*a, **kw)
        wrapper._tv_guarded = True
        return wrapper
    return deco


def json_body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ApiError(400, "Expected a JSON object body")
    return data
