# TrustVault API

Base path `/api`. JSON in, JSON out (uploads are `multipart/form-data`). All errors look like `{"error": "message"}`.

**Authentication.** `POST /api/auth/login` sets an `HttpOnly; SameSite=Strict` session cookie (`Secure` in production) and returns a
`csrf` token. Every non-GET request must send it as `X-CSRF-Token`, and a cross-origin `Origin` is refused.
Sessions live in the database, so logout, password change, account disable and admin revoke all take effect on the next request.

**Who may call** uses these terms:

* **anyone**: no login needed · **any user**: any logged-in account
* **owner / viewer / admin**: the account *role* (coarse gate, checked by the route guard)
* **doc read / doc edit / doc owner**: the caller's *effective permission on that document*, checked by `authz.load_doc()` on every request
  (`read` = owner, or live read/edit grant · `edit` = owner, or live edit grant held by an `owner`-role account · `doc owner` = the owner of that document)

Status codes everywhere: `401` not logged in · `403` role not allowed, bad CSRF, or you can see the document but lack that level ·
`404` document does not exist **or you have no rights on it** (deliberately indistinguishable) · `400` validation · `409` state conflict · `413` too large · `429` throttled.
Every `403`/`404` refusal on a document is written to the audit trail.

## Session

| Method & path | Who | Notes |
|---|---|---|
| `POST /api/auth/login` | anyone | `{username, password}` → `{user, csrf}`. Same error for unknown user, wrong password, locked or disabled account. 5 failures lock the account 15 min; 20 attempts/min/IP. |
| `POST /api/auth/logout` | any user | ends this session |
| `GET /api/auth/me` | any user | `{user, csrf}` |
| `POST /api/auth/password` | any user | `{current, new}`; all *other* sessions are ended |
| `GET /api/events` | any user | Server-Sent Events. Re-validates the session every second and ends with `session_ended` when it is revoked. Admin receives every audit event; others only grant changes aimed at them, activity on documents they own, and their own document actions. |
| `GET /healthz` | anyone | liveness only |

## Documents

| Method & path | Who | Notes |
|---|---|---|
| `GET /api/directory?q=` | owner | active non-admin people, for the share picker (T-45) |
| `GET /api/documents` | owner, viewer | only documents the caller owns or holds a live grant on. Filters: `q` (name/description), `category`, `owner`, `date_from`, `date_to`, `scope=all\|mine\|shared`, `trash=1` (owners: own trash), `limit`, `offset`. Admins get `403`. |
| `POST /api/documents` | owner | multipart: `file`, `name?`, `category`, `description?`. Validated (type, content, size). Creates a document owned by the caller. |
| `GET /api/documents/{id}` | doc read | metadata, versions, `my_permission`, `can`. Audited as `doc.view`. |
| `GET /api/documents/{id}/download?version=N` | doc read | decrypts, verifies integrity, audits **before** releasing bytes. Always `attachment`, `nosniff`, sandbox CSP. |
| `PATCH /api/documents/{id}` | doc edit | `{name?, description?, category?}` (allow-listed fields only). Audited with before/after. |
| `POST /api/documents/{id}/versions` | doc edit | multipart `file`; creates version N+1 |
| `DELETE /api/documents/{id}` | doc owner | move to trash (recoverable for 30 days) |
| `POST /api/documents/{id}/restore` | doc owner | from trash |
| `DELETE /api/documents/{id}/purge` | doc owner | permanent; document must already be in the trash; blobs are destroyed |
| `GET /api/documents/{id}/audit` | doc owner | who touched this document, including refused attempts |

## Sharing (all doc owner)

| Method & path | Notes |
|---|---|
| `GET /api/documents/{id}/grants` | active grants + recent history |
| `PUT /api/documents/{id}/grants` | `{user_id, permission: read\|edit, expires_at?}`. Upserts. Viewers can only receive `read`; admins and disabled users cannot receive anything. |
| `DELETE /api/documents/{id}/grants/{user_id}` | revoke. Effective on the next request. |
| `GET /api/documents/{id}/suggestions` | "who should see this?" advice. **Grants nothing.** Each suggestion is stored and audited. |
| `POST /api/documents/{id}/suggestions/{sid}/accept` | `{permission?, expires_at?}`. The human decision: creates the grant, records `via_suggestion`, audits both. |
| `POST /api/documents/{id}/suggestions/{sid}/dismiss` | audited; dismissed people are not suggested again |

## Administration (all **admin** role only; any other role gets `403`, audited)

| Method & path | Notes |
|---|---|
| `GET /api/admin/audit` | filters: `action`, `prefix`, `actor`, `outcome`, `doc_id`, `before`, `limit` (≤500) |
| `GET /api/admin/audit/verify` | walks the hash chain + HMACs + the mirror file; reports every problem |
| `GET /api/admin/audit/anchor` | `{seq, hash, at}` of the chain head, for pinning outside the system |
| `GET /api/admin/documents` | **metadata only** (name, owner, category, size, active grants, last download, denials). There is no admin route that returns content. |
| `GET /api/admin/grants` | every live grant |
| `DELETE /api/admin/grants/{grant_id}` | emergency revoke; admins can remove access, never add it |
| `GET /api/admin/users` · `POST /api/admin/users` | list · create `{username, display_name, role, password}` |
| `PATCH /api/admin/users/{id}` | `{role?, active?, display_name?}`. Disabling ends every session at once. The last active admin cannot be demoted or disabled. |
| `POST /api/admin/users/{id}/password` | reset; ends the user's sessions |
| `POST /api/admin/users/{id}/revoke-sessions` | log the user out everywhere |
| `GET /api/admin/alerts` | what is worth noticing: repeated denials, bulk downloads, login failures, retry-after-revoke, grant bursts, account changes, and **critical** if the audit chain fails verification |
| `GET /api/admin/stats` | counters for the dashboard |

## Audit actions recorded

`auth.login` `auth.login_failed` `auth.lockout` `auth.logout` `auth.password_change` · `doc.upload` `doc.view` `doc.download` `doc.update` `doc.new_version` `doc.delete` `doc.restore` `doc.purge` ·
`grant.add` `grant.update` `grant.revoke` · `suggestion.created` `suggestion.accepted` `suggestion.dismissed` · `user.create` `user.disable` `user.enable` `user.role_change` `user.password_reset` `session.revoked` ·
`access.denied` (any refused document or role-gated request, with what was attempted) · `audit.verify` · `system.error`.
Each row: sequence, time, actor, outcome (`ok`/`denied`/`error`), document, target user, details, IP, user agent, `prev_hash`, `hash`, `mac`.
