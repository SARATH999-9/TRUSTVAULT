# TrustVault

Secure document sharing where the wrong person cannot read the file, and you can prove who did.
Python full stack: **Flask + SQLite + a dependency-free JavaScript UI**, with live updates over Server-Sent Events.

| | |
|---|---|
| Live URL | _add your deployed URL here_ |
| Demo video | _add link_ |
| Docs | [API.md](API.md) · [THREATS.md](THREATS.md) · [PROMPTS.md](PROMPTS.md) · [WRITEUP.md](WRITEUP.md) · [schema.sql](schema.sql) |

## Demo accounts (created by `scripts/seed.py`)

| Role | Username | Password | Can do |
|---|---|---|---|
| Administrator | `admin` | `Vault-Admin-2026!` | manage users, see **metadata** + audit trail + alerts, emergency-revoke grants. **Cannot read any document.** |
| Document owner | `alice` | `Vault-Alice-2026!` | upload, organise, share (read/edit), revoke, delete/restore, see who touched her documents |
| Document owner | `bob` | `Vault-Bob-2026!` | same, for his own documents |
| Viewer | `carol` | `Vault-Carol-2026!` | read documents that were granted to her; nothing else |
| Viewer | `dave` | `Vault-Dave-2026!` | same |

These are public demo credentials. Change them (or set `TV_SEED=0` and create your own users) for anything real.

Try it: log in as `carol` in one browser and `alice` in another. Revoke carol's grant in Alice's window and watch Carol's list update
and her next download fail, instantly. Log in as `admin` and watch the audit feed fill live, including carol's refused probes.

## Run it

**Local (Python 3.10+)**
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python scripts/init_db.py        # create schema (idempotent)
python scripts/seed.py           # demo users + documents, created through the real API
python run.py                    # http://127.0.0.1:5000
```

**Docker**
```bash
docker compose up --build        # http://localhost:8000
```

**Production (any container host; `render.yaml` is included)**
1. Persistent disk mounted at `/data` (SQLite file + encrypted blobs live there).
2. Set `TV_COOKIE_SECURE=1`, `TV_TRUST_PROXY=1`, and **provide `TV_STORAGE_KEY` and `TV_AUDIT_KEY` from the platform's secret store**,
   not on the same disk as the data (see THREATS T-47). Generate with `python -c "import secrets;print(secrets.token_hex(32))"`.
3. Keep `WEB_CONCURRENCY=1` on SQLite unless you also move the login throttle out of process (THREATS T-50).
4. Run `python scripts/purge_trash.py` daily (cron / scheduled job) to enforce the 30-day trash retention.
5. Periodically copy `GET /api/admin/audit/anchor` somewhere the app cannot write (ticket, e-mail, WORM bucket). That is what makes tail-truncation of the audit trail provable (T-19).

Environment variables: see `.env.example`.

## Tests

```bash
python -m unittest discover -s tests -t .         # ~100 tests, about a minute
python scripts/mutation_check.py                  # removes one security check at a time; every mutant must be killed
```
`pytest` also works if you have it installed. The mutation check is the "delete one authorisation check and see whether the tests notice" exercise, automated.

## What is where

```
app/authz.py            THE authorisation decision point. Every document route goes through load_doc().
app/security.py         sessions, CSRF/origin checks, login throttle, the @api() route guard
app/audit.py            hash-chained + HMAC'd append-only audit trail, and verify()
app/storage.py          AES-256-GCM encrypted blob store (per-blob key, bound to document+version)
app/validation.py       upload validation (extension + magic bytes + zip-bomb/macro/PDF-JS rejection)
app/suggest.py          "who should see this?" advisor (advice only; never writes a grant)
app/routes/             auth, docs, admin, events (SSE)
app/static/             the single-page UI (no framework, no innerHTML)
schema.sql              database schema (applied by scripts/init_db.py)
scripts/                init_db, seed, purge_trash, mutation_check, entrypoint
tests/                  unittest suite, organised by THREATS.md entry numbers
```

## The permission model in four lines

1. **Per-document grants** to named people: `read` or `edit`, optional expiry. Nothing is inherited; there are no folders or groups to leak through.
2. **Roles cap grants.** Viewers can never edit (even if a bad row exists). Admins can never be granted documents and have no read path at all.
3. **Only the document's owner manages access** (share, revoke, delete, restore, purge, see its activity). Editors cannot re-share.
4. **The server decides, every time, from the database**: no cached decisions, no signed URLs, no share tokens. A revoke is a row update that the very next request sees.

Strangers get `404` (same as a non-existent id), so there is no existence oracle. Every refusal is written to the audit trail.
