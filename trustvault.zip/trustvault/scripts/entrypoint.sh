#!/bin/sh
# Container start: create schema, seed demo data on first run (unless TV_SEED=0), then serve.
set -e
python scripts/init_db.py
if [ "${TV_SEED:-1}" = "1" ]; then python scripts/seed.py; fi
# gthread: each live-update (SSE) connection holds one thread, so keep plenty of them.
exec gunicorn wsgi:app --bind "0.0.0.0:${PORT:-8000}" --worker-class gthread \
     --workers "${WEB_CONCURRENCY:-2}" --threads "${TV_THREADS:-32}" --timeout 120 \
     --access-logfile - --forwarded-allow-ips="${FORWARDED_ALLOW_IPS:-127.0.0.1}"
