"""Seed demo data THROUGH THE REAL API (so seed activity lands in the audit trail
and exercises the same authorisation code as any user). Idempotent.

    python scripts/seed.py
"""
import base64
import io
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import create_app            # noqa: E402
from app.db import connect, now        # noqa: E402
from app.security import hash_password  # noqa: E402

USERS = [  # username, display, role, password
    ("admin", "Ada Admin", "admin", "Vault-Admin-2026!"),
    ("alice", "Alice Owner", "owner", "Vault-Alice-2026!"),
    ("bob", "Bob Owner", "owner", "Vault-Bob-2026!"),
    ("carol", "Carol Viewer", "viewer", "Vault-Carol-2026!"),
    ("dave", "Dave Viewer", "viewer", "Vault-Dave-2026!"),
]
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")


def pdf(title, lines):
    def esc(s): return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    text = "BT /F1 14 Tf 72 720 Td 18 TL (" + esc(title) + ") Tj " + " ".join(f"T* ({esc(l)}) Tj" for l in lines) + " ET"
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
            f"<< /Length {len(text)} >>\nstream\n{text}\nendstream", "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    out, offs = b"%PDF-1.4\n", []
    for i, o in enumerate(objs, 1):
        offs.append(len(out)); out += f"{i} 0 obj\n{o}\nendobj\n".encode()
    x = len(out)
    out += f"xref\n0 {len(objs)+1}\n0000000000 65535 f \n".encode() + "".join(f"{o:010d} 00000 n \n" for o in offs).encode()
    return out + f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{x}\n%%EOF\n".encode()


def main():
    app = create_app()
    cfg = app.config["TV"]
    conn = connect(cfg.DB_PATH)
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
        print("Already seeded - nothing to do.")
        return
    u = USERS[0]   # bootstrap the first administrator directly; everything else goes through the API
    conn.execute("INSERT INTO users(username,display_name,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                 (u[0], u[1], hash_password(u[3]), u[2], now()))
    conn.close()

    def client(user, pw):
        c = app.test_client()
        r = c.post("/api/auth/login", json={"username": user, "password": pw})
        assert r.status_code == 200, r.get_json()
        c.csrf = {"X-CSRF-Token": r.get_json()["csrf"]}
        return c

    admin = client(USERS[0][0], USERS[0][3])
    ids = {}
    for name, display, role, pw in USERS[1:]:
        r = admin.post("/api/admin/users", json={"username": name, "display_name": display, "role": role, "password": pw}, headers=admin.csrf)
        assert r.status_code == 201, r.get_json()
        ids[name] = r.get_json()["id"]

    alice, bob = client("alice", USERS[1][3]), client("bob", USERS[2][3])
    carol, dave = client("carol", USERS[3][3]), client("dave", USERS[4][3])

    def upload(c, filename, data, name, category, desc=""):
        r = c.post("/api/documents", headers=c.csrf, content_type="multipart/form-data",
                   data={"file": (io.BytesIO(data), filename), "name": name, "category": category, "description": desc})
        assert r.status_code == 201, r.get_json()
        return r.get_json()["id"]

    def grant(c, doc, user, perm, days=None):
        body = {"user_id": ids[user], "permission": perm}
        if days:
            body["expires_at"] = (datetime.now(timezone.utc) + timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
        r = c.put(f"/api/documents/{doc}/grants", json=body, headers=c.csrf)
        assert r.status_code == 200, r.get_json()

    d1 = upload(alice, "acme-contract.pdf", pdf("Employment Contract - Acme Ltd", ["Confidential.", "Parties: Acme Ltd and TrustVault Demo Co."]),
                "Contract - Acme Ltd", "Contract", "Master services agreement")
    d2 = upload(alice, "globex.pdf", pdf("Contract - Globex renewal", ["Renewal terms for 2027."]), "Contract - Globex renewal", "Contract")
    d3 = upload(alice, "salary-p-sharma.txt", b"Salary letter for P. Sharma\nCTC: confidential\n", "Salary Letter - P. Sharma", "HR", "Private to HR owner")
    d4 = upload(alice, "audit-workpapers.csv", b"ref,finding,status\nA-1,Access review,open\nA-2,Backup test,closed\n", "FY26 Audit Workpapers", "Audit")
    d5 = upload(alice, "initech.pdf", pdf("Contract - Initech MSA", ["Draft."]), "Contract - Initech MSA", "Contract")
    d6 = upload(bob, "pump-drawing.png", PNG, "Pump Assembly Drawing", "Engineering", "External partner drawing")
    d7 = upload(bob, "board-minutes.txt", b"Board minutes (draft)\nItem 1: budget\n", "Board Minutes Draft", "Legal")

    grant(alice, d1, "carol", "read"); grant(alice, d1, "bob", "edit")
    grant(alice, d2, "carol", "read")
    grant(alice, d4, "dave", "read", days=14)
    grant(bob, d6, "dave", "read"); grant(bob, d6, "alice", "read")

    # A few realistic activity and refusal records so the admin views are not empty.
    carol.get(f"/api/documents/{d1}/download", headers=carol.csrf)
    dave.get(f"/api/documents/{d4}/download", headers=dave.csrf)
    for doc in (d3, d7):                   # carol probing documents she was never given
        carol.get(f"/api/documents/{doc}", headers=carol.csrf)
        carol.get(f"/api/documents/{doc}/download", headers=carol.csrf)
    print("Seeded 5 users and 7 documents.")


if __name__ == "__main__":
    main()
