"""Mutation check for the security controls.

Removes ONE check at a time from a throw-away copy of the code and runs the test
suite against the copy. A mutant that the suite does not kill is a check that no
test depends on, which is exactly what a reviewer who deletes one authorisation
check will discover. Exit status is non-zero if any mutant survives.

    python scripts/mutation_check.py            # all mutants (about 10 minutes)
    python scripts/mutation_check.py grant      # only mutants whose label contains 'grant'
"""
import shutil
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = 'doc = db.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()\n'

M = []   # (label, file, old, new)


def load_doc_skipped(label, action, anchor):
    M.append((f"load_doc('{action}') skipped: {label}", "app/routes/docs.py",
              f'doc = authz.load_doc(db, doc_id, user, "{action}")\n{anchor}', RAW + anchor))


load_doc_skipped("view", "read", "    perms = authz.permissions")
load_doc_skipped("download", "read", "    try:\n        ver = int(")
load_doc_skipped("edit metadata", "edit", "    changes = {}")
load_doc_skipped("upload version", "edit", "    filename, data, mime = _read_upload()\n    ver")
load_doc_skipped("delete", "manage", '    if doc["deleted_at"]:\n        raise ApiError(409, "Already')
load_doc_skipped("restore", "manage", '    if not doc["deleted_at"]:\n        raise ApiError(409, "Document is not')
load_doc_skipped("purge", "manage", '    if not doc["deleted_at"]:\n        raise ApiError(409, "Move')
load_doc_skipped("list grants", "manage", '    rows = db.execute("""SELECT g.*')
load_doc_skipped("add grant", "manage", "    exp = parse_when")
load_doc_skipped("revoke grant", "manage", "    begin_write(db)\n    g = db.execute")
load_doc_skipped("get suggestions", "manage", "    items = suggest.generate")
load_doc_skipped("accept suggestion", "manage", "    body = request.get_json")
load_doc_skipped("dismiss suggestion", "manage", "    s = _open_suggestion(db, doc, sid)\n    begin_write")
load_doc_skipped("per-document audit", "manage", '    rows = db.execute("SELECT * FROM audit_log WHERE doc_id=?')

M += [
    ("authz: any non-null doc passes", "app/authz.py", "if action in perms:", "if action in perms or doc is not None:"),
    ("authz: admins treated like users", "app/authz.py", 'if role == "admin":\n        return set()', 'if False:\n        return set()'),
    ("authz: demoted owner keeps ownership", "app/authz.py", 'if doc["owner_id"] == user["id"] and role == "owner":', 'if doc["owner_id"] == user["id"]:'),
    ("authz: trash reachable by grantees", "app/authz.py", '    if doc["deleted_at"]:\n        return set()', "    if False:\n        return set()"),
    ("authz: revoked grants still count", "app/authz.py", 'AND user_id=? AND revoked_at IS NULL "', 'AND user_id=? "'),
    ("authz: grant expiry ignored", "app/authz.py", '"AND (expires_at IS NULL OR expires_at > ?)"', '"AND ? IS NOT NULL"'),
    ("authz: viewer with edit grant can edit", "app/authz.py", 'if g["permission"] == "edit" and role == "owner":', 'if g["permission"] == "edit":'),
    ("authz: read grant behaves as edit", "app/authz.py", 'perms = {"read"}', 'perms = {"read", "edit"}'),
    ("authz: refusals not audited", "app/authz.py", 'audit.log(db, "access.denied", actor=user, outcome="denied", doc_id=doc_id, attempted=action)', "pass"),
    ("authz: stranger told 403 not 404", "app/authz.py", "    if perms:\n        raise ApiError(403", "    if True:\n        raise ApiError(403"),
    ("search: every document listed", "app/routes/docs.py", 'where.append("(d.owner_id=:uid OR g.id IS NOT NULL)")', 'where.append("1=1")'),
    ("search: viewers see everything", "app/routes/docs.py", 'where.append("g.id IS NOT NULL")', 'where.append("1=1")'),
    ("download: version not scoped to document (IDOR)", "app/routes/docs.py", '"SELECT * FROM document_versions WHERE document_id=? AND version=?", (doc["id"], ver)', '"SELECT * FROM document_versions WHERE (document_id=? OR 1=1) AND version=?", (doc["id"], ver)'),
    ("download: not audited", "app/routes/docs.py", 'audit.log(db, "doc.download", actor=user, doc_id=doc["id"], doc_name=doc["name"], version=ver,\n              size=v["size"], sha256=v["sha256"])', "pass"),
    ("download: served inline", "app/routes/docs.py", "as_attachment=True", "as_attachment=False"),
    ("grant: viewers can be given edit", "app/routes/docs.py", 'if permission == "edit" and target["role"] != "owner":', "if False:"),
    ("grant: admins can be granted access", "app/routes/docs.py", 'if not target or target["role"] == "admin":', "if not target:"),
    ("grant: disabled users can be granted access", "app/routes/docs.py", '"SELECT * FROM users WHERE id=? AND active=1"', '"SELECT * FROM users WHERE id=?"'),
    ("suggestion id not bound to document", "app/routes/docs.py", '"SELECT * FROM suggestions WHERE id=? AND document_id=?", (sid, doc["id"])', '"SELECT * FROM suggestions WHERE id=?", (sid,)'),
    ("route role gate removed", "app/security.py", 'if roles and user["role"] not in roles:', "if False:"),
    ("CSRF token check removed", "app/security.py", 'if not user or not hmac.compare_digest(sent, user["csrf"]):', "if False:"),
    ("origin check removed", "app/security.py", "if urlsplit(origin).netloc != request.host:\n            return False", "if False:\n            return False"),
    ("disabled user's session still valid", "app/security.py", "WHERE s.id_hash = ? AND u.active = 1", "WHERE s.id_hash = ?"),
    ("session expiry ignored", "app/security.py", 'if not row or row["expires_at"] < t or row["last_seen"] + cfg.SESSION_IDLE_SECONDS < t:', "if not row:"),
    ("login lockout removed", "app/routes/auth.py", "lock = now() + cfg.LOGIN_LOCK_SECONDS if fails >= cfg.LOGIN_MAX_FAILS else None", "lock = None"),
    ("sessions survive password change", "app/routes/auth.py", 'revoke_user_sessions(db, user["id"], except_hash=user["id_hash"])', "pass"),
    ("sessions survive account disable", "app/routes/admin.py", "revoke_user_sessions(db, uid)                 # logged out everywhere, this instant", "pass"),
    ("sessions survive admin password reset", "app/routes/admin.py", 'revoke_user_sessions(db, uid)\n    audit.log(db, "user.password_reset"', 'pass\n    audit.log(db, "user.password_reset"'),
    ("last admin can be demoted", "app/routes/admin.py", 'if u["role"] == "admin" and b["role"] != "admin" and _other_active_admins(db, uid) == 0:', "if False:"),
    ("live stream shows everyone's events to everyone", "app/routes/events.py", 'if user["role"] == "admin":', "if True:"),
    ("audit: update trigger removed", "schema.sql", "CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log\nBEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;", ""),
    ("audit: delete trigger removed", "schema.sql", "CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log\nBEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;", ""),
    ("audit: hash chain link not checked", "app/audit.py", 'if r["prev_hash"] != prev:', "if False:"),
    ("audit: row content not checked", "app/audit.py", 'if h != r["hash"]:', "if False:"),
    ("audit: HMAC not checked", "app/audit.py", 'if not hmac.compare_digest(_mac(key, r["hash"]), r["mac"]):', "if False:"),
    ("upload: PDF magic bytes not checked", "app/validation.py", 'if not data.startswith(b"%PDF-"):', "if False:"),
    ("upload: PDF active content allowed", "app/validation.py", "for marker in (b\"/JavaScript\", b\"/JS\", b\"/Launch\"):", "for marker in ():"),
    ("upload: macros allowed", "app/validation.py", 'if any(n.lower().endswith("vbaproject.bin") for n in names):', "if False:"),
    ("upload: zip bomb allowed", "app/validation.py", "if len(infos) > MAX_ZIP_ENTRIES or sum(i.file_size for i in infos) > MAX_ZIP_UNCOMPRESSED:", "if False:"),
    ("storage: blob not bound to its record (no AAD)", "app/storage.py", "AESGCM(self._key(blob_name)).decrypt(raw[:12], raw[12:], aad.encode())", "AESGCM(self._key(blob_name)).decrypt(raw[:12], raw[12:], None)"),
    ("storage: blob name traversal check removed", "app/storage.py", "if not blob_name.isalnum() or len(blob_name) != 32:", "if False:"),
]


def run_suite(cwd):
    p = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "tests", "-t", ".", "-f"],
                       cwd=cwd, capture_output=True, text=True, timeout=900)
    return p.returncode, p.stdout + p.stderr


def try_mutant(m):
    label, rel, old, new = m
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp) / "p"
        shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns(".git", "data", "__pycache__", "*.pyc", "dist"))
        f = work / rel
        src = f.read_text()
        if src.count(old) != 1:
            return label, "BAD", f"pattern matched {src.count(old)}x in {rel}"
        f.write_text(src.replace(old, new))
        code, out = run_suite(work)
    if code == 0:
        return label, "SURVIVED", ""
    first = next((l for l in out.splitlines() if l.startswith(("FAIL:", "ERROR:"))), "failed")
    return label, "killed", first[:90]


def main():
    only = sys.argv[1] if len(sys.argv) > 1 else None
    todo = [m for m in M if not only or only in m[0]]
    code, out = run_suite(ROOT)
    if code != 0:
        print("Baseline suite fails - fix that first.\n", out[-1500:])
        return 2
    bad = []
    with ThreadPoolExecutor(max_workers=2) as ex:
        for label, status, note in ex.map(try_mutant, todo):
            print(f"{status:<9} {label:<62} {note}", flush=True)
            if status != "killed":
                bad.append(label)
    print(f"\n{len(todo) - len(bad)}/{len(todo)} mutants killed." + (f"  PROBLEMS: {bad}" if bad else ""))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
