"""Create the schema (idempotent). Usage: python scripts/init_db.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import create_app

app = create_app()
print("Database ready at", app.config["TV"].DB_PATH)
