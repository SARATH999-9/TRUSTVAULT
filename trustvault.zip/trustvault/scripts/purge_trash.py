"""Retention: permanently remove documents that have sat in the trash longer than
TRASH_RETENTION_DAYS (default 30). Run daily from cron / a scheduled job.

    python scripts/purge_trash.py [--dry-run]

Blobs are deleted (so the content is gone for good); the audit rows stay forever,
and each purge is itself audited as actor 'system:retention'."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import create_app            # noqa: E402
from app.db import connect, now       # noqa: E402
from app.routes.docs import purge     # noqa: E402


def run(app, dry_run=False):
    cfg = app.config["TV"]
    cutoff = now() - cfg.TRASH_RETENTION_DAYS * 86400
    n = 0
    with app.app_context():
        db = connect(cfg.DB_PATH)
        try:
            for doc in db.execute("SELECT * FROM documents WHERE deleted_at IS NOT NULL AND deleted_at < ?", (cutoff,)).fetchall():
                n += 1
                if not dry_run:
                    purge(db, doc, None, reason="retention", attempted_username="system:retention")
        finally:
            db.close()
    return n


if __name__ == "__main__":
    n = run(create_app(), "--dry-run" in sys.argv)
    print(f"{'Would purge' if '--dry-run' in sys.argv else 'Purged'} {n} document(s).")
