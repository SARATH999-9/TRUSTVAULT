# TrustVault write-up

## What I built
A document platform in Python (Flask, SQLite, vanilla JS) with three roles, per-document grants, encrypted storage, a tamper-evident audit trail, an admin view, an advisory "who should see this?" assistant, and live updates (Server-Sent Events). All ten required capabilities are implemented; see the table in the README and [API.md](API.md) for who may call what.

| Requirement | Where |
|---|---|
| Auth, three roles, written down | `app/security.py`, README table, `app/authz.py` docstring |
| Upload / organise / search / manage | `app/routes/docs.py`; categories, versions, trash, restore, purge |
| Per-document read/edit grants to named people | `grants` table, `PUT /documents/{id}/grants` |
| Owners grant and take back | grant, update, revoke; optional expiry |
| Non-granted people cannot read/download/change/delete | `authz.load_doc()`; tests T-01…T-09 |
| Audit of uploads, downloads, changes, deletions, permission changes (and refusals) | `app/audit.py`; tests T-16…T-22 |
| Search by name, owner, category, date | `GET /documents?q=&owner=&category=&date_from=&date_to=` |
| Upload validation | `app/validation.py` |
| Admin view of activity and permission changes | Admin tabs: live audit feed, documents (metadata), grants, users, alerts, chain verification |
| Automated tests that one user cannot reach another's documents | `tests/` (≈105 tests) plus `scripts/mutation_check.py` |

## My permission model, in my own words
A document belongs to exactly one owner. Anyone else gets in only through a **grant on that document** to a named person: `read` or `edit`, optionally expiring. There are no folders, groups or inheritance, because each of those is a way for access to arrive that nobody typed in. I accept the cost: sharing forty files means forty grants (the UI makes that quick; the suggestion assistant helps).

Roles cap what grants can do. A **viewer** is read-only whatever a grant row says. An **owner** manages only their own documents. The **administrator** manages people and sees metadata and the audit trail but has no read path to any document at all (separation of duties); admins can *remove* a grant in an emergency but can never *add* one.

The server decides on every request by reading the database. Nothing is cached and nothing signed is ever issued (no share links, no JWTs, no pre-signed URLs), so "taking access away immediately" costs me only the ability to serve files from a CDN, and in exchange there is nothing to chase after a revoke. People outside the company get an account (role viewer), not a link.

## How files are stored
Encrypted with AES-256-GCM under a per-blob key (HKDF from a master key), in a directory no route serves, under random names. The ciphertext is bound to *(document id, version)*, so repointing a database row at another document's blob fails to decrypt instead of leaking. Downloads decrypt in the app after the authorisation check, and the audit row is committed before the bytes leave.

## How the audit trail is protected
Append-only by database trigger; each row hashes the previous one (chain) and is HMAC'd with a key that is not in the database; every committed row is also `fsync`'d to a second file; the admin can pin the head hash outside the system. Refusals are recorded, not just successes. `verify` is an endpoint and also runs inside the alerts view, so a broken chain shows up as a critical alert. What it cannot do: stop someone who controls the host *and* both keys from rewriting everything. Only an externally pinned anchor proves that, and that needs a human habit (THREATS T-19, T-47).

## Where I used AI, and where it was wrong
See [PROMPTS.md](PROMPTS.md). In product, the assistant suggests who might need access from *metadata only*; it has no code path that writes a grant. A person accepts or dismisses each suggestion; both the advice and the decision are audited.

## What I deliberately did not build
* **Folders / groups / inheritance**: more ways to over-share than I could prove closed in a week.
* **Share links and anonymous access**: incompatible with "revocation is immediate".
* **An LLM inside the product**: a heuristic is explainable and cannot leak content; a model would see document names and I would have to prove it never widened access.
* **MFA, SSO, e-mail password reset**: valuable, out of scope; admin-set passwords are the known weak spot (T-46).
* **Antivirus scanning, DRM, per-chunk download re-checks** (T-53, T-54, T-48).
* **Multi-node scale**: SQLite and an in-process login throttle (T-50, T-52).

## What is unfinished or weak
Everything in section G of [THREATS.md](THREATS.md). The ones I would fix first: force a password change after an admin reset; cap live-stream connections per user; move the login throttle and sessions' "last seen" into shared storage; pin the audit anchor automatically to an external sink.

## Verification
`python -m unittest discover -s tests -t .` and `python scripts/mutation_check.py` (see README). The mutation check is the automated version of "remove one authorisation check and run the tests".
