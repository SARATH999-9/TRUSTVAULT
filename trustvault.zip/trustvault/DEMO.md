# Five-minute demo script

Two browser windows side by side (use a private window for the second). Start the app with seed data.

| Time | Do | Say |
|---|---|---|
| 0:00 | Window A: log in as **alice**. Show her documents, categories, search by name/owner/date. | Owner role: uploads and manages. |
| 0:40 | Window B: log in as **carol**. Show she sees only what was shared. Try her pasting another document's URL/id: 404. | Wrong person cannot reach it, and cannot even tell it exists. |
| 1:20 | A: open "Contract - Acme Ltd" → Sharing. Click **Suggest who should see this** → show reasons → note nothing is granted. Accept one. | Advice only. A person confirms. Both are audited. |
| 2:00 | A: **revoke Carol**. B updates live; click download: refused. | Revocation is immediate: no tokens exist to chase. |
| 2:40 | Window C or A: log in as **admin**. Show live audit feed, carol's refused attempts, alerts ("refused N times"). | Refusals are evidence too. |
| 3:20 | Admin → Documents: metadata only, no download. Try the API for content as admin: refused. | Admin cannot read content: separation of duties. |
| 3:50 | Admin → Activity → "Verify audit integrity": ok. Then in a terminal drop the trigger and edit a row; verify again: **critical alert**. (`tests/test_audit.py` does this.) | Alteration is detected; HMAC key not in the DB. |
| 4:30 | Terminal: `python scripts/mutation_check.py grant` → mutants killed. Show THREATS.md. | Delete one check and the tests fail. |
