# PROMPTS.md: how AI was used, and where it was wrong

> **Read this first.** The entries below are the ones I can vouch for from the hardening session on 2026-10-19/20 with Claude.
> **Before you submit, add your own entries from the rest of the week** (your real prompts, real dates) and replace every
> `Commit: ⟨fill in⟩` with the real link once you have committed. The brief wants history across the week; I cannot invent that for you,
> and invented commit links would be worse than none.

Each entry: what was asked · what it produced · what was wrong · what was done instead.

---

## 1. 2026-10-20 · AUDIT TRAIL · "Give the audit log a second sink so tail-truncation is detectable"
**Asked:** an append-only mirror file for the audit log, cross-checked by `verify()`.
**Produced:** `audit.log()` appended and `fsync`'d each row to `audit.jsonl` *inside* the database transaction, before commit. It looked right and the existing tests (including the truncation test) passed.
**Wrong:** if the request later failed and rolled back, the mirror kept a row the database never had; the next request reused that sequence number with a different hash, and `verify()` reported "database row differs from the mirror" — a **false tamper alarm**, which would train the admin to ignore the real one. No test covered "audit, then roll back".
**Instead:** mirror lines are queued per request and written only after `COMMIT`, dropped on rollback (`app/db.py: queue_mirror/commit/rollback`). New tests `TestMirrorOnlyWritesCommittedRows` (fails on the old behaviour). THREATS T-22.
Commit: ⟨fill in⟩

## 2. 2026-10-20 · AUTHORISATION · "Is the test suite strong enough? Remove one check at a time"
**Asked:** a mutation script that deletes one authorisation or audit check at a time from a copy of the code and requires the suite to fail.
**Produced:** a first suite of 95 passing tests that I (and the AI) believed covered every route; the 55-mutant run showed **6 surviving mutants** (all 55 are now killed).
**Wrong:** the green suite was overstating its protection. The real gaps: (a) *no test that another owner cannot dismiss a suggestion on someone else's document* (a genuine missing authorisation test: `load_doc` could be deleted from that route unnoticed); (b) admin was only blocked by the "no grants for admins" rule, never tested against a forced grant row — and my first fix for it *still* survived, because the route role-gate rejected the admin before `authz` was ever reached, so the test now calls `authz.permissions()` directly; (c) a demoted owner's ownership was only tested through the route role-gate, not through `authz`; (d) a disabled account's *live* session was only tested via the code path that deletes sessions, not the lookup that also requires `active=1`; (e) the audit chain-link check was masked by the sequence-gap and mirror checks; (f) the blob-name traversal guard was never exercised.
**Instead:** a test for each (`test_other_owners_cannot_dismiss_someone_elses_suggestions`, `test_admin_gets_nothing_even_if_a_grant_row_is_forced_in`, `test_demoted_owner_cannot_use_their_old_ownership_on_any_route`, `test_session_of_an_account_disabled_behind_the_apps_back_is_dead`, `test_rewriting_one_row_with_the_key_still_breaks_the_chain_link`, `test_blob_names_from_a_tampered_db_cannot_escape_the_blob_dir`), then re-ran the survivors until killed. The script ships as `scripts/mutation_check.py`.
Commit: ⟨fill in⟩

## 3. 2026-10-20 · DOCUMENTATION vs CODE · "Write THREATS.md matching the T-numbers in the tests"
**Asked:** a THREATS.md consistent with the `T-xx` ids already in test docstrings.
**Produced:** a complete table, but (a) I assigned **T-46 twice** (SQL injection and insider admin) and (b) an old code comment (`audit.py`) cited T-14 for tail truncation while the tests use T-19 for that and T-14 for bearer links.
**Wrong:** a reviewer following a reference would land on the wrong entry, which makes the document look careless exactly where it claims rigour.
**Instead:** renumbered (SQLi is T-63, insider admin T-46), fixed the comment to T-19, and checked every test name cited in THREATS.md exists.
Commit: ⟨fill in⟩

## 4. 2026-10-20 · RETENTION · "Make sure everything the docs promise is actually enforced"
**Asked:** an audit of claims in the docs/config against the code.
**Produced / wrong:** `TRASH_RETENTION_DAYS = 30` existed in config (and I had just written "recoverable for 30 days" into API.md), but **nothing enforced it**: trashed documents and their encrypted blobs would have lived forever, quietly contradicting the docs.
**Instead:** `scripts/purge_trash.py` (dry-run flag, audited as `system:retention`, blobs destroyed), test `TestRetentionPurge`, and an honest note (THREATS T-60) that it needs a scheduler.
Commit: ⟨fill in⟩

## 5. 2026-10-20 · DEPLOYMENT / AUDIT IP · "Make it deployable"
**Asked:** Docker + hosting files.
**Produced:** a Dockerfile and host blueprint that put the app behind a reverse proxy. **Wrong (caught while reviewing the design, before shipping):** the app deliberately trusts only the socket address for client IP, so behind any proxy every audit row and login throttle would see the *proxy's* IP: the "who" in the audit trail would be useless in production, silently.
**Instead:** opt-in `TV_TRUST_PROXY=1` (Werkzeug `ProxyFix`, exactly one proxy), documented in README and THREATS T-61; default stays off so a direct-exposed deployment cannot have its IP spoofed.
Commit: ⟨fill in⟩

---

## Reused instructions and context
* [`CLAUDE.md`](CLAUDE.md): the invariants and working rules given to the assistant on every task (authorisation funnel, audit append-only, refusals audited, "never claim a control without a test").
* The workflow prompt used repeatedly: *"Write the failing test for this attack first, name the THREATS id in the docstring, then fix. Then run `scripts/mutation_check.py <keyword>`; a surviving mutant means a missing test."*
* The review prompt used on each security-relevant diff: *"List every route or code path that can reach a document, version, blob or grant list without going through `authz.load_doc()`. For each, say which test fails if the check is removed."*

## Where the AI did **not** need correcting
Password hashing, scrypt timing equalisation for unknown users, the SameSite/CSRF/Origin triple, and AES-GCM with associated data were right first time. I checked them by reading `security.py` and `storage.py` and by tests T-27 (blob swap) and T-32/T-33 (CSRF/origin), and by the mutation run removing the CSRF, Origin and AAD checks (all killed). I am reporting that because "it was all fine" is only believable with the check attached.
