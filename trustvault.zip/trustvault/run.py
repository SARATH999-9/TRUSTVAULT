"""Local/dev server. For production use gunicorn (see README / Dockerfile)."""
import os
from app import create_app

app = create_app()
if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "5000")), threaded=True)
