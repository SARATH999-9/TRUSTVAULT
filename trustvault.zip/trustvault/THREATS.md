# THREATS

How I think TrustVault can be broken, what I did about each one, and what I knowingly left open.
IDs match the docstrings in `tests/` (grep `T-17` to find the test). **Status:** *Closed* = a control plus a test that fails if the control is removed ·
*Mitigated* = reduced, not eliminated · *Accepted* = known weak, reason given.

`python scripts/mutation_check.py` deletes 55 individual checks from a copy of the code, one at a time, and requires the suite to fail for each.
That is my answer to "remove one authorisation check and run the tests".

## A. Reaching a document you were not given (the standard's rule one)

| ID | Attack | Defence | Test | Status |
|---|---|---|---|---|
| T-01 | Call any document route (view, download, edit, versions, delete, restore, purge, grants, suggestions, per-doc audit) with a document id you were not granted. Guess or reuse an id seen elsewhere. | One decision point: `authz.load_doc()` is the only path from an id to a row or its bytes; it recomputes from the database on every call. Ids are random UUIDs, never sequential. Role gate (`@api(roles=…)`) sits in front of it. | `TestNoGrantNoAccess.test_strangers_get_nothing_on_any_route` | Closed |
| T-02 | Existence oracle: tell "forbidden" from "does not exist" to discover documents. | Strangers get the same `404` and body as for a non-existent id. Only someone who can already see the document ever gets `403`. | `test_stranger_response_identical_to_nonexistent_document` | Closed (timing: T-58) |
| T-03 | A reader escalates to edit, delete, share, or reads the grant list. | Actions are `read`/`edit`/`manage`; `manage` is owner-only. Editors cannot re-share. | `test_reader_cannot_edit_or_share_or_delete` | Closed |
| T-04 | A *viewer*-role account ends up with an `edit` grant row (bug, DB edit, race with a role change). | `permissions()` caps edit to `owner`-role accounts at decision time, not only at grant time. Grant API also refuses it. | `test_viewer_role_is_read_only_even_with_edit_grant_row` | Closed |
| T-05 | The administrator reads documents. | Separation of duties: admin has **no** read path; admin routes return metadata only; admins cannot be granted documents. | `test_admin_has_no_document_access` | Closed (insider-admin: T-46) |
| T-06 | "Owner" role as master key: an owner reads another owner's document. | Ownership is per document (`owner_id == me` *and* role is owner). | `test_owner_of_another_document_has_no_power_here` | Closed |
| T-07 | Version IDOR: ask for version N of *my* document id but get another document's file, or enumerate version ids. | Versions are looked up as `(document_id, version)` after the document check; blob path is never client-supplied. | `test_version_numbers_are_scoped_to_their_document` | Closed |
| T-08 | Trashed document still reachable by former grantees. | Trash is reachable by nobody except the owner, who may only restore or purge. | `test_trashed_document_is_unreachable_except_to_owner_restore`, `test_purge_removes_blob_and_rows` | Closed |
| T-09 | Search / listing leaks documents (SQL `LIKE` wildcards, injection, filters like `owner=` or `trash=1`, pagination). | Listing SQL only returns rows the caller owns or holds a live grant on, and a test asserts the SQL and `authz.permissions()` never disagree for any user. Wildcards escaped; all values parameterised. | `TestListingAndSearch.*` | Closed |

## B. Taking access away (rule three)

| ID | Attack / failure | Defence | Test | Status |
|---|---|---|---|---|
| T-10 | Revoked person keeps using their open session. | Nothing is cached. Sessions are rows; grants are rows; each request re-reads both. Revoke = `UPDATE grants SET revoked_at`, visible to the next statement. | `test_revoke_takes_effect_on_the_very_next_request`, `test_edit_revocation_stops_writes`, `test_downgrade_edit_to_read_is_immediate` | Closed |
| T-11 | Grant that was meant to be temporary lives on. | Optional expiry is evaluated in the query, not by a job. | `test_expired_grant_stops_working` | Closed |
| T-12 | Employee leaves; their open session or a stolen cookie still works. | Disabling a user deletes all their sessions in the same transaction; session lookup also requires `active=1`. Demotion applies at once. | `test_disabling_user_kills_sessions_instantly`, `test_demotion_applies_immediately`, `test_demoted_owner_loses_management_of_own_documents` | Closed |
| T-13 | Old sessions survive logout / password change / admin reset. | All are server-side rows and are deleted. | `test_logout_and_password_change_invalidate_sessions`, `test_admin_password_reset_kills_sessions` | Closed |
| T-14 | "Their link still works": a signed URL, share token, or JWT outliving the revoke. | **None are ever issued.** There are no bearer links, no JWTs, no pre-signed storage URLs. The only credential is the session cookie, which is revocable. Cost: every download goes through the app (no CDN offload), and sharing outside the company means creating an account. | `test_no_bearer_links_exist` | Closed |
| T-15 | A revoked user's live-update stream keeps receiving events. | The SSE loop re-validates the session every second and ends; non-admins only ever receive events about themselves/their documents. | `TestLiveStream.*` | Closed |
| T-48 | **Download in flight at the instant of revoke.** | The check happens before decryption and the audit row is committed before bytes are released, so the audit order is exact. A response already being streamed (≤10 MB, held in memory) completes. | – | **Accepted**: shrinking this window to zero needs per-chunk re-checks; a person who already received the bytes cannot be un-sent them anyway. |

## C. The audit trail (rule two)

| ID | Attack | Defence | Test | Status |
|---|---|---|---|---|
| T-16 | Edit or delete audit rows through the app or SQL injection. | Append-only: SQLite triggers abort `UPDATE`/`DELETE`; there is no code path that updates it. | `test_update_and_delete_are_blocked_by_the_database` | Closed |
| T-17 | Attacker with DB-file access drops the triggers and rewrites history. | Each row is `SHA-256(prev_hash ‖ row)`, so any change breaks every later hash; `verify()` finds the first bad row. | `test_edit_after_dropping_triggers_is_detected`, `test_deleting_a_row_is_detected` | Closed |
| T-18 | Smarter attacker recomputes the whole chain. | Each hash is also HMAC'd with `AUDIT_KEY`, which is separate from the storage key and (in production) not on the DB's disk. | `test_recomputing_the_hash_chain_without_the_key_is_still_detected` | Closed if the key is held separately; see T-47 |
| T-19 | **Truncate the tail** (delete the newest rows, e.g. the download you want hidden). A chain alone cannot show this. | Every committed row is also appended and `fsync`'d to `audit.jsonl`; `verify()` cross-checks it. For attackers who can edit both files: `/api/admin/audit/anchor` gives a head hash to pin outside the system. | `test_truncating_the_tail_is_detected_via_the_mirror_file`, `test_anchor_exposes_head_for_external_pinning` | **Mitigated**: only fully provable if someone actually pins the anchor. |
| T-20 | Refused attempts leave no trace. | Every refusal (document or role gate) is audited with actor, what was attempted, IP; the refusal commits even though the request aborts. | `test_every_refusal_is_audited_with_actor`, `test_admin_denied_on_role_gate_is_audited_too`, `test_failed_request_does_not_leave_half_written_state_but_keeps_denial` | Closed |
| T-21 | Required actions missing from the record (upload, download, change, delete, permission change, login failures). | One test drives each and asserts a row exists; downloads record version, size and SHA-256; the audit row is committed **before** the bytes are released, so no unrecorded read can happen. | `TestAuditCoverage.*` | Closed |
| T-22 | False alarms destroy trust in the alarm. **Found by me during this build:** the mirror line was written before the DB commit, so a request that audited and then rolled back left a phantom mirror row and `verify()` would have reported tampering that never happened. | Mirror lines are queued and written only after `COMMIT`; dropped on rollback. A tamper failure surfaces as a **critical** admin alert. | `TestMirrorOnlyWritesCommittedRows.*`, `test_tamper_surfaces_as_critical_admin_alert` | Closed |

## D. Hostile content and storage

| ID | Attack | Defence | Test | Status |
|---|---|---|---|---|
| T-23 | Upload an executable renamed `.pdf`, a zip bomb, an Office file with macros, a PDF with JavaScript, a 5 GB file. | Allow-list of extensions; magic bytes must match the extension; Office files are opened as zips (entry count, unpacked size, unsafe paths, `[Content_Types].xml`, `vbaProject.bin`); PDFs with `/JavaScript`, `/JS`, `/Launch` rejected; 10 MB limit; server-chosen MIME, client `Content-Type` ignored. | `TestUploadValidation.*` | Mitigated (T-53) |
| T-24 | Hostile filenames: `../../x`, NUL bytes, CRLF header injection, 10 000 characters. | Filename normalised, path stripped, control characters removed, length capped; the blob name on disk is random and server-generated. | `test_hostile_filename_is_neutralised` | Closed |
| T-25 | Stored XSS through a document the browser renders in our origin. | Always `Content-Disposition: attachment`, `application/octet-stream`, `nosniff`, `Content-Security-Policy: sandbox`. | `test_downloads_are_attachments_nosniff_sandboxed` | Closed |
| T-26 | Stolen disk / backup of the blob directory. | AES-256-GCM per blob, key derived per blob from the master key. | `test_blob_is_ciphertext` | Mitigated (T-47, and metadata is not encrypted) |
| T-27 | Attacker who can write the DB repoints Bob's version row at Alice's blob, or swaps blob files. | Ciphertext is bound to `(document id, version)` as AEAD associated data: decryption fails instead of leaking. Bit-flips are detected, not served. | `test_blob_swap_between_documents_does_not_leak`, `test_flipped_bit_is_detected_not_served` | Closed |
| T-28 | Fetch blobs directly from the web server. | Blobs live outside any served directory; the only static route is `app/static`; traversal blocked. | `test_blob_dir_is_not_web_reachable` | Closed |
| T-29 | Failed insert leaves an orphan blob (plaintext remnants / storage leak). | Blob written, then DB transaction; on failure the blob is deleted. | `test_failed_insert_leaves_no_orphan_blob` | Closed |
| T-30 | Stored XSS or clickjacking through names/descriptions. | UI never uses `innerHTML`; API returns data as data; strict CSP (`script-src 'self'`), `X-Frame-Options: DENY`, `Referrer-Policy`, COOP/CORP, HSTS when secure. | `test_html_metadata_is_returned_as_data_not_markup`, `test_security_headers_everywhere` | Closed |

## E. Accounts, sessions, routes

| ID | Attack | Defence | Test | Status |
|---|---|---|---|---|
| T-31 | A developer adds a route and forgets the check. | Every API view must be wrapped by `@api()`; a test fails if one is not. Another test calls **every** route anonymously and as every non-admin role against the admin routes. | `TestEveryRouteIsGuarded.*` | Closed |
| T-32 | CSRF. | `SameSite=Strict` cookie **and** a per-session CSRF token on every non-GET **and** `Origin`/`Sec-Fetch-Site` checks. | `test_state_changing_requests_need_csrf_token`, `test_csrf_token_of_another_session_is_rejected` | Closed |
| T-33 | Cross-origin calls and login CSRF. | Origin must match host for every unsafe method, including login. | `test_cross_origin_requests_refused`, `test_login_requires_json` | Closed |
| T-34 | Session fixation, forged or garbage cookies, session theft from a DB leak. | New random token on every login; only `SHA-256(token)` is stored; `HttpOnly`, `SameSite=Strict`, `Secure` in production. | `test_new_session_token_on_every_login`, `test_forged_and_garbage_cookies_are_rejected`, `test_stored_session_value_is_not_the_cookie`, `test_cookie_flags` | Mitigated (cookie theft by malware: T-57) |
| T-35 | Sessions that never end. | 30 min idle and 12 h absolute, checked server-side. | `test_session_idle_timeout_and_absolute_expiry` | Closed |
| T-36 | Password guessing. | 5 failures lock the account 15 min; 20 attempts/min/IP; scrypt hashing. | `test_login_lockout`, `test_login_throttle_per_ip` | Mitigated (T-50, T-51) |
| T-37 | User enumeration by message or timing. | One message for every failure; a dummy scrypt verify runs for unknown users. | `test_failed_and_unknown_logins_are_recorded_without_enumeration` | Closed |
| T-38 | Privilege escalation: self-registration, mass assignment (`role`, `owner_id`, `deleted_at`), demoting the last admin. | No self-registration; allow-listed columns only; last active admin is protected. | `test_no_self_registration_and_no_privilege_escalation`, `test_mass_assignment_ignored`, `test_last_admin_cannot_be_removed` | Closed |
| T-39 | Weak passwords; hash leaked in API responses. | ≥10 chars, letters+non-letters, not the username; hash never serialised. | `test_password_policy_and_wrong_current`, `test_password_hash_never_returned` | Mitigated (no MFA: T-57) |
| T-40 | Stack traces / SQL errors leak internals. | Generic 500 body; the error itself is logged and audited as `system.error`. | `test_internal_errors_do_not_leak_details` | Closed |
| T-63 | SQL injection. | Every value is a bound parameter; the only interpolated fragments are allow-listed column names and `int`-parsed limits. | search/cookie cases in `test_search_never_widens_visibility`, `test_forged_and_garbage_cookies_are_rejected` | Closed |

## F. The AI-style assistant

| ID | Attack / failure | Defence | Test | Status |
|---|---|---|---|---|
| T-41 | The assistant widens access on its own. | `suggest.py` has no write path to `grants`. Suggestions are rows in their own table. | `test_suggestion_never_widens_access_by_itself` | Closed |
| T-42 | No record of what it advised or who decided. | `suggestion.created` (with the candidates), `suggestion.accepted`/`dismissed` (with who and what was granted) are all audited; the resulting grant carries `via_suggestion`. | `test_accept_is_a_separate_human_action_and_is_audited`, `test_owner_can_override_to_narrower_or_dismiss` | Closed |
| T-43 | It nags the owner to undo a human decision, or proposes edit for a viewer. | Anyone ever granted/revoked or dismissed on that document is never suggested; viewers only ever get `read`. | `test_revoked_people_are_not_suggested_again`, `test_suggestions_for_viewers_are_never_edit` | Closed |
| T-44 | Use a suggestion id minted for document A to grant on document B, or have an editor/other user accept one. | Suggestion lookup is scoped to the document; accept is owner-only. | `test_suggestion_id_from_another_document_is_rejected`, `test_others_cannot_see_or_accept_suggestions`, `test_editor_cannot_accept_suggestions` | Closed |

The advisor is a transparent heuristic over **metadata only** (who this owner shared similar documents with). It never reads document content, so it cannot leak it.

## G. Known weak or deliberately left open

| ID | What | Why I left it |
|---|---|---|
| T-45 | **Owners can search the internal people directory** (name, role) to pick grantees. | Needed for the share UI; admins are excluded. A hostile owner learns who works here, not what anyone holds. |
| T-46 | **Insider administrator.** An admin can reset a user's password, then log in as them and read their documents. | An admin must be able to recover accounts. Not prevented; made loud: `user.password_reset` is audited, shown as an alert, and sessions of the target are ended. Next step I did not build: force password change at first login, or two-person approval. |
| T-47 | **Keys live next to the data by default.** Without `TV_STORAGE_KEY`/`TV_AUDIT_KEY` the keys are auto-generated into the data directory (0600), so a copy of the volume contains them. | Zero-config local run. Production instructions require platform secrets. Document names/descriptions in the DB are not encrypted at all. |
| T-49 | **Admin sees document names** (in the document list and audit details). | Accountability needs it. Owners should not put secrets in titles. |
| T-50 | Login throttle is per-process memory. Several workers multiply the allowance; a restart clears it. | Per-account lockout (in the DB) still holds. Deployment sets one worker. |
| T-51 | Lockout lets an attacker lock a known account out for 15 min. | Preferred over unlimited guessing; admin can reset. |
| T-52 | SQLite is a single node and single writer. | Fine for this scale; the schema is plain SQL. Back up the `-wal` file with the DB. |
| T-53 | Upload scanning is **heuristic**: PDF active-content detection is a byte search (obfuscated names can evade it), no antivirus, no OLE-object scanning. | Downloads are never rendered by us (T-25), so the risk is to the *recipient's* viewer. A real deployment would add ClamAV. |
| T-54 | A legitimate reader can copy or forward the file. | No DRM; the audit trail tells you who had it. |
| T-55 | Each live-update stream holds a server thread; an authenticated user can open many. | No per-user connection cap yet. |
| T-56 | No rate limit on endpoints other than login. | Bulk activity is detected (alerts), not prevented. |
| T-57 | No MFA; no binding of a session to IP/device, so a stolen cookie works until revoked. | Out of a one-week scope; sessions are short and revocable. |
| T-58 | Timing can still distinguish "no such id" from "exists, not yours" by microseconds (one extra query). | Not exploitable over a network at useful resolution; same status and body. |
| T-59 | Uploads up to 10 MB are held in memory while processed. | Capped by `MAX_CONTENT_LENGTH`. |
| T-60 | Retention purge depends on someone scheduling `scripts/purge_trash.py`. | No scheduler inside the app by design. |
| T-61 | TLS is terminated by the host/proxy, and `TV_TRUST_PROXY=1` trusts `X-Forwarded-*` from exactly one proxy. | Misconfiguring that gives wrong audit IPs, not access. |
| T-64 | **No ownership transfer.** If an owner leaves (disabled or demoted), their documents become unreachable by anyone, including the admin, until the account is re-enabled/re-promoted. Their grants are not inherited. | Safe failure (nobody gets in) rather than letting admin reassign a document to themselves. A transfer-to-another-*owner* flow with audit is the obvious next feature. |
| T-62 | Demo credentials are public in the README. | Required by the brief; seed with `TV_SEED=0` for real use. |

**Not applicable here:** SSRF (the server makes no outbound requests), open redirects (none), server-side template injection (no templates), file inclusion (no dynamic paths), deserialisation of user data (JSON only).
