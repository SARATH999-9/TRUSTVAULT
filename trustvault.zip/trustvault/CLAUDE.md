# Project rules for AI assistants working on TrustVault

These are the instructions reused for every prompt in this repo (see PROMPTS.md). They exist because a confident wrong answer
in authorisation or audit code is the most expensive kind of bug in this system.

## Invariants (never break; if a request conflicts, say so instead of complying)
1. A document is reachable only through `authz.load_doc()`. Never fetch a document row, version row, or blob from a request-supplied id any other way.
2. The server decides on every request from the database. No cached decisions, no signed URLs, no share tokens, no JWTs.
3. Strangers get `404`, identical to a missing id. Only someone who can already see the document may get `403`.
4. Every refusal is audited, and the refusal row is committed before the error is raised.
5. The audit table is append-only. Never write code that updates or deletes it. Mirror lines are written only after COMMIT.
6. Admins have no read path to document content and can never *add* a grant, only remove one.
7. Suggestions (the "AI" feature) never write to `grants`. A human accepts; both are audited.
8. Every new route is wrapped in `@api(...)`, documented in API.md with who may call it, and has a test that a stranger is refused.
9. All SQL values are bound parameters; only allow-listed column names or `int()`-parsed numbers may be interpolated.
10. The UI never uses `innerHTML`.

## How to work
* Write the failing test for the attack first, then the fix. Name the THREATS.md id in the test docstring.
* After any change to `authz.py`, `security.py`, `audit.py`, `routes/docs.py`: run `python -m unittest discover -s tests -t .` and then `python scripts/mutation_check.py <keyword>`.
* A surviving mutant means a missing test, not a flaky one. Add the test; do not delete the mutant.
* Do not claim a control exists unless a test would fail without it. Say "accepted" in THREATS.md when it is a known weakness.
