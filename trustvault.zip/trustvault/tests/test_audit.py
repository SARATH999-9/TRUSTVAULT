"""THREATS T-16..T-22: the audit trail records everything, including refusals, and cannot be quietly altered."""
import sqlite3

from app import audit
from tests.base import Base, Client, PW


class TestAuditCoverage(Base):
    def test_every_required_action_is_recorded(self):
        d = self.make_doc("alice", name="Contract A")
        self.grant(d, "alice", "bob", "edit")
        self.grant(d, "alice", "bob", "read")
        self.u["bob"].get(f"/api/documents/{d}")
        self.u["bob"].get(f"/api/documents/{d}/download")
        self.u["alice"].patch(f"/api/documents/{d}", json={"name": "Contract B"})
        self.u["alice"].upload("v2.txt", b"two", url=f"/api/documents/{d}/versions")
        self.u["alice"].delete(f"/api/documents/{d}/grants/{self.ids['bob']}")
        self.u["mallory"].get(f"/api/documents/{d}/download")
        self.u["alice"].delete(f"/api/documents/{d}")
        self.u["alice"].post(f"/api/documents/{d}/restore")
        self.u["alice"].delete(f"/api/documents/{d}")
        self.u["alice"].delete(f"/api/documents/{d}/purge")
        actions = {r["action"] for r in self.audit_rows()}
        for a in ("auth.login", "doc.upload", "grant.add", "grant.update", "grant.revoke", "doc.view", "doc.download",
                  "doc.update", "doc.new_version", "doc.delete", "doc.restore", "doc.purge", "access.denied"):
            self.assertIn(a, actions)

    def test_rows_carry_actor_time_ip_and_target(self):
        d = self.make_doc("alice")
        self.grant(d, "alice", "carol")
        r = self.audit_rows(action="grant.add")[0]
        self.assertEqual((r["actor_id"], r["target_user_id"], r["doc_id"], r["outcome"]),
                         (self.ids["alice"], self.ids["carol"], d, "ok"))
        self.assertTrue(r["ts"] > 0 and r["ip"])

    def test_failed_and_unknown_logins_are_recorded_without_enumeration(self):
        c = Client(self.app, "carol")
        bad_pw = c.c.post("/api/auth/login", json={"username": "carol", "password": "wrong-password-1"})
        ghost = c.c.post("/api/auth/login", json={"username": "ghost", "password": "wrong-password-1"})
        self.assertEqual((bad_pw.status_code, bad_pw.get_json()), (ghost.status_code, ghost.get_json()))
        rows = self.audit_rows(action="auth.login_failed")
        self.assertEqual({r["actor_name"] for r in rows}, {"carol", "ghost"})

    def test_download_is_recorded_with_hash_and_version(self):
        d = self.make_doc("alice")
        self.u["alice"].get(f"/api/documents/{d}/download")
        r = self.audit_rows(action="doc.download")[0]
        self.assertIn("sha256", r["detail"])
        self.assertIn('"version":1', r["detail"])

    def test_owner_can_see_who_touched_their_document_but_not_others(self):
        d = self.make_doc("alice")
        self.u["mallory"].get(f"/api/documents/{d}")
        evs = self.u["alice"].get(f"/api/documents/{d}/audit").get_json()["events"]
        self.assertTrue(any(e["action"] == "access.denied" and e["actor"] == "mallory" for e in evs))
        self.assertTrue(all("ip" not in e for e in evs))
        self.assertEqual(self.u["mallory"].get(f"/api/documents/{d}/audit").status_code, 404)

    def test_admin_denied_on_role_gate_is_audited_too(self):
        self.u["carol"].get("/api/admin/audit")
        r = self.audit_rows(action="access.denied", actor_id=self.ids["carol"])
        self.assertTrue(r)

    def test_failed_request_does_not_leave_half_written_state_but_keeps_denial(self):
        d = self.make_doc("alice")
        before = len(self.audit_rows())
        r = self.u["mallory"].patch(f"/api/documents/{d}", json={"name": "x"})
        self.assertEqual(r.status_code, 404)
        self.assertEqual(len(self.audit_rows()), before + 1)       # exactly the denial


class TestAuditTamperEvidence(Base):
    def setUp(self):
        super().setUp()
        d = self.make_doc("alice")
        self.grant(d, "alice", "carol")
        self.u["carol"].get(f"/api/documents/{d}/download")
        self.key = self.cfg.AUDIT_KEY

    def con(self):
        c = sqlite3.connect(self.cfg.DB_PATH)
        self.addCleanup(c.close)
        return c

    def verify(self):
        return audit.verify(self.db(), self.key, self.cfg.AUDIT_FILE)

    def test_clean_chain_verifies(self):
        res = self.verify()
        self.assertTrue(res["ok"], res)
        self.assertGreater(res["count"], 3)
        self.assertEqual(self.u["admin"].get("/api/admin/audit/verify").get_json()["ok"], True)

    def test_update_and_delete_are_blocked_by_the_database(self):
        """T-16"""
        c = self.con()
        with self.assertRaises(sqlite3.DatabaseError):
            c.execute("UPDATE audit_log SET actor_name='nobody' WHERE seq=1")
        with self.assertRaises(sqlite3.DatabaseError):
            c.execute("DELETE FROM audit_log WHERE seq=1")
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM audit_log WHERE seq=1").fetchone()[0], 1)

    def test_edit_after_dropping_triggers_is_detected(self):
        """T-17: attacker with raw DB access removes the triggers and rewrites history."""
        c = self.con()
        c.execute("DROP TRIGGER audit_no_update")
        c.execute("UPDATE audit_log SET actor_name='someone-else' WHERE action='doc.download'")
        c.commit()
        res = self.verify()
        self.assertFalse(res["ok"])
        self.assertTrue(any("altered" in p for p in res["problems"]))

    def test_deleting_a_row_is_detected(self):
        c = self.con()
        c.execute("DROP TRIGGER audit_no_delete")
        c.execute("DELETE FROM audit_log WHERE action='grant.add'")      # a row in the middle
        c.commit()
        res = self.verify()
        self.assertFalse(res["ok"])
        self.assertTrue(any("gap" in p or "prev_hash" in p for p in res["problems"]))

    def test_truncating_the_tail_is_detected_via_the_mirror_file(self):
        """T-19: dropping the newest rows (e.g. the download you want hidden)."""
        c = self.con()
        c.execute("DROP TRIGGER audit_no_delete")
        c.execute("DELETE FROM audit_log WHERE action='doc.download'")   # last row in this fixture
        c.commit()
        self.assertTrue(audit.verify(self.db(), self.key)["ok"])          # chain alone cannot see it...
        res = self.verify()                                               # ...the mirror can
        self.assertFalse(res["ok"])
        self.assertTrue(any("truncated" in p for p in res["problems"]))

    def test_recomputing_the_hash_chain_without_the_key_is_still_detected(self):
        """T-18: a smart attacker fixes hashes but cannot forge the HMAC."""
        c = self.con()
        c.execute("DROP TRIGGER audit_no_update")
        row = c.execute("SELECT * FROM audit_log WHERE action='doc.download'").fetchone()
        cols = [x[0] for x in c.execute("SELECT * FROM audit_log LIMIT 1").description]
        rec = dict(zip(cols, row))
        rec["actor_name"] = "framed-someone-else"
        payload = audit._row_payload(rec["seq"], rec["ts"], rec["actor_id"], rec["actor_name"], rec["action"], rec["outcome"],
                                     rec["doc_id"], rec["target_user_id"], rec["detail"], rec["ip"], rec["user_agent"])
        new_hash = audit._hash(rec["prev_hash"], payload)
        c.execute("UPDATE audit_log SET actor_name=?, hash=? WHERE seq=?", (rec["actor_name"], new_hash, rec["seq"]))
        # ...and also repair every later prev_hash/hash so the chain links up
        prev = new_hash
        for r in c.execute("SELECT * FROM audit_log WHERE seq>? ORDER BY seq", (rec["seq"],)).fetchall():
            rr = dict(zip(cols, r))
            p = audit._row_payload(rr["seq"], rr["ts"], rr["actor_id"], rr["actor_name"], rr["action"], rr["outcome"],
                                   rr["doc_id"], rr["target_user_id"], rr["detail"], rr["ip"], rr["user_agent"])
            nh = audit._hash(prev, p)
            c.execute("UPDATE audit_log SET prev_hash=?, hash=? WHERE seq=?", (prev, nh, rr["seq"]))
            prev = nh
        c.commit()
        res = self.verify()
        self.assertFalse(res["ok"])
        self.assertTrue(any("MAC invalid" in p for p in res["problems"]))

    def test_rewriting_one_row_with_the_key_still_breaks_the_chain_link(self):
        """T-18 (key compromised): even an attacker who holds AUDIT_KEY and re-hashes + re-MACs the edited row
        cannot hide it from the chain itself, because the next row still points at the old hash.
        Checked WITHOUT the mirror file, so this proves the chain-link check specifically."""
        c = self.con()
        c.execute("DROP TRIGGER audit_no_update")
        cols = [x[0] for x in c.execute("SELECT * FROM audit_log LIMIT 1").description]
        rec = dict(zip(cols, c.execute("SELECT * FROM audit_log WHERE action='doc.download'").fetchone()))
        # a later row must exist for the link to be checked
        self.u["alice"].get("/api/documents")
        self.u["carol"].get("/api/auth/me")
        self.make_doc("alice")
        rec["actor_name"] = "framed-someone-else"
        payload = audit._row_payload(rec["seq"], rec["ts"], rec["actor_id"], rec["actor_name"], rec["action"], rec["outcome"],
                                     rec["doc_id"], rec["target_user_id"], rec["detail"], rec["ip"], rec["user_agent"])
        new_hash = audit._hash(rec["prev_hash"], payload)
        c.execute("UPDATE audit_log SET actor_name=?, hash=?, mac=? WHERE seq=?",
                  (rec["actor_name"], new_hash, audit._mac(self.key, new_hash), rec["seq"]))
        c.commit()
        self.assertGreater(c.execute("SELECT COUNT(*) FROM audit_log WHERE seq>?", (rec["seq"],)).fetchone()[0], 0)
        res = audit.verify(self.db(), self.key)                      # chain only, no mirror
        self.assertFalse(res["ok"])
        self.assertTrue(any("prev_hash does not match" in p for p in res["problems"]), res["problems"])

    def test_tamper_surfaces_as_critical_admin_alert(self):
        c = self.con()
        c.execute("DROP TRIGGER audit_no_update")
        c.execute("UPDATE audit_log SET actor_name='x' WHERE seq=2")
        c.commit()
        alerts = self.u["admin"].get("/api/admin/alerts").get_json()["alerts"]
        self.assertEqual(alerts[0]["kind"], "audit_chain_broken")

    def test_file_mirror_matches_db(self):
        lines = self.cfg.AUDIT_FILE.read_text().strip().splitlines()
        self.assertEqual(len(lines), self.db().execute("SELECT COUNT(*) FROM audit_log").fetchone()[0])

    def test_anchor_exposes_head_for_external_pinning(self):
        a = self.u["admin"].get("/api/admin/audit/anchor").get_json()
        head = self.db().execute("SELECT seq, hash FROM audit_log ORDER BY seq DESC LIMIT 1").fetchone()
        self.assertEqual((a["seq"], a["hash"]), (head["seq"], head["hash"]))


class TestAdminAlerts(Base):
    def test_probing_and_retry_after_revoke_are_flagged(self):
        d = self.make_doc("alice")
        for _ in range(5):
            self.u["mallory"].get(f"/api/documents/{d}")
        self.grant(d, "alice", "carol")
        self.u["alice"].delete(f"/api/documents/{d}/grants/{self.ids['carol']}")
        self.u["carol"].get(f"/api/documents/{d}")
        kinds = {a["kind"] for a in self.u["admin"].get("/api/admin/alerts").get_json()["alerts"]}
        self.assertIn("repeated_denials", kinds)
        self.assertIn("revoked_user_retry", kinds)

    def test_login_lockout(self):
        c = Client(self.app, "dave")
        for _ in range(5):
            c.c.post("/api/auth/login", json={"username": "dave", "password": "nope-nope-nope"})
        self.assertEqual(c.c.post("/api/auth/login", json={"username": "dave", "password": PW}).status_code, 401)
        self.assertTrue(self.audit_rows(action="auth.lockout"))
        kinds = {a["kind"] for a in self.u["admin"].get("/api/admin/alerts").get_json()["alerts"]}
        self.assertIn("login_failures", kinds)
