"""THREATS T-41..T-44: the AI-style assistant advises; only a person widens access, and it is audited."""
from tests.base import Base


class TestSuggestions(Base):
    def setUp(self):
        super().setUp()
        # alice has shared two Contract documents with carol before
        for i in range(2):
            d = self.make_doc("alice", name=f"Contract {i}", category="Contract")
            self.grant(d, "alice", "carol")
        self.new = self.make_doc("alice", name="Contract Initech", category="Contract")

    def suggestions(self, who="alice", doc=None):
        return self.u[who].get(f"/api/documents/{doc or self.new}/suggestions")

    def grants(self, doc=None):
        return self.db().execute("SELECT COUNT(*) FROM grants WHERE document_id=?", (doc or self.new,)).fetchone()[0]

    def test_suggestion_never_widens_access_by_itself(self):
        r = self.suggestions()
        self.assertEqual(r.status_code, 200)
        items = r.get_json()["suggestions"]
        self.assertEqual([i["user"]["username"] for i in items], ["carol"])
        self.assertEqual(items[0]["permission"], "read")
        self.assertEqual(self.grants(), 0)                                              # nothing granted
        self.assertEqual(self.u["carol"].get(f"/api/documents/{self.new}").status_code, 404)
        self.assertTrue(self.audit_rows(action="suggestion.created"))

    def test_accept_is_a_separate_human_action_and_is_audited(self):
        sid = self.suggestions().get_json()["suggestions"][0]["id"]
        r = self.u["alice"].post(f"/api/documents/{self.new}/suggestions/{sid}/accept", json={})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.u["carol"].get(f"/api/documents/{self.new}").status_code, 200)
        add = self.audit_rows(action="grant.add", doc_id=self.new)[0]
        self.assertIn('"via_suggestion":true', add["detail"])
        self.assertTrue(self.audit_rows(action="suggestion.accepted"))
        self.assertEqual(self.u["alice"].post(f"/api/documents/{self.new}/suggestions/{sid}/accept", json={}).status_code, 409)

    def test_owner_can_override_to_narrower_or_dismiss(self):
        sid = self.suggestions().get_json()["suggestions"][0]["id"]
        self.assertEqual(self.u["alice"].post(f"/api/documents/{self.new}/suggestions/{sid}/dismiss").status_code, 200)
        self.assertEqual(self.grants(), 0)
        self.assertEqual(self.suggestions().get_json()["suggestions"], [])               # dismissed people are not re-suggested
        self.assertTrue(self.audit_rows(action="suggestion.dismissed"))

    def test_revoked_people_are_not_suggested_again(self):
        self.grant(self.new, "alice", "carol")
        self.u["alice"].delete(f"/api/documents/{self.new}/grants/{self.ids['carol']}")
        self.assertEqual(self.suggestions().get_json()["suggestions"], [])

    def test_others_cannot_see_or_accept_suggestions(self):
        sid = self.suggestions().get_json()["suggestions"][0]["id"]
        for who in ("mallory", "bob", "carol"):
            self.assertIn(self.suggestions(who).status_code, (403, 404))
            r = self.u[who].post(f"/api/documents/{self.new}/suggestions/{sid}/accept", json={})
            self.assertIn(r.status_code, (403, 404))
        self.assertEqual(self.grants(), 0)

    def test_other_owners_cannot_dismiss_someone_elses_suggestions(self):
        """T-44: dismissing is a state change too (and a dismissed person is never suggested again)."""
        sid = self.suggestions().get_json()["suggestions"][0]["id"]
        for who in ("mallory", "bob", "carol"):
            r = self.u[who].post(f"/api/documents/{self.new}/suggestions/{sid}/dismiss", json={})
            self.assertIn(r.status_code, (403, 404), who)
        state = self.db().execute("SELECT state FROM suggestions WHERE id=?", (sid,)).fetchone()[0]
        self.assertEqual(state, "open")
        self.assertEqual(self.u["alice"].post(f"/api/documents/{self.new}/suggestions/{sid}/dismiss", json={}).status_code, 200)

    def test_editor_cannot_accept_suggestions(self):
        self.grant(self.new, "alice", "bob", "edit")
        sid = self.suggestions().get_json()["suggestions"][0]["id"]
        self.assertEqual(self.u["bob"].post(f"/api/documents/{self.new}/suggestions/{sid}/accept", json={}).status_code, 403)

    def test_suggestion_id_from_another_document_is_rejected(self):
        """T-44: can't use a suggestion minted for doc A to grant on doc B."""
        sid = self.suggestions().get_json()["suggestions"][0]["id"]
        other = self.make_doc("alice", name="Unrelated", category="HR")
        r = self.u["alice"].post(f"/api/documents/{other}/suggestions/{sid}/accept", json={})
        self.assertEqual(r.status_code, 404)
        self.assertEqual(self.grants(other), 0)

    def test_suggestions_for_viewers_are_never_edit(self):
        for i in range(3):
            d = self.make_doc("alice", name=f"Eng {i}", category="Engineering")
            self.grant(d, "alice", "dave")
        n = self.make_doc("alice", name="Eng new", category="Engineering")
        s = self.suggestions(doc=n).get_json()["suggestions"]
        self.assertTrue(s and all(i["permission"] == "read" for i in s if i["user"]["username"] == "dave"))
