"""THREATS T-01..T-08: a person who was not granted a document cannot reach it by any route."""
import sqlite3

from tests.base import Base
from app import authz


class TestNoGrantNoAccess(Base):
    """T-01: every document route, every non-granted user."""

    def setUp(self):
        super().setUp()
        self.doc = self.make_doc("alice")
        self.grant(self.doc, "alice", "bob", "edit")      # bob is granted; the others are strangers
        self.strangers = ["mallory", "carol", "dave"]

    def attempts(self):
        d = self.doc
        return [
            ("GET", f"/api/documents/{d}", {}),
            ("GET", f"/api/documents/{d}/download", {}),
            ("GET", f"/api/documents/{d}/download?version=1", {}),
            ("PATCH", f"/api/documents/{d}", {"json": {"name": "pwned"}}),
            ("POST", f"/api/documents/{d}/versions", None),
            ("DELETE", f"/api/documents/{d}", {}),
            ("POST", f"/api/documents/{d}/restore", {}),
            ("DELETE", f"/api/documents/{d}/purge", {}),
            ("GET", f"/api/documents/{d}/grants", {}),
            ("PUT", f"/api/documents/{d}/grants", {"json": {"user_id": 1, "permission": "read"}}),
            ("DELETE", f"/api/documents/{d}/grants/{self.ids['bob']}", {}),
            ("GET", f"/api/documents/{d}/suggestions", {}),
            ("POST", f"/api/documents/{d}/suggestions/1/accept", {"json": {}}),
            ("GET", f"/api/documents/{d}/audit", {}),
        ]

    def test_strangers_get_nothing_on_any_route(self):
        for who in self.strangers:
            for method, url, kw in self.attempts():
                c = self.u[who]
                if kw is None:
                    r = c.upload("evil.txt", b"x", url=url)
                else:
                    r = c.req(method, url, **kw)
                self.assertIn(r.status_code, (403, 404), f"{who} {method} {url} -> {r.status_code}")
                self.assertNotIn(b"TOP-SECRET-PAYLOAD", r.data)
        # and the document is untouched
        r = self.u["alice"].get(f"/api/documents/{self.doc}")
        self.assertEqual(r.get_json()["name"], "secret.txt")
        self.assertEqual(self.u["alice"].get(f"/api/documents/{self.doc}/download").data, b"TOP-SECRET-PAYLOAD\n")

    def test_stranger_response_identical_to_nonexistent_document(self):
        """T-02: no existence oracle."""
        real = self.u["mallory"].get(f"/api/documents/{self.doc}")
        fake = self.u["mallory"].get("/api/documents/" + "0" * 32)
        self.assertEqual(real.status_code, fake.status_code)
        self.assertEqual(real.get_json(), fake.get_json())

    def test_every_refusal_is_audited_with_actor(self):
        for method, url, kw in self.attempts()[:3]:
            self.u["mallory"].req(method, url, **(kw or {}))
        denied = self.audit_rows(action="access.denied", actor_id=self.ids["mallory"])
        self.assertGreaterEqual(len(denied), 3)
        self.assertTrue(all(r["outcome"] == "denied" and r["doc_id"] == self.doc for r in denied))

    def test_reader_cannot_edit_or_share_or_delete(self):
        """T-03: a read grant is only read; an editor still cannot manage."""
        self.grant(self.doc, "alice", "carol", "read")
        c = self.u["carol"]
        self.assertEqual(c.get(f"/api/documents/{self.doc}").status_code, 200)
        self.assertEqual(c.patch(f"/api/documents/{self.doc}", json={"name": "x"}).status_code, 403)
        self.assertEqual(c.upload("n.txt", b"v2", url=f"/api/documents/{self.doc}/versions").status_code, 403)
        self.assertEqual(c.delete(f"/api/documents/{self.doc}").status_code, 403)
        b = self.u["bob"]    # editor
        self.assertEqual(b.patch(f"/api/documents/{self.doc}", json={"name": "renamed"}).status_code, 200)
        self.assertEqual(b.put(f"/api/documents/{self.doc}/grants", json={"user_id": self.ids["mallory"], "permission": "read"}).status_code, 403)
        self.assertEqual(b.delete(f"/api/documents/{self.doc}").status_code, 403)
        self.assertEqual(b.get(f"/api/documents/{self.doc}/grants").status_code, 403)
        self.assertEqual(self.u["mallory"].get(f"/api/documents/{self.doc}").status_code, 404)

    def test_viewer_role_is_read_only_even_with_edit_grant_row(self):
        """T-04: role cap holds even if a bad grant row exists (defence in depth)."""
        r = self.u["alice"].put(f"/api/documents/{self.doc}/grants", json={"user_id": self.ids["carol"], "permission": "edit"})
        self.assertEqual(r.status_code, 400)
        con = self.db()
        con.execute("INSERT INTO grants(document_id,user_id,permission,granted_by,granted_at) VALUES(?,?,?,?,0)",
                    (self.doc, self.ids["carol"], "edit", self.ids["alice"]))
        con.commit()
        c = self.u["carol"]
        self.assertEqual(c.get(f"/api/documents/{self.doc}").status_code, 200)
        self.assertEqual(c.patch(f"/api/documents/{self.doc}", json={"name": "x"}).status_code, 403)

    def test_admin_has_no_document_access(self):
        """T-05: separation of duties: admin sees metadata and audit, never content."""
        a = self.u["admin"]
        for method, url in [("GET", f"/api/documents/{self.doc}"), ("GET", f"/api/documents/{self.doc}/download"),
                            ("PATCH", f"/api/documents/{self.doc}"), ("DELETE", f"/api/documents/{self.doc}"),
                            ("PUT", f"/api/documents/{self.doc}/grants"), ("GET", "/api/documents")]:
            r = a.req(method, url, json={"user_id": self.ids["admin"], "permission": "read"})
            self.assertIn(r.status_code, (403, 404), f"{method} {url}")
            self.assertNotIn(b"TOP-SECRET", r.data)
        self.assertEqual(a.upload("x.txt", b"x").status_code, 403)
        meta = a.get("/api/admin/documents").get_json()["documents"]
        self.assertEqual(len(meta), 1)
        self.assertNotIn("TOP-SECRET", str(meta))
        # no admin route can grant
        r = a.put(f"/api/admin/documents/{self.doc}/grants", json={"user_id": self.ids["admin"], "permission": "read"})
        self.assertIn(r.status_code, (404, 405))

    def test_admin_gets_nothing_even_if_a_grant_row_is_forced_in(self):
        """T-05 (defence in depth): a grant row for an admin, written straight into the DB, still opens nothing."""
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.execute("INSERT INTO grants(document_id,user_id,permission,granted_by,granted_at) VALUES(?,?,?,?,?)",
                    (self.doc, self.ids["admin"], "edit", self.ids["alice"], 0))
        con.commit()
        con.close()
        a = self.u["admin"]
        for method, url in [("GET", f"/api/documents/{self.doc}"), ("GET", f"/api/documents/{self.doc}/download"),
                            ("PATCH", f"/api/documents/{self.doc}")]:
            self.assertIn(a.req(method, url, json={"name": "x"}).status_code, (403, 404), f"{method} {url}")
        # The route role-gate already stops admins; the decision function must independently agree,
        # so a future route that forgets the role gate still cannot open a document to an admin.
        con = self.db()
        admin = con.execute("SELECT * FROM users WHERE username='admin'").fetchone()
        doc = con.execute("SELECT * FROM documents WHERE id=?", (self.doc,)).fetchone()
        self.assertEqual(authz.permissions(con, admin, doc), set())

    def test_demoted_owner_cannot_use_their_old_ownership_on_any_route(self):
        """T-06: ownership only counts while the account still has the owner role."""
        self.u["admin"].patch(f"/api/admin/users/{self.ids['alice']}", json={"role": "viewer"})
        a = self.u["alice"]
        for method, url in [("GET", f"/api/documents/{self.doc}"), ("GET", f"/api/documents/{self.doc}/download"),
                            ("PATCH", f"/api/documents/{self.doc}"), ("DELETE", f"/api/documents/{self.doc}"),
                            ("GET", f"/api/documents/{self.doc}/grants")]:
            r = a.req(method, url, json={"name": "x"})
            self.assertIn(r.status_code, (403, 404), f"{method} {url}")
            self.assertNotIn(b"TOP-SECRET", r.data)

    def test_owner_of_another_document_has_no_power_here(self):
        """T-06: 'owner' role is not a master key."""
        other = self.make_doc("mallory", data=b"mallory-doc")
        self.assertEqual(self.u["mallory"].get(f"/api/documents/{other}/download").data, b"mallory-doc")
        self.assertEqual(self.u["mallory"].get(f"/api/documents/{self.doc}/download").status_code, 404)
        r = self.u["mallory"].put(f"/api/documents/{self.doc}/grants", json={"user_id": self.ids["mallory"], "permission": "edit"})
        self.assertEqual(r.status_code, 404)

    def test_version_numbers_are_scoped_to_their_document(self):
        """T-07: asking for version N of my doc never returns someone else's file."""
        mine = self.make_doc("mallory", data=b"mallory-v1")
        self.u["alice"].upload("v2.txt", b"alice-v2-SECRET", url=f"/api/documents/{self.doc}/versions")
        r = self.u["mallory"].get(f"/api/documents/{mine}/download?version=2")
        self.assertEqual(r.status_code, 404)
        self.assertNotIn(b"alice", r.data)

    def test_trashed_document_is_unreachable_except_to_owner_restore(self):
        """T-08"""
        self.grant(self.doc, "alice", "carol", "read")
        self.assertEqual(self.u["alice"].delete(f"/api/documents/{self.doc}").status_code, 200)
        for who in ("carol", "bob", "mallory"):
            self.assertEqual(self.u[who].get(f"/api/documents/{self.doc}").status_code, 404)
            self.assertEqual(self.u[who].get(f"/api/documents/{self.doc}/download").status_code, 404)
        self.assertEqual(self.u["alice"].get(f"/api/documents/{self.doc}/download").status_code, 403)  # owner: trash only restores
        self.assertEqual(self.u["carol"].post(f"/api/documents/{self.doc}/restore").status_code, 403)   # role gate
        self.assertEqual(self.u["mallory"].post(f"/api/documents/{self.doc}/restore").status_code, 404)
        self.assertEqual(self.u["alice"].post(f"/api/documents/{self.doc}/restore").status_code, 200)
        self.assertEqual(self.u["carol"].get(f"/api/documents/{self.doc}").status_code, 200)

    def test_purge_removes_blob_and_rows(self):
        con = self.db()
        blob = con.execute("SELECT blob_name FROM document_versions WHERE document_id=?", (self.doc,)).fetchone()[0]
        self.assertEqual(self.u["alice"].delete(f"/api/documents/{self.doc}/purge").status_code, 409)  # must trash first
        self.u["alice"].delete(f"/api/documents/{self.doc}")
        self.assertEqual(self.u["alice"].delete(f"/api/documents/{self.doc}/purge").status_code, 200)
        self.assertFalse((self.cfg.BLOB_DIR / f"{blob}.bin").exists())
        self.assertEqual(self.u["alice"].get(f"/api/documents/{self.doc}").status_code, 404)


class TestListingAndSearch(Base):
    def test_listing_equals_authz_for_every_user(self):
        """T-09: the SQL listing and authz.permissions can never disagree."""
        d1, d2, d3 = self.make_doc("alice"), self.make_doc("bob"), self.make_doc("mallory")
        self.grant(d1, "alice", "carol"); self.grant(d2, "bob", "alice", "edit"); self.grant(d2, "bob", "dave")
        self.u["mallory"].delete(f"/api/documents/{d3}")
        con = self.db()
        for name in self.u:
            user = con.execute("SELECT * FROM users WHERE username=?", (name,)).fetchone()
            expected = {d["id"] for d in con.execute("SELECT * FROM documents")
                        if "read" in authz.permissions(con, user, d)}
            resp = self.u[name].get("/api/documents")
            if name == "admin":
                self.assertEqual(resp.status_code, 403)
                self.assertEqual(expected, set())
                continue
            self.assertEqual(resp.status_code, 200, (name, resp.get_json()))
            self.assertEqual({x["id"] for x in resp.get_json()["documents"]}, expected, name)

    def test_search_never_widens_visibility(self):
        secret = self.make_doc("alice", name="Salary letter Priya", category="HR")
        for q in ("Salary", "%", "_", "sal%", "' OR 1=1 --"):
            for who in ("carol", "dave", "mallory", "bob"):
                r = self.u[who].get("/api/documents", query_string={"q": q})
                self.assertEqual(r.status_code, 200)
                self.assertEqual([d for d in r.get_json()["documents"] if d["id"] == secret], [], f"{who} q={q!r}")
        for params in ({"owner": "alice"}, {"category": "HR"}, {"date_from": "2000-01-01"}, {"scope": "all"}, {"trash": "1"}):
            r = self.u["carol"].get("/api/documents", query_string=params)
            self.assertNotIn(secret, [d["id"] for d in r.get_json().get("documents", [])], params)
        self.assertEqual(self.u["carol"].get("/api/documents?trash=1").status_code, 403)

    def test_search_filters_work_for_authorised_user(self):
        d = self.make_doc("alice", name="Quarterly Contract", category="Contract")
        self.make_doc("alice", name="Other thing", category="HR")
        g = lambda **p: [x["id"] for x in self.u["alice"].get("/api/documents", query_string=p).get_json()["documents"]]
        self.assertEqual(g(q="quarterly"), [d])
        self.assertEqual(g(category="Contract"), [d])
        self.assertEqual(g(owner="alice").__len__(), 2)
        self.assertEqual(g(owner="nobody"), [])
        self.assertEqual(len(g(date_from="2000-01-01", date_to="2999-01-01")), 2)
        self.assertEqual(g(date_to="2000-01-01"), [])
        self.assertEqual(self.u["alice"].get("/api/documents?category=Nope").status_code, 400)
        self.assertEqual(self.u["alice"].get("/api/documents?date_from=garbage").status_code, 400)


class TestGrantRules(Base):
    def test_grant_validation(self):
        d = self.make_doc("alice")
        a = self.u["alice"]
        put = lambda body: a.put(f"/api/documents/{d}/grants", json=body).status_code
        self.assertEqual(put({"user_id": self.ids["admin"], "permission": "read"}), 400)   # admins never get documents
        self.assertEqual(put({"user_id": 9999, "permission": "read"}), 400)
        self.assertEqual(put({"user_id": self.ids["alice"], "permission": "read"}), 400)
        self.assertEqual(put({"user_id": "2", "permission": "read"}), 400)
        self.assertEqual(put({"user_id": self.ids["bob"], "permission": "manage"}), 400)
        self.assertEqual(put({"user_id": self.ids["bob"], "permission": "read", "expires_at": "2001-01-01"}), 400)
        self.assertEqual(put({"user_id": self.ids["bob"], "permission": "read"}), 200)

    def test_cannot_grant_to_disabled_user(self):
        d = self.make_doc("alice")
        self.u["admin"].patch(f"/api/admin/users/{self.ids['carol']}", json={"active": False})
        r = self.u["alice"].put(f"/api/documents/{d}/grants", json={"user_id": self.ids["carol"], "permission": "read"})
        self.assertEqual(r.status_code, 400)

    def test_regrant_updates_not_duplicates(self):
        d = self.make_doc("alice")
        self.grant(d, "alice", "bob", "read"); self.grant(d, "alice", "bob", "edit")
        con = self.db()
        self.assertEqual(con.execute("SELECT COUNT(*) FROM grants WHERE document_id=? AND revoked_at IS NULL", (d,)).fetchone()[0], 1)
        self.assertEqual(len(self.audit_rows(action="grant.update")), 1)

    def test_mass_assignment_ignored(self):
        d = self.make_doc("alice")
        self.grant(d, "alice", "bob", "edit")
        r = self.u["bob"].patch(f"/api/documents/{d}", json={"name": "ok", "owner_id": self.ids["bob"], "deleted_at": 1})
        self.assertEqual(r.status_code, 200)
        row = self.db().execute("SELECT owner_id, deleted_at FROM documents WHERE id=?", (d,)).fetchone()
        self.assertEqual((row["owner_id"], row["deleted_at"]), (self.ids["alice"], None))


class TestDirectory(Base):
    def test_only_owners_can_list_people_and_never_admins_or_self(self):
        r = self.u["alice"].get("/api/directory")
        names = {u["username"] for u in r.get_json()["users"]}
        self.assertEqual(names, {"bob", "mallory", "carol", "dave"})
        self.assertEqual(self.u["carol"].get("/api/directory").status_code, 403)
        self.assertEqual(self.u["admin"].get("/api/directory").status_code, 403)
        self.assertNotIn("password", r.get_data(as_text=True).lower())
        self.assertEqual(self.u["alice"].get("/api/directory?q=car").get_json()["users"][0]["username"], "carol")
