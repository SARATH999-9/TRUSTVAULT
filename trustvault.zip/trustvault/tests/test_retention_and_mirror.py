import json
import sqlite3
import sys
from pathlib import Path

from app import audit
from app.db import now
from tests.base import Base

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import purge_trash  # noqa: E402


class TestMirrorOnlyWritesCommittedRows(Base):
    def mirror_seqs(self):
        return [json.loads(l)["seq"] for l in open(self.cfg.AUDIT_FILE, encoding="utf-8")]

    def test_rolled_back_request_leaves_nothing_in_the_mirror(self):
        """A request that audits and then fails (rollback) must not leave a phantom mirror row,
        otherwise verify() would report tampering that never happened."""
        self.make_doc("alice")
        self.assertTrue(audit.verify(self.db(), self.cfg.AUDIT_KEY, self.cfg.AUDIT_FILE)["ok"])
        before = self.mirror_seqs()
        # Write an audit row inside a transaction, then roll the transaction back (what a failing request does).
        from app.db import begin_write, connect, rollback
        db = connect(self.cfg.DB_PATH)
        with self.app.test_request_context():
            begin_write(db)
            audit.log(db, "test.phantom", outcome="ok")
            rollback(db)
        db.close()
        self.assertEqual(self.mirror_seqs(), before)
        self.assertTrue(audit.verify(self.db(), self.cfg.AUDIT_KEY, self.cfg.AUDIT_FILE)["ok"])

    def test_refusal_is_in_the_mirror_after_commit(self):
        d = self.make_doc("alice")
        self.u["mallory"].get(f"/api/documents/{d}/download")
        rows = [json.loads(l) for l in open(self.cfg.AUDIT_FILE, encoding="utf-8")]
        self.assertTrue(any(r["action"] == "access.denied" and r["outcome"] == "denied" for r in rows))
        self.assertTrue(audit.verify(self.db(), self.cfg.AUDIT_KEY, self.cfg.AUDIT_FILE)["ok"])


class TestRetentionPurge(Base):
    def test_old_trash_is_purged_recent_trash_and_live_docs_are_not(self):
        old, recent, live = self.make_doc("alice"), self.make_doc("alice"), self.make_doc("alice")
        for d in (old, recent):
            self.u["alice"].delete(f"/api/documents/{d}")
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.execute("UPDATE documents SET deleted_at=? WHERE id=?", (now() - 31 * 86400, old))
        con.commit()
        blob = con.execute("SELECT blob_name FROM document_versions WHERE document_id=?", (old,)).fetchone()[0]
        con.close()
        self.assertEqual(purge_trash.run(self.app, dry_run=True), 1)
        self.assertTrue((self.cfg.BLOB_DIR / f"{blob}.bin").exists())
        self.assertEqual(purge_trash.run(self.app), 1)
        self.assertFalse((self.cfg.BLOB_DIR / f"{blob}.bin").exists())
        con = self.db()
        self.assertEqual(con.execute("SELECT COUNT(*) FROM documents WHERE id=?", (old,)).fetchone()[0], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM documents WHERE id IN (?,?)", (recent, live)).fetchone()[0], 2)
        r = con.execute("SELECT * FROM audit_log WHERE action='doc.purge' AND doc_id=?", (old,)).fetchone()
        self.assertEqual(r["actor_name"], "system:retention")
        self.assertTrue(audit.verify(con, self.cfg.AUDIT_KEY, self.cfg.AUDIT_FILE)["ok"])
