"""THREATS T-10..T-15: taking access away works immediately."""
import json
import sqlite3
import time

from app.routes.events import stream
from tests.base import Base, PW, Client


class TestRevocation(Base):
    def setUp(self):
        super().setUp()
        self.doc = self.make_doc("alice")
        self.grant(self.doc, "alice", "carol")
        self.grant(self.doc, "alice", "bob", "edit")

    def test_revoke_takes_effect_on_the_very_next_request(self):
        """T-10: same session, same cookie, no re-login: access is gone."""
        c = self.u["carol"]
        self.assertEqual(c.get(f"/api/documents/{self.doc}/download").status_code, 200)
        self.assertEqual(self.u["alice"].delete(f"/api/documents/{self.doc}/grants/{self.ids['carol']}").status_code, 200)
        for url in (f"/api/documents/{self.doc}", f"/api/documents/{self.doc}/download"):
            self.assertEqual(c.get(url).status_code, 404)
        self.assertNotIn(self.doc, [d["id"] for d in c.get("/api/documents").get_json()["documents"]])

    def test_edit_revocation_stops_writes(self):
        b = self.u["bob"]
        self.assertEqual(b.patch(f"/api/documents/{self.doc}", json={"name": "ok"}).status_code, 200)
        self.u["alice"].delete(f"/api/documents/{self.doc}/grants/{self.ids['bob']}")
        self.assertEqual(b.patch(f"/api/documents/{self.doc}", json={"name": "after"}).status_code, 404)
        self.assertEqual(b.upload("n.txt", b"v", url=f"/api/documents/{self.doc}/versions").status_code, 404)

    def test_downgrade_edit_to_read_is_immediate(self):
        self.grant(self.doc, "alice", "bob", "read")
        self.assertEqual(self.u["bob"].patch(f"/api/documents/{self.doc}", json={"name": "x"}).status_code, 403)

    def test_expired_grant_stops_working(self):
        """T-11"""
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.execute("UPDATE grants SET expires_at=? WHERE user_id=?", (time.time() - 5, self.ids["carol"]))
        con.commit()
        self.assertEqual(self.u["carol"].get(f"/api/documents/{self.doc}").status_code, 404)

    def test_disabling_user_kills_sessions_instantly(self):
        """T-12: someone leaves the company; their open session and any stolen cookie die now."""
        c = self.u["carol"]
        self.assertEqual(c.get("/api/auth/me").status_code, 200)
        self.assertEqual(self.u["admin"].patch(f"/api/admin/users/{self.ids['carol']}", json={"active": False}).status_code, 200)
        self.assertEqual(c.get("/api/auth/me").status_code, 401)
        self.assertEqual(c.get(f"/api/documents/{self.doc}/download").status_code, 401)
        self.assertEqual(Client(self.app, "carol").login().status_code, 401)
        self.u["admin"].patch(f"/api/admin/users/{self.ids['carol']}", json={"active": True})
        self.assertEqual(c.get("/api/auth/me").status_code, 401)       # old session did not come back

    def test_session_of_an_account_disabled_behind_the_apps_back_is_dead(self):
        """T-12 (defence in depth): the session lookup itself requires an active account, so an account
        deactivated by any other route (DB edit, future code path, a race) cannot keep using a live cookie."""
        c = self.u["carol"]
        self.assertEqual(c.get("/api/auth/me").status_code, 200)
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.execute("UPDATE users SET active=0 WHERE id=?", (self.ids["carol"],))   # note: sessions NOT deleted
        con.commit()
        self.assertEqual(con.execute("SELECT COUNT(*) FROM sessions WHERE user_id=?", (self.ids["carol"],)).fetchone()[0], 1)
        con.close()
        self.assertEqual(c.get("/api/auth/me").status_code, 401)
        self.assertEqual(c.get(f"/api/documents/{self.doc}/download").status_code, 401)

    def test_demotion_applies_immediately(self):
        self.u["admin"].patch(f"/api/admin/users/{self.ids['bob']}", json={"role": "viewer"})
        self.assertEqual(self.u["bob"].patch(f"/api/documents/{self.doc}", json={"name": "x"}).status_code, 403)
        self.assertEqual(self.u["bob"].get(f"/api/documents/{self.doc}").status_code, 200)

    def test_demoted_owner_loses_management_of_own_documents(self):
        self.u["admin"].patch(f"/api/admin/users/{self.ids['alice']}", json={"role": "viewer"})
        self.assertEqual(self.u["alice"].put(f"/api/documents/{self.doc}/grants",
                                             json={"user_id": self.ids["dave"], "permission": "read"}).status_code, 403)

    def test_admin_emergency_revoke(self):
        gid = self.db().execute("SELECT id FROM grants WHERE user_id=?", (self.ids["carol"],)).fetchone()[0]
        self.assertEqual(self.u["admin"].delete(f"/api/admin/grants/{gid}").status_code, 200)
        self.assertEqual(self.u["carol"].get(f"/api/documents/{self.doc}").status_code, 404)
        ev = self.audit_rows(action="grant.revoke")[-1]
        self.assertIn('"by_admin":true', ev["detail"])

    def test_logout_and_password_change_invalidate_sessions(self):
        """T-13"""
        stolen = Client(self.app, "dave"); stolen.login()
        mine = Client(self.app, "dave"); mine.login()
        r = mine.post("/api/auth/password", json={"current": PW, "new": "Another-Pass-77"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(stolen.get("/api/auth/me").status_code, 401)   # other session died
        self.assertEqual(mine.get("/api/auth/me").status_code, 200)
        mine.post("/api/auth/logout")
        self.assertEqual(mine.get("/api/auth/me").status_code, 401)

    def test_admin_password_reset_kills_sessions(self):
        self.u["admin"].post(f"/api/admin/users/{self.ids['dave']}/password", json={"password": "Reset-Pass-123"})
        self.assertEqual(self.u["dave"].get("/api/auth/me").status_code, 401)

    def test_no_bearer_links_exist(self):
        """T-14: nothing we issue (no signed URLs / share tokens) can outlive a revoke:
        the only credential is the session, re-validated against the DB every request."""
        d = self.make_doc("alice")
        r = self.u["alice"].get(f"/api/documents/{d}/download")
        self.assertNotIn("Location", r.headers)
        self.assertEqual(self.u["alice"].c.get(f"/api/documents/{d}/download").status_code, 200)   # cookie works
        self.assertEqual(self.app.test_client().get(f"/api/documents/{d}/download").status_code, 401)  # URL alone is useless
        self.assertEqual(self.app.test_client().get(f"/api/documents/{d}/download?token=abc&session=x").status_code, 401)


class TestLiveStream(Base):
    def _token(self, name):
        return self.u[name].c.get_cookie("tv_session").value

    def _events(self, name, start=0, ticks=2):
        out = []
        for chunk in stream(self.cfg, self._token(name), start, max_ticks=ticks, sleep=0):
            if chunk.startswith("id:"):
                out.append(json.loads(chunk.split("data: ", 1)[1]))
            elif chunk.startswith("event: session_ended"):
                out.append({"ended": True})
        return out

    def test_stream_ends_when_session_revoked(self):
        """T-15"""
        self.u["admin"].patch(f"/api/admin/users/{self.ids['carol']}", json={"active": False})
        self.assertEqual(self._events("carol"), [{"ended": True}])

    def test_target_user_is_told_about_revocation_and_nothing_else(self):
        doc = self.make_doc("alice", name="Alice private")
        other = self.make_doc("bob", name="Bob private")
        self.grant(doc, "alice", "carol")
        self.u["alice"].delete(f"/api/documents/{doc}/grants/{self.ids['carol']}")
        self.u["bob"].get(f"/api/documents/{other}")
        evs = self._events("carol")
        actions = [(e["action"], e["doc_id"]) for e in evs]
        self.assertIn(("grant.add", doc), actions)
        self.assertIn(("grant.revoke", doc), actions)
        self.assertTrue(all(e["doc_id"] != other for e in evs), "carol must not see bob's activity")
        self.assertTrue(all("ip" not in e for e in evs))

    def test_owner_sees_denied_attempts_on_own_docs_but_not_others(self):
        mine, theirs = self.make_doc("alice"), self.make_doc("bob")
        self.u["mallory"].get(f"/api/documents/{mine}")
        self.u["mallory"].get(f"/api/documents/{theirs}")
        seen = {e["doc_id"] for e in self._events("alice") if e["outcome"] == "denied"}
        self.assertEqual(seen, {mine})

    def test_admin_sees_everything_with_ip(self):
        d = self.make_doc("alice")
        self.u["mallory"].get(f"/api/documents/{d}")
        evs = self._events("admin")
        self.assertTrue(any(e["action"] == "access.denied" for e in evs))
        self.assertTrue(all("ip" in e for e in evs))

    def test_non_admin_cannot_use_admin_endpoints(self):
        for who in ("alice", "carol"):
            for url in ("/api/admin/audit", "/api/admin/alerts", "/api/admin/users", "/api/admin/documents", "/api/admin/stats"):
                self.assertEqual(self.u[who].get(url).status_code, 403, (who, url))
