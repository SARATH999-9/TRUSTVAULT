"""THREATS T-23..T-30: hostile uploads, storage at rest, path tricks."""
import io
import zipfile

from tests.base import Base

PDF = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"


def office(ext, extra=None, names=None):
    buf = io.BytesIO()
    prefix = {"docx": "word/", "xlsx": "xl/", "pptx": "ppt/"}[ext]
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        for n in names or [prefix + "document.xml"]:
            z.writestr(n, "<x/>")
        for n, d in (extra or {}).items():
            z.writestr(n, d)
    return buf.getvalue()


class TestUploadValidation(Base):
    def up(self, filename, data, who="alice", **kw):
        return self.u[who].upload(filename, data, **kw)

    def test_accepts_legit_files(self):
        for fn, data in [("a.pdf", PDF), ("a.txt", b"hi"), ("a.csv", b"a,b\n1,2\n"), ("a.png", b"\x89PNG\r\n\x1a\nxx"),
                         ("a.jpg", b"\xff\xd8\xff\xe0xx"), ("a.docx", office("docx")), ("a.xlsx", office("xlsx")),
                         ("a.pptx", office("pptx"))]:
            self.assertEqual(self.up(fn, data).status_code, 201, fn)

    def test_rejects_dangerous_or_mismatched(self):
        cases = {
            "exe": ("tool.exe", b"MZ\x90\x00"),
            "html": ("page.html", b"<script>alert(1)</script>"),
            "svg": ("x.svg", b"<svg onload=alert(1)>"),
            "no extension": ("README", b"hello"),
            "double ext": ("a.pdf.exe", b"MZ"),
            "exe renamed pdf": ("a.pdf", b"MZ\x90\x00 not a pdf"),
            "html renamed png": ("a.png", b"<html>"),
            "empty": ("a.txt", b""),
            "binary txt": ("a.txt", b"abc\x00def"),
            "latin1 txt": ("a.txt", b"caf\xe9"),
            "pdf with js": ("a.pdf", PDF + b"/JavaScript (app.alert(1))"),
            "fake docx": ("a.docx", b"PK\x03\x04garbage"),
            "docx wrong zip": ("a.docx", office("xlsx")),
            "macro docx": ("a.docx", office("docx", {"word/vbaProject.bin": "x"})),
            "zip path traversal": ("a.docx", office("docx", names=["word/../../evil.xml"])),
            "legacy doc": ("a.doc", b"\xd0\xcf\x11\xe0"),
        }
        for label, (fn, data) in cases.items():
            r = self.up(fn, data)
            self.assertEqual(r.status_code, 400, f"{label}: {r.status_code} {r.get_json()}")
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM documents").fetchone()[0], 0)

    def test_zip_bomb_rejected(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", "<Types/>")
            z.writestr("word/document.xml", b"\0" * (210 * 1024 * 1024))
        self.assertLess(len(buf.getvalue()), 1024 * 1024)
        r = self.up("bomb.docx", buf.getvalue())
        self.assertEqual(r.status_code, 400)

    def test_size_limit(self):
        self.cfg.MAX_UPLOAD_BYTES = 1024
        self.app.config["MAX_CONTENT_LENGTH"] = 1024 + 1024 * 1024
        self.assertEqual(self.up("big.txt", b"a" * 2000).status_code, 413)
        self.assertEqual(self.up("ok.txt", b"a" * 900).status_code, 201)

    def test_viewers_and_admins_cannot_upload(self):
        self.assertEqual(self.up("a.txt", b"x", who="carol").status_code, 403)
        self.assertEqual(self.up("a.txt", b"x", who="admin").status_code, 403)

    def test_bad_metadata_rejected(self):
        self.assertEqual(self.up("a.txt", b"x", category="Nope").status_code, 400)
        self.assertEqual(self.up("a.txt", b"x", name="n" * 500).status_code, 400)
        self.assertEqual(self.up("a.txt", b"x", description="d" * 5000).status_code, 400)

    def test_missing_file_field(self):
        r = self.u["alice"].post("/api/documents", data={"name": "x"})
        self.assertEqual(r.status_code, 400)

    def test_hostile_filename_is_neutralised(self):
        """T-24: path traversal / header injection through the filename."""
        for fn in ("../../../etc/passwd.txt", "..\\..\\win.txt", "nul\x00.txt", "<img src=x onerror=1>.txt"):
            r = self.up(fn, b"data")
            self.assertEqual(r.status_code, 201, (fn, r.get_json()))
            d = r.get_json()["id"]
            dl = self.u["alice"].get(f"/api/documents/{d}/download")
            cd = dl.headers["Content-Disposition"]
            self.assertNotIn("..", cd.replace("filename*", ""))
            self.assertNotIn("\n", cd)
            self.assertNotIn("X-Evil", dl.headers)
        from app.validation import clean_filename
        self.assertNotIn("\n", clean_filename("a\r\nX-Evil: 1.txt"))
        # blobs only ever live under the blob dir with random names
        for p in self.cfg.BLOB_DIR.iterdir():
            self.assertRegex(p.name, r"^[0-9a-f]{32}\.bin$")
        self.assertFalse((self.cfg.DATA_DIR.parent / "passwd.txt").exists())


class TestDownloadHeaders(Base):
    def test_downloads_are_attachments_nosniff_sandboxed(self):
        """T-25: uploaded content is never rendered by the browser in our origin."""
        d = self.make_doc("alice", "note.txt", b"<script>alert(1)</script>", name="x")
        r = self.u["alice"].get(f"/api/documents/{d}/download")
        self.assertIn("attachment", r.headers["Content-Disposition"])
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(r.headers["Content-Type"], "application/octet-stream")
        self.assertIn("sandbox", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["Cache-Control"], "no-store")

    def test_security_headers_everywhere(self):
        r = self.app.test_client().get("/")
        self.assertIn("script-src 'self'", r.headers["Content-Security-Policy"])
        self.assertNotIn("unsafe-inline", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")

    def test_html_metadata_is_returned_as_data_not_markup(self):
        d = self.make_doc("alice", name="<img src=x onerror=alert(1)>")
        r = self.u["alice"].get(f"/api/documents/{d}")
        self.assertEqual(r.headers["Content-Type"], "application/json")
        self.assertEqual(r.get_json()["name"], "<img src=x onerror=alert(1)>")   # UI renders with textContent


class TestEncryptionAtRest(Base):
    def test_blob_is_ciphertext(self):
        """T-26: stolen disk or backup does not reveal contents."""
        self.make_doc("alice", data=b"TOP-SECRET-PAYLOAD " * 10)
        blobs = list(self.cfg.BLOB_DIR.glob("*.bin"))
        self.assertEqual(len(blobs), 1)
        self.assertNotIn(b"TOP-SECRET", blobs[0].read_bytes())
        self.assertEqual(oct(blobs[0].stat().st_mode & 0o777), "0o600")

    def test_flipped_bit_is_detected_not_served(self):
        d = self.make_doc("alice")
        p = next(self.cfg.BLOB_DIR.glob("*.bin"))
        raw = bytearray(p.read_bytes()); raw[-1] ^= 1; p.write_bytes(bytes(raw))
        r = self.u["alice"].get(f"/api/documents/{d}/download")
        self.assertEqual(r.status_code, 500)
        self.assertNotIn(b"TOP-SECRET", r.data)

    def test_blob_swap_between_documents_does_not_leak(self):
        """T-27: DB-write attacker repoints bob's version row at alice's blob."""
        a = self.make_doc("alice", data=b"ALICE-SECRET")
        b = self.make_doc("bob", data=b"bob-data")
        con = self.db()
        blob_a = con.execute("SELECT blob_name FROM document_versions WHERE document_id=?", (a,)).fetchone()[0]
        blob_b = con.execute("SELECT blob_name FROM document_versions WHERE document_id=?", (b,)).fetchone()[0]
        import shutil
        shutil.copy(self.cfg.BLOB_DIR / f"{blob_a}.bin", self.cfg.BLOB_DIR / f"{blob_b}.bin")   # file-level swap
        r = self.u["bob"].get(f"/api/documents/{b}/download")
        self.assertEqual(r.status_code, 500)
        self.assertNotIn(b"ALICE-SECRET", r.data)

    def test_blob_dir_is_not_web_reachable(self):
        self.make_doc("alice")
        name = next(self.cfg.BLOB_DIR.glob("*.bin")).name
        c = self.app.test_client()
        for url in (f"/static/../data/blobs/{name}", f"/static/%2e%2e/data/blobs/{name}", f"/data/blobs/{name}",
                    "/static/../data/trustvault.db", "/static/..%2fdata%2ftrustvault.db", "/schema.sql", "/static/../schema.sql"):
            self.assertEqual(c.get(url).status_code, 404, url)

    def test_blob_names_from_a_tampered_db_cannot_escape_the_blob_dir(self):
        """T-28: a DB-write attacker sets blob_name to a path. Reads must fail and purge must not delete outside."""
        from app.storage import BlobStore, StorageError
        victim = self.cfg.DATA_DIR / "victim.bin"
        victim.write_bytes(b"do not delete me")
        store = BlobStore(self.cfg.BLOB_DIR, self.cfg.STORAGE_KEY)
        for bad in ("../victim", "../../victim", "..%2fvictim", "a" * 31 + "/", "", "x" * 33, "../" + "a" * 29):
            with self.assertRaises(StorageError, msg=bad):
                store.get(bad, "aad")
            store.delete(bad)
        self.assertTrue(victim.exists())
        # the same attack through the real purge path
        d = self.make_doc("alice")
        import sqlite3
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.execute("UPDATE document_versions SET blob_name='../victim' WHERE document_id=?", (d,))
        con.commit(); con.close()
        self.u["alice"].delete(f"/api/documents/{d}")
        self.u["alice"].delete(f"/api/documents/{d}/purge")
        self.assertTrue(victim.exists())

    def test_failed_insert_leaves_no_orphan_blob(self):
        import sqlite3
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.execute("DROP TABLE document_versions"); con.commit()
        r = self.u["alice"].upload("a.txt", b"x")
        self.assertEqual(r.status_code, 500)
        self.assertEqual(list(self.cfg.BLOB_DIR.glob("*.bin")), [])
