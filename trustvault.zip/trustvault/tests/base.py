import io
import shutil
import sqlite3
import tempfile
import unittest

from app import create_app
from app.db import now
from app.security import hash_password

PW = "Correct-Horse-9!"
USERS = [("admin", "admin"), ("alice", "owner"), ("bob", "owner"), ("mallory", "owner"),
         ("carol", "viewer"), ("dave", "viewer")]
_HASH = hash_password(PW)       # one scrypt hash reused: tests stay fast


class Client:
    """Test client that is logged in and sends the CSRF header like the real UI."""
    def __init__(self, app, name):
        self.app, self.name, self.c = app, name, app.test_client()

    def login(self, pw=PW):
        r = self.c.post("/api/auth/login", json={"username": self.name, "password": pw})
        self.csrf = r.get_json().get("csrf") if r.status_code == 200 else None
        return r

    def req(self, method, url, csrf=True, **kw):
        headers = kw.pop("headers", {})
        if csrf and getattr(self, "csrf", None):
            headers = {"X-CSRF-Token": self.csrf, **headers}
        return self.c.open(url, method=method, headers=headers, **kw)

    def get(self, url, **kw): return self.req("GET", url, **kw)
    def post(self, url, **kw): return self.req("POST", url, **kw)
    def put(self, url, **kw): return self.req("PUT", url, **kw)
    def patch(self, url, **kw): return self.req("PATCH", url, **kw)
    def delete(self, url, **kw): return self.req("DELETE", url, **kw)

    def upload(self, filename="a.txt", data=b"hello world\n", name=None, category="Other", url="/api/documents", **form):
        return self.post(url, content_type="multipart/form-data",
                         data={"file": (io.BytesIO(data), filename), "name": name or filename,
                               "category": category, **form})


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="tvtest-")
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        self.app = create_app(DATA_DIR=self.tmp, TESTING=True, IP_LOGIN_PER_MINUTE=10_000)
        self.cfg = self.app.config["TV"]
        con = sqlite3.connect(self.cfg.DB_PATH)
        self.ids = {}
        for name, role in USERS:
            cur = con.execute("INSERT INTO users(username,display_name,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                              (name, name.title(), _HASH, role, now()))
            self.ids[name] = cur.lastrowid
        con.commit()
        con.close()
        self.u = {}
        for name, _ in USERS:
            self.u[name] = Client(self.app, name)
            assert self.u[name].login().status_code == 200

    # ---- helpers
    def db(self):
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.row_factory = sqlite3.Row
        self.addCleanup(con.close)
        return con

    def make_doc(self, owner="alice", filename="secret.txt", data=b"TOP-SECRET-PAYLOAD\n", **kw):
        r = self.u[owner].upload(filename, data, **kw)
        self.assertEqual(r.status_code, 201, r.get_json())
        return r.get_json()["id"]

    def grant(self, doc, owner, to, perm="read", **extra):
        r = self.u[owner].put(f"/api/documents/{doc}/grants", json={"user_id": self.ids[to], "permission": perm, **extra})
        self.assertEqual(r.status_code, 200, r.get_json())

    def audit_rows(self, **where):
        con = self.db()
        sql = "SELECT * FROM audit_log" + (" WHERE " + " AND ".join(f"{k}=?" for k in where) if where else "") + " ORDER BY seq"
        return con.execute(sql, tuple(where.values())).fetchall()

    def only(self, user_from, *others):
        return [u for u in self.u if u not in (user_from,) + others]
