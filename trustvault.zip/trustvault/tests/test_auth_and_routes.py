"""THREATS T-31..T-40: authentication, CSRF, session handling, route coverage."""
from tests.base import Base, Client, PW


class TestEveryRouteIsGuarded(Base):
    """T-31: a new route added without authorisation fails these tests."""

    def rules(self):
        for rule in self.app.url_map.iter_rules():
            if rule.rule.startswith("/api/"):
                yield rule

    def test_all_api_view_functions_are_wrapped_by_the_guard(self):
        for rule in self.rules():
            fn = self.app.view_functions[rule.endpoint]
            self.assertTrue(getattr(fn, "_tv_guarded", False), f"{rule.rule} is not wrapped by @api()")

    def test_every_api_route_rejects_anonymous_callers(self):
        public = {"/api/auth/login"}
        anon = self.app.test_client()
        for rule in self.rules():
            if rule.rule in public:
                continue
            url = rule.rule
            for arg in rule.arguments:
                url = url.replace(f"<int:{arg}>", "1").replace(f"<{arg}>", "x" * 32)
            for method in rule.methods - {"HEAD", "OPTIONS"}:
                r = anon.open(url, method=method)
                self.assertEqual(r.status_code, 401, f"{method} {url} -> {r.status_code}")

    def test_every_admin_route_rejects_every_non_admin(self):
        for rule in self.rules():
            if not rule.rule.startswith("/api/admin/"):
                continue
            url = rule.rule
            for arg in rule.arguments:
                url = url.replace(f"<int:{arg}>", "1")
            for who in ("alice", "carol"):
                for method in rule.methods - {"HEAD", "OPTIONS"}:
                    r = self.u[who].req(method, url, json={})
                    self.assertEqual(r.status_code, 403, f"{who} {method} {url}")


class TestSessionsAndCsrf(Base):
    def test_cookie_flags(self):
        c = Client(self.app, "carol")
        r = c.login()
        sc = r.headers["Set-Cookie"]
        self.assertIn("HttpOnly", sc)
        self.assertIn("SameSite=Strict", sc)
        self.assertIn("Path=/", sc)

    def test_secure_flag_when_configured(self):
        from app import create_app
        import tempfile
        app = create_app(DATA_DIR=tempfile.mkdtemp(), COOKIE_SECURE=True, TESTING=True)
        self.assertTrue(app.config["TV"].COOKIE_SECURE)

    def test_state_changing_requests_need_csrf_token(self):
        d = self.make_doc("alice")
        r = self.u["alice"].delete(f"/api/documents/{d}", csrf=False)
        self.assertEqual(r.status_code, 403)
        r = self.u["alice"].delete(f"/api/documents/{d}", headers={"X-CSRF-Token": "wrong"})
        self.assertEqual(r.status_code, 403)
        self.assertEqual(self.u["alice"].get(f"/api/documents/{d}").status_code, 200)   # still there

    def test_csrf_token_of_another_session_is_rejected(self):
        d = self.make_doc("alice")
        r = self.u["alice"].delete(f"/api/documents/{d}", headers={"X-CSRF-Token": self.u["bob"].csrf})
        self.assertEqual(r.status_code, 403)

    def test_cross_origin_requests_refused(self):
        d = self.make_doc("alice")
        a = self.u["alice"]
        r = a.delete(f"/api/documents/{d}", headers={"Origin": "https://evil.example"})
        self.assertEqual(r.status_code, 403)
        r = a.delete(f"/api/documents/{d}", headers={"Origin": "null"})
        self.assertEqual(r.status_code, 403)
        r = a.delete(f"/api/documents/{d}", headers={"Sec-Fetch-Site": "cross-site"})
        self.assertEqual(r.status_code, 403)
        r = Client(self.app, "x").c.post("/api/auth/login", json={"username": "alice", "password": PW},
                                         headers={"Origin": "https://evil.example"})
        self.assertEqual(r.status_code, 403)                       # login CSRF

    def test_login_requires_json(self):
        r = self.app.test_client().post("/api/auth/login", data={"username": "alice", "password": PW})
        self.assertEqual(r.status_code, 415)

    def test_new_session_token_on_every_login(self):
        a, b = Client(self.app, "carol"), Client(self.app, "carol")
        a.login(); b.login()
        self.assertNotEqual(a.c.get_cookie("tv_session").value, b.c.get_cookie("tv_session").value)

    def test_forged_and_garbage_cookies_are_rejected(self):
        c = self.app.test_client()
        for v in ("", "abc", "' OR 1=1 --", "A" * 5000, self.u["alice"].c.get_cookie("tv_session").value[:-1] + "x"):
            c.set_cookie("tv_session", v)
            self.assertEqual(c.get("/api/auth/me").status_code, 401)

    def test_stored_session_value_is_not_the_cookie(self):
        token = self.u["alice"].c.get_cookie("tv_session").value
        rows = [r[0] for r in self.db().execute("SELECT id_hash FROM sessions")]
        self.assertNotIn(token, rows)

    def test_session_idle_timeout_and_absolute_expiry(self):
        import sqlite3
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.execute("UPDATE sessions SET last_seen=last_seen-100000 WHERE user_id=?", (self.ids["carol"],))
        con.execute("UPDATE sessions SET expires_at=1 WHERE user_id=?", (self.ids["dave"],))
        con.commit()
        self.assertEqual(self.u["carol"].get("/api/auth/me").status_code, 401)
        self.assertEqual(self.u["dave"].get("/api/auth/me").status_code, 401)

    def test_no_self_registration_and_no_privilege_escalation(self):
        c = self.app.test_client()
        for url in ("/api/auth/register", "/api/register", "/api/users"):
            self.assertIn(c.post(url, json={"username": "x"}).status_code, (404, 405))
        r = self.u["carol"].patch(f"/api/admin/users/{self.ids['carol']}", json={"role": "admin"})
        self.assertEqual(r.status_code, 403)
        r = self.u["carol"].post("/api/admin/users", json={"username": "evil", "display_name": "e", "role": "admin", "password": "Evil-Pass-1234"})
        self.assertEqual(r.status_code, 403)

    def test_last_admin_cannot_be_removed(self):
        a = self.u["admin"]
        self.assertEqual(a.patch(f"/api/admin/users/{self.ids['admin']}", json={"role": "viewer"}).status_code, 409)
        self.assertEqual(a.patch(f"/api/admin/users/{self.ids['admin']}", json={"active": False}).status_code, 409)

    def test_password_policy_and_wrong_current(self):
        c = self.u["carol"]
        self.assertEqual(c.post("/api/auth/password", json={"current": "wrong", "new": "Another-Pass-77"}).status_code, 403)
        for bad in ("short1!", "onlyletterslong", "12345678901234", "carol"):
            self.assertEqual(c.post("/api/auth/password", json={"current": PW, "new": bad}).status_code, 400, bad)

    def test_password_hash_never_returned(self):
        for url in ("/api/auth/me", "/api/admin/users"):
            self.assertNotIn("password", self.u["admin"].get(url).get_data(as_text=True).lower().replace("password_reset", ""))

    def test_login_throttle_per_ip(self):
        from app import create_app
        import tempfile
        app = create_app(DATA_DIR=tempfile.mkdtemp(), TESTING=True, IP_LOGIN_PER_MINUTE=3)
        from app import security
        security._ip_hits.clear()
        c = app.test_client()
        codes = [c.post("/api/auth/login", json={"username": f"u{i}", "password": "x"}).status_code for i in range(6)]
        self.assertIn(429, codes)

    def test_internal_errors_do_not_leak_details(self):
        import sqlite3
        con = sqlite3.connect(self.cfg.DB_PATH)
        con.execute("DROP TABLE grants"); con.commit()
        d = self.make_doc("alice") if False else None
        r = self.u["alice"].get("/api/documents")
        self.assertEqual(r.status_code, 500)
        self.assertEqual(r.get_json(), {"error": "Internal error"})
        self.assertNotIn("sqlite", r.get_data(as_text=True).lower())
