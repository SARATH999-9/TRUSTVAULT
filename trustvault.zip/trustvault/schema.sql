-- TrustVault schema (SQLite). Applied by scripts/init_db.py (idempotent).
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
  display_name  TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('admin','owner','viewer')),
  active        INTEGER NOT NULL DEFAULT 1,
  failed_logins INTEGER NOT NULL DEFAULT 0,
  locked_until  REAL,
  created_at    REAL NOT NULL
);

-- Server-side sessions. Only the SHA-256 of the cookie token is stored.
CREATE TABLE IF NOT EXISTS sessions (
  id_hash    TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf       TEXT NOT NULL,
  created_at REAL NOT NULL,
  last_seen  REAL NOT NULL,
  expires_at REAL NOT NULL,
  ip         TEXT,
  user_agent TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS documents (
  id          TEXT PRIMARY KEY,                       -- random UUID, never sequential
  name        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  category    TEXT NOT NULL,
  owner_id    INTEGER NOT NULL REFERENCES users(id),
  current_version INTEGER NOT NULL DEFAULT 1,
  created_at  REAL NOT NULL,
  updated_at  REAL NOT NULL,
  deleted_at  REAL,                                   -- soft delete (recoverable)
  deleted_by  INTEGER REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_docs_owner ON documents(owner_id);

CREATE TABLE IF NOT EXISTS document_versions (
  id          TEXT PRIMARY KEY,
  document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  version     INTEGER NOT NULL,
  blob_name   TEXT NOT NULL UNIQUE,                   -- random name on disk; encrypted at rest
  size        INTEGER NOT NULL,
  sha256      TEXT NOT NULL,                          -- of the plaintext
  mime        TEXT NOT NULL,
  original_filename TEXT NOT NULL,
  uploaded_by INTEGER NOT NULL REFERENCES users(id),
  uploaded_at REAL NOT NULL,
  UNIQUE (document_id, version)
);

-- Per-document grants. A grant is never deleted, only revoked, so history survives.
CREATE TABLE IF NOT EXISTS grants (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  document_id   TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  user_id       INTEGER NOT NULL REFERENCES users(id),
  permission    TEXT NOT NULL CHECK (permission IN ('read','edit')),
  granted_by    INTEGER NOT NULL REFERENCES users(id),
  granted_at    REAL NOT NULL,
  expires_at    REAL,
  revoked_at    REAL,
  revoked_by    INTEGER REFERENCES users(id),
  suggestion_id INTEGER
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_grant
  ON grants(document_id, user_id) WHERE revoked_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_grants_user ON grants(user_id);

-- Suggestions are advice only. Nothing here ever grants access.
CREATE TABLE IF NOT EXISTS suggestions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  permission  TEXT NOT NULL CHECK (permission IN ('read','edit')),
  reason      TEXT NOT NULL,
  score       REAL NOT NULL,
  created_at  REAL NOT NULL,
  state       TEXT NOT NULL DEFAULT 'open' CHECK (state IN ('open','accepted','dismissed')),
  decided_by  INTEGER REFERENCES users(id),
  decided_at  REAL
);

-- Append-only, hash-chained audit trail.
CREATE TABLE IF NOT EXISTS audit_log (
  seq            INTEGER PRIMARY KEY,
  ts             REAL NOT NULL,
  actor_id       INTEGER,
  actor_name     TEXT,
  action         TEXT NOT NULL,
  outcome        TEXT NOT NULL CHECK (outcome IN ('ok','denied','error')),
  doc_id         TEXT,
  target_user_id INTEGER,
  detail         TEXT NOT NULL DEFAULT '{}',
  ip             TEXT,
  user_agent     TEXT,
  prev_hash      TEXT NOT NULL,
  hash           TEXT NOT NULL,
  mac            TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_doc ON audit_log(doc_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_log(actor_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action);

-- The application cannot rewrite history even through a bug or SQL injection
-- that reaches this connection: UPDATE and DELETE on the audit table abort.
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
